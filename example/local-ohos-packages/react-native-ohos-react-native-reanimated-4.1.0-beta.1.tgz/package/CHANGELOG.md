# Changelog

## ReleaseLog

### [4.1.0-beta.1] 2026-09-09
### Added
- based on the 4.5.3 version of react-native-reanimated for adaptation, it supports RNOH 0.84.* version.([#81](https://gitcode.com/CPF-RN/rntpc_react-native-reanimated/issues/81))


### [4.0.2] 2026-08-20
### Added
- add support for useReducedMotion (API >= 23).([#89](https://gitcode.com/CPF-RN/rntpc_react-native-reanimated/pull/89))

### Fixed
- ensure animation library works normally when switching to JSVM virtual machin([#76](https://gitcode.com/CPF-RN/rntpc_react-native-reanimated/pull/76))
- fix the issue of compiling hermes::inspector on the latest version 82 framework, with a switch consistent with the framework([#68](https://gitcode.com/CPF-RN/rntpc_react-native-reanimated/pull/68))


### [4.0.1] 2026-04-15
### Fixed
- fix version verification of the official worklets package to read the HarmonyOS-adapted worklets version([#47](https://gitcode.com/CPF-RN/rntpc_react-native-reanimated/pull/47))
- fix crash in ~ReanimatedModuleProxy -> ~ShadowNodeFamily([#48](https://gitcode.com/CPF-RN/rntpc_react-native-reanimated/pull/48))


### [4.0.0] 2026-03-31
### Added
- 增加基于react-native-reanimated 4.2.1版本进行鸿蒙化，提供js侧更改
- 将源库react-native-reanimated c侧的common的实现copy鸿蒙工程
- 新增react-native-reanimated中鸿蒙原生侧的package及其TurboModule
- 新增react-native-reanimated鸿蒙原生侧ReanimatedModuleProxy的构建及其ReanimatedModule的Fabric的初始化
- 新增react-native-reanimated中鸿蒙侧传感器的实现

### Fixed
- 修复在realease模式下打包运行编译报错的问题


## ReleaseLog

### 3.18.0
#### Key changes compared to 3.17.5
- Support for React Native 0.80-rc.3
- Fix for Jest Snapshots
- Fix Native Proxy leak

#### What's Changed
- cherry-pick: Add missing optional chaining operator in current react owner check by [@MatiPl01](https://github.com/MatiPl01) in [#7550](https://github.com/software-mansion/react-native-reanimated/pull/7550)
- cherry-pick: Export some internal layout animations types ([#7546](https://github.com/software-mansion/react-native-reanimated/pull/7546)) by [@MatiPl01](https://github.com/MatiPl01) in [#7549](https://github.com/software-mansion/react-native-reanimated/pull/7549)
- (cherry-pick) fix: cleanup sensors in invalidate and make nativeProxy not leak ([#7515](https://github.com/software-mansion/react-native-reanimated/pull/7515)) by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7552](https://github.com/software-mansion/react-native-reanimated/pull/7552)
- (cherry-pick) fix: Move check of last state inside loop ([#7506](https://github.com/software-mansion/react-native-reanimated/pull/7506)) by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7551](https://github.com/software-mansion/react-native-reanimated/pull/7551)
- (cherry-pick) fix: lack of hidden hermes flags ([#7398](https://github.com/software-mansion/react-native-reanimated/pull/7398)) by [@tjzel](https://github.com/tjzel) in [#7557](https://github.com/software-mansion/react-native-reanimated/pull/7557)
- chore(Reanimated3): cherry-pick [#7428](https://github.com/software-mansion/react-native-reanimated/pull/7428) by [@tjzel](https://github.com/tjzel) in [#7558](https://github.com/software-mansion/react-native-reanimated/pull/7558)
- chore(Reanimated3): cherry-pick [#7372](https://github.com/software-mansion/react-native-reanimated/pull/7372) by [@tjzel](https://github.com/tjzel) in [#7559](https://github.com/software-mansion/react-native-reanimated/pull/7559)
- [v3] Add support for React Native 0.80 by [@tomekzaw](https://github.com/tomekzaw) in [#7555](https://github.com/software-mansion/react-native-reanimated/pull/7555)
- (v3) fix: TVOS example crashing right after launch by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7600](https://github.com/software-mansion/react-native-reanimated/pull/7600)
- Release 3.18.0 by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7595](https://github.com/software-mansion/react-native-reanimated/pull/7595)

### 3.17.5
#### What's Changed
- cherry pick: Fix numeric colors processing by [@MatiPl01](https://github.com/MatiPl01) in [#7404](https://github.com/software-mansion/react-native-reanimated/pull/7404)
- fix: Animations on android not working if multiple styles objects are present in the props vector by [@MatiPl01](https://github.com/MatiPl01) in [#7422](https://github.com/software-mansion/react-native-reanimated/pull/7422)
- Release 3.17.5 by [@MatiPl01](https://github.com/MatiPl01) in [#7425](https://github.com/software-mansion/react-native-reanimated/pull/7425)

### 3.17.4
#### What's Changed
- chore: Bump macos and tvos example dependencies by [@MatiPl01](https://github.com/MatiPl01) in [#7350](https://github.com/software-mansion/react-native-reanimated/pull/7350)
- [cherry-pick] Fix profiles example ([#7359](https://github.com/software-mansion/react-native-reanimated/pull/7359)) by [@skusnierz](https://github.com/skusnierz) in [#7371](https://github.com/software-mansion/react-native-reanimated/pull/7371)
- fix: Initial animated style updater style is applied on re-render by [@MatiPl01](https://github.com/MatiPl01) in [#7376](https://github.com/software-mansion/react-native-reanimated/pull/7376)
- cherry-pick: Support for all transform origin values by [@MatiPl01](https://github.com/MatiPl01) in [#7395](https://github.com/software-mansion/react-native-reanimated/pull/7395)
- (cherry-pick) fix: Support optional arguments in boxShadow string ([#7386](https://github.com/software-mansion/react-native-reanimated/pull/7386)) by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7394](https://github.com/software-mansion/react-native-reanimated/pull/7394)
- cherry-pick: Layout animations with rotation not working in RN 0.79 by [@MatiPl01](https://github.com/MatiPl01) in [#7400](https://github.com/software-mansion/react-native-reanimated/pull/7400)
- Release 3.17.4 by [@MatiPl01](https://github.com/MatiPl01) in [#7399](https://github.com/software-mansion/react-native-reanimated/pull/7399)

### 3.17.3
#### What's Changed
- backport: fix: Misspelt height prop name in supported layout animation props by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7339](https://github.com/software-mansion/react-native-reanimated/pull/7339)
- (cherry-pick) Bump react-native-is-edge-to-edge to 1.1.7 ([#7346](https://github.com/software-mansion/react-native-reanimated/pull/7346)) by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7356](https://github.com/software-mansion/react-native-reanimated/pull/7356)
- (cherry-pick) Add processing for array color related props by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7357](https://github.com/software-mansion/react-native-reanimated/pull/7357)
- (cherry-pick) fix: boxShadow sometimes not working on web by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7358](https://github.com/software-mansion/react-native-reanimated/pull/7358)
- chore: Bump RN to 0.79 by [@MatiPl01](https://github.com/MatiPl01) in [#7322](https://github.com/software-mansion/react-native-reanimated/pull/7322)
- release: 3.17.3 by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7361](https://github.com/software-mansion/react-native-reanimated/pull/7361)

### 3.17.2
#### What's Changed
- chore(Reanimated3): fix CI by [@tjzel](https://github.com/tjzel) in [#7244](https://github.com/software-mansion/react-native-reanimated/pull/7244)
- chore(Reanimated3):cherry-pick [#7197](https://github.com/software-mansion/react-native-reanimated/pull/7197) by [@tjzel](https://github.com/tjzel) in [#7235](https://github.com/software-mansion/react-native-reanimated/pull/7235)
- chore(Reanimated3):cherry-pick [#7196](https://github.com/software-mansion/react-native-reanimated/pull/7196) by [@tjzel](https://github.com/tjzel) in [#7236](https://github.com/software-mansion/react-native-reanimated/pull/7236)
- backport: Add warning for unsupported layout animation props ([#7135](https://github.com/software-mansion/react-native-reanimated/pull/7135)) by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7273](https://github.com/software-mansion/react-native-reanimated/pull/7273)
- backport: Add suport for animatedProps by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7284](https://github.com/software-mansion/react-native-reanimated/pull/7284)
- chore(Reanimated3): cherry-pick [#7269](https://github.com/software-mansion/react-native-reanimated/pull/7269) by [@tjzel](https://github.com/tjzel) in [#7314](https://github.com/software-mansion/react-native-reanimated/pull/7314)
- chore(Reanimated3): cherry-pick [#7266](https://github.com/software-mansion/react-native-reanimated/pull/7266) by [@tjzel](https://github.com/tjzel) in [#7315](https://github.com/software-mansion/react-native-reanimated/pull/7315)
- cherry-pick: Remove non-layout style and prop updates path via `synchronouslyUpdatePropsOnUIThread` by [@tomekzaw](https://github.com/tomekzaw) in [#7313](https://github.com/software-mansion/react-native-reanimated/pull/7313)
- (chery-pick) prevent flattening style arrays by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7327](https://github.com/software-mansion/react-native-reanimated/pull/7327)
- Cherry pick [#7292](https://github.com/software-mansion/react-native-reanimated/pull/7292) by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#7319](https://github.com/software-mansion/react-native-reanimated/pull/7319)
- cherry-pick: fix: Impossibility to remove layout transitions by [@MatiPl01](https://github.com/MatiPl01) in [#7310](https://github.com/software-mansion/react-native-reanimated/pull/7310)
- Cherry pick [#6958](https://github.com/software-mansion/react-native-reanimated/pull/6958) by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#7320](https://github.com/software-mansion/react-native-reanimated/pull/7320)
- Backport react-freeze fixes by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#7316](https://github.com/software-mansion/react-native-reanimated/pull/7316)
- cherry-pick: fix: Crash caused by passing animated ref to the animate component by [@MatiPl01](https://github.com/MatiPl01) in [#7309](https://github.com/software-mansion/react-native-reanimated/pull/7309)
- release: 3.17.2 by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7332](https://github.com/software-mansion/react-native-reanimated/pull/7332)

### 3.17.1
#### What's Changed
- chore: Add support for React 19 and RN 0.78 with backward compatibility by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#7089](https://github.com/software-mansion/react-native-reanimated/pull/7089)
- release: 3.17.1 by [@MatiPl01](https://github.com/MatiPl01) in [#7132](https://github.com/software-mansion/react-native-reanimated/pull/7132)

### 3.17.0
#### Key changes compared to 3.16.7
- Partial separation of Worklets and Reanimated
- Support React Native 0.78-rc.3 [#6934](https://github.com/software-mansion/react-native-reanimated/pull/6934)
- Fixes for Layout Animations on Fabric
- Fixes for circular dependencies resulting in slight memory leaks on reload [#6850](https://github.com/software-mansion/react-native-reanimated/pull/6850)
- Support for LAB color interpolation [#6782](https://github.com/software-mansion/react-native-reanimated/pull/6782)
- Support for `boxShadow` property [#6749](https://github.com/software-mansion/react-native-reanimated/pull/6749)
- Support for multiple worklet referencing in Reanimated Babel Plugin [#6904](https://github.com/software-mansion/react-native-reanimated/pull/6904)
- Support for Android's edge-to-edge [#6732](https://github.com/software-mansion/react-native-reanimated/pull/6732)
#### What's Changed
- Update ReducedMotionConfig.mdx by [@mzaien](https://github.com/mzaien) in [#6598](https://github.com/software-mansion/react-native-reanimated/pull/6598)
- Fix crash on macos when using Layout Animations by [@Latropos](https://github.com/Latropos) in [#6600](https://github.com/software-mansion/react-native-reanimated/pull/6600)
- Fix `CallInvokerHolderImpl` backwards compatibility by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6601](https://github.com/software-mansion/react-native-reanimated/pull/6601)
- Bump reanimated version to 3.17.0 by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6609](https://github.com/software-mansion/react-native-reanimated/pull/6609)
- docs: Restore logger docs changes after release by [@MatiPl01](https://github.com/MatiPl01) in [#6608](https://github.com/software-mansion/react-native-reanimated/pull/6608)
- Update Podfile.locks by [@tomekzaw](https://github.com/tomekzaw) in [#6610](https://github.com/software-mansion/react-native-reanimated/pull/6610)
- Move headers to `apple` directory by [@tomekzaw](https://github.com/tomekzaw) in [#6612](https://github.com/software-mansion/react-native-reanimated/pull/6612)
- Remove `config[:reanimated_node_modules_dir]` in reanimated_utils.rb by [@tomekzaw](https://github.com/tomekzaw) in [#6611](https://github.com/software-mansion/react-native-reanimated/pull/6611)
- Fix static linking on iOS by [@tomekzaw](https://github.com/tomekzaw) in [#6614](https://github.com/software-mansion/react-native-reanimated/pull/6614)
- Do not make a synchronous call when canceling animation. by [@Szymon20000](https://github.com/Szymon20000) in [#6564](https://github.com/software-mansion/react-native-reanimated/pull/6564)
- refactor(Worklets): Merge TypeScript type files by [@tjzel](https://github.com/tjzel) in [#6556](https://github.com/software-mansion/react-native-reanimated/pull/6556)
- chore: Silence next-example linter warnings by [@tjzel](https://github.com/tjzel) in [#6633](https://github.com/software-mansion/react-native-reanimated/pull/6633)
- [LA] Update window update check by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6618](https://github.com/software-mansion/react-native-reanimated/pull/6618)
- fix: Side effects paths in package.json by [@MatiPl01](https://github.com/MatiPl01) in [#6634](https://github.com/software-mansion/react-native-reanimated/pull/6634)
- fix: create symlink to common-app by [@jakex7](https://github.com/jakex7) in [#6637](https://github.com/software-mansion/react-native-reanimated/pull/6637)
- fix: Installation of Reanimated from commit on CI by [@tjzel](https://github.com/tjzel) in [#6635](https://github.com/software-mansion/react-native-reanimated/pull/6635)
- refactor(Worklets): JavaScript NativeReanimatedModule by [@tjzel](https://github.com/tjzel) in [#6557](https://github.com/software-mansion/react-native-reanimated/pull/6557)
- fix: Invalid shared value access displaying when code is correct by [@MatiPl01](https://github.com/MatiPl01) in [#6631](https://github.com/software-mansion/react-native-reanimated/pull/6631)
- fix: Return value of set-reanimated-version.js script by [@tjzel](https://github.com/tjzel) in [#6649](https://github.com/software-mansion/react-native-reanimated/pull/6649)
- Add warning when passing incorrect transformOrigin by [@Latropos](https://github.com/Latropos) in [#6602](https://github.com/software-mansion/react-native-reanimated/pull/6602)
- refactor: Specify each example app workspace by [@tjzel](https://github.com/tjzel) in [#6652](https://github.com/software-mansion/react-native-reanimated/pull/6652)
- chore: Redo tvos example for 0.76 by [@tjzel](https://github.com/tjzel) in [#6654](https://github.com/software-mansion/react-native-reanimated/pull/6654)
- chore(Worklets): Add worklets validation to scripts by [@tjzel](https://github.com/tjzel) in [#6651](https://github.com/software-mansion/react-native-reanimated/pull/6651)
- chore: Add noop typescript worklets module by [@tjzel](https://github.com/tjzel) in [#6650](https://github.com/software-mansion/react-native-reanimated/pull/6650)
- chore: Bump macos example to 0.75 by [@tjzel](https://github.com/tjzel) in [#6653](https://github.com/software-mansion/react-native-reanimated/pull/6653)
- Bump React Native to 0.76 in example apps by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6636](https://github.com/software-mansion/react-native-reanimated/pull/6636)
- chore: Remove duplicated yarn by [@tjzel](https://github.com/tjzel) in [#6656](https://github.com/software-mansion/react-native-reanimated/pull/6656)
- chore(deps): bump rexml from 3.3.6 to 3.3.9 in /apps/paper-example by [@dependabot](https://github.com/dependabot) in [#6643](https://github.com/software-mansion/react-native-reanimated/pull/6643)
- chore(deps): bump http-proxy-middleware from 2.0.6 to 2.0.7 in /packages/docs-reanimated by [@dependabot](https://github.com/dependabot) in [#6638](https://github.com/software-mansion/react-native-reanimated/pull/6638)
- docs: Manage system color scheme changes by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6627](https://github.com/software-mansion/react-native-reanimated/pull/6627)
- chore(deps): bump rexml from 3.3.6 to 3.3.9 in /apps/fabric-example by [@dependabot](https://github.com/dependabot) in [#6662](https://github.com/software-mansion/react-native-reanimated/pull/6662)
- chore: Align with react-native@0.74 as oldest supported version by [@tjzel](https://github.com/tjzel) in [#6629](https://github.com/software-mansion/react-native-reanimated/pull/6629)
- fixed a typo— "grater" by [@akshar-dave](https://github.com/akshar-dave) in [#6675](https://github.com/software-mansion/react-native-reanimated/pull/6675)
- chore: Add pod install(update) to each app build script by [@tjzel](https://github.com/tjzel) in [#6575](https://github.com/software-mansion/react-native-reanimated/pull/6575)
- useAnimatedKeyboard fixes (iOS) by [@mhoran](https://github.com/mhoran) in [#6755](https://github.com/software-mansion/react-native-reanimated/pull/6755)
- chore: Remove dead code for RN 73 and below by [@tjzel](https://github.com/tjzel) in [#6658](https://github.com/software-mansion/react-native-reanimated/pull/6658)
- docs: update landing copy by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6695](https://github.com/software-mansion/react-native-reanimated/pull/6695)
- chore: migrate to screens v4 and navigation v7 by [@alduzy](https://github.com/alduzy) in [#6622](https://github.com/software-mansion/react-native-reanimated/pull/6622)
- chore: Bump web example to 0.76 by [@alduzy](https://github.com/alduzy) in [#6679](https://github.com/software-mansion/react-native-reanimated/pull/6679)
- chore: Use updated MetroConfig type by [@tjzel](https://github.com/tjzel) in [#6717](https://github.com/software-mansion/react-native-reanimated/pull/6717)
- fix: missing headers on new arch by [@WoLewicki](https://github.com/WoLewicki) in [#6725](https://github.com/software-mansion/react-native-reanimated/pull/6725)
- Support for multiple surfaces on Fabric by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6647](https://github.com/software-mansion/react-native-reanimated/pull/6647)
- fix(example): Reloading to crashing screen by [@tjzel](https://github.com/tjzel) in [#6689](https://github.com/software-mansion/react-native-reanimated/pull/6689)
- chore: Remove reference for 0.72 tests on CI by [@tjzel](https://github.com/tjzel) in [#6716](https://github.com/software-mansion/react-native-reanimated/pull/6716)
- Add name to the Reanimated Plugin by [@tjzel](https://github.com/tjzel) in [#6705](https://github.com/software-mansion/react-native-reanimated/pull/6705)
- fix: Allow TypeScript in worklet classes by [@tjzel](https://github.com/tjzel) in [#6667](https://github.com/software-mansion/react-native-reanimated/pull/6667)
- chore: Describe `isWorkletRuntime` behavior on different runtimes by [@tjzel](https://github.com/tjzel) in [#6692](https://github.com/software-mansion/react-native-reanimated/pull/6692)
- Add fallback detection methods for Worklet Classes by [@tjzel](https://github.com/tjzel) in [#6706](https://github.com/software-mansion/react-native-reanimated/pull/6706)
- fix: Animation assignment with compiler-safe API by [@tjzel](https://github.com/tjzel) in [#6715](https://github.com/software-mansion/react-native-reanimated/pull/6715)
- feat(Worklets): Create a stub of Worklets Module by [@tjzel](https://github.com/tjzel) in [#6539](https://github.com/software-mansion/react-native-reanimated/pull/6539)
- release: 3.17.0-rc.0 by [@tjzel](https://github.com/tjzel) in [#6731](https://github.com/software-mansion/react-native-reanimated/pull/6731)
- release: 3.17.0-rc.1 by [@tjzel](https://github.com/tjzel) in [#6819](https://github.com/software-mansion/react-native-reanimated/pull/6819)
- chore: cherry-pick commits for 3.17.0 release by [@tjzel](https://github.com/tjzel) in [#7038](https://github.com/software-mansion/react-native-reanimated/pull/7038)
- Backport changes to 3.17 by [@m-bert](https://github.com/m-bert) in [#7041](https://github.com/software-mansion/react-native-reanimated/pull/7041)
- chore: cherry-pick for 3.17.0 by [@tjzel](https://github.com/tjzel) in [#7039](https://github.com/software-mansion/react-native-reanimated/pull/7039)
- cherry-pick: Bump RN version to 0.77 stable by [@MatiPl01](https://github.com/MatiPl01) in [#7046](https://github.com/software-mansion/react-native-reanimated/pull/7046)
- cherry-pick: Add 0.78.0-rc.3 support by [@MatiPl01](https://github.com/MatiPl01) in [#7047](https://github.com/software-mansion/react-native-reanimated/pull/7047)
- Cherry-pick for 3.17.0 by [@tomekzaw](https://github.com/tomekzaw) in [#7050](https://github.com/software-mansion/react-native-reanimated/pull/7050)
- cherry-pick: Remove unused reference to runtime from requestRender method [#6953](https://github.com/software-mansion/react-native-reanimated/pull/6953) by [@piaskowyk](https://github.com/piaskowyk) in [#7057](https://github.com/software-mansion/react-native-reanimated/pull/7057)
- cherry-pick: Fix resolving ref to SVG components on Web [#6885](https://github.com/software-mansion/react-native-reanimated/pull/6885) by [@piaskowyk](https://github.com/piaskowyk) in [#7059](https://github.com/software-mansion/react-native-reanimated/pull/7059)
- cherry-pick: Remove REAInitializerRCTFabricSurface [#6837](https://github.com/software-mansion/react-native-reanimated/pull/6837) by [@piaskowyk](https://github.com/piaskowyk) in [#7060](https://github.com/software-mansion/react-native-reanimated/pull/7060)
- cherry-pick: Handle component internal animated ref [#7054](https://github.com/software-mansion/react-native-reanimated/pull/7054) by [@piaskowyk](https://github.com/piaskowyk) in [#7063](https://github.com/software-mansion/react-native-reanimated/pull/7063)
- cherry-pick: Fix getAnimatedStyle error when called with component that doesn't have animated styles [#6746](https://github.com/software-mansion/react-native-reanimated/pull/6746) by [@piaskowyk](https://github.com/piaskowyk) in [#7080](https://github.com/software-mansion/react-native-reanimated/pull/7080)
- chore: cherry-pick for 3.17.0 by [@tjzel](https://github.com/tjzel) in [#7081](https://github.com/software-mansion/react-native-reanimated/pull/7081)
- chore: cherry-pick for 3.17.0 by [@tjzel](https://github.com/tjzel) in [#7082](https://github.com/software-mansion/react-native-reanimated/pull/7082)
- release: 3.17.0 by [@tjzel](https://github.com/tjzel) in [#7071](https://github.com/software-mansion/react-native-reanimated/pull/7071)
#### New Contributors
- [@mzaien](https://github.com/mzaien) made their first contribution in [#6598](https://github.com/software-mansion/react-native-reanimated/pull/6598)
- [@akshar-dave](https://github.com/akshar-dave) made their first contribution in [#6675](https://github.com/software-mansion/react-native-reanimated/pull/6675)

### 3.16.7
#### What's changed
- Support for React Native 0.77 by [@tomekzaw](https://github.com/tomekzaw) and [@piaskowyk](https://github.com/piaskowyk)
- Workaround for V8EXECUTOR_LIB NOTFOUND error in worklets CMakeLists.txt by [@dlee](https://github.com/dlee) in [#6603](https://github.com/software-mansion/react-native-reanimated/pull/6603)

### 3.16.6
#### What's changed
- fix layout animations initialization on the New Architecture by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) ([#6841](https://github.com/software-mansion/react-native-reanimated/pull/6841))

### 3.17.0-rc.1
#### Key changes
- Cache worklets - optimization [#6758](https://github.com/software-mansion/react-native-reanimated/pull/6758)
- Restoring JSInvoker everywhere [#6783](https://github.com/software-mansion/react-native-reanimated/pull/6783)

### 3.16.5
#### What's Changed
- Refactor findNodeHandler by [@piaskowyk](https://github.com/piaskowyk) in [#6736](https://github.com/software-mansion/react-native-reanimated/pull/6736)

### 3.16.4
#### What's Changed
- fix: brownfield integration in [#6774](https://github.com/software-mansion/react-native-reanimated/pull/6774) by [@WoLewicki](https://github.com/WoLewicki)
- fix: Empty array & null checks in handleTabNavigatorChange method fixes [#6698](https://github.com/software-mansion/react-native-reanimated/issues/6698) in [#6700](https://github.com/software-mansion/react-native-reanimated/pull/6700) by [@aymather](https://github.com/aymather)
- Fix crash caused by using ShareableHandle in multiple remote runtimes in [#6796](https://github.com/software-mansion/react-native-reanimated/pull/6796) by [@tomekzaw](https://github.com/tomekzaw)
- Clear `operationsInBatch_` before terminating UI runtime in [#6779](https://github.com/software-mansion/react-native-reanimated/pull/6779) by [@tomekzaw](https://github.com/tomekzaw)

### 3.16.3
#### What's Changed
- Restoring `jsxRuntime: classic` when building Reanimated module output with `react-native-builder-bob` for NativeWind support [#6760](https://github.com/software-mansion/react-native-reanimated/pull/6760)
- Adding mocks for `get` `set` API for mutables [#6742](https://github.com/software-mansion/react-native-reanimated/pull/6742)
- Fixing `sideEffects` paths for web support [#6634](https://github.com/software-mansion/react-native-reanimated/pull/6634)
- Fixing unnecessary warning [#6631](https://github.com/software-mansion/react-native-reanimated/pull/6631)
- release: 3.16.3 by [@tjzel](https://github.com/tjzel) in [#6761](https://github.com/software-mansion/react-native-reanimated/pull/6761)

### 3.17.0-rc.0

#### What's changed
This RC release focuses mostly on new native module `WorkletsModule` and is a significant milestone in our effort to split Worklets and Reanimated.

Key pull request:
- feat(Worklets): Create a stub of Worklets Module by [@tjzel](https://github.com/tjzel) in [#6539](https://github.com/software-mansion/react-native-reanimated/pull/6539)

#### What's Changed
- Update ReducedMotionConfig.mdx by [@mzaien](https://github.com/mzaien) in [#6598](https://github.com/software-mansion/react-native-reanimated/pull/6598)
- Fix crash on macos when using Layout Animations by [@Latropos](https://github.com/Latropos) in [#6600](https://github.com/software-mansion/react-native-reanimated/pull/6600)
- Fix `CallInvokerHolderImpl` backwards compatibility by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6601](https://github.com/software-mansion/react-native-reanimated/pull/6601)
- Bump reanimated version to 3.17.0 by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6609](https://github.com/software-mansion/react-native-reanimated/pull/6609)
- docs: Restore logger docs changes after release by [@MatiPl01](https://github.com/MatiPl01) in [#6608](https://github.com/software-mansion/react-native-reanimated/pull/6608)
- Update Podfile.locks by [@tomekzaw](https://github.com/tomekzaw) in [#6610](https://github.com/software-mansion/react-native-reanimated/pull/6610)
- Move headers to `apple` directory by [@tomekzaw](https://github.com/tomekzaw) in [#6612](https://github.com/software-mansion/react-native-reanimated/pull/6612)
- Remove `config[:reanimated_node_modules_dir]` in reanimated_utils.rb by [@tomekzaw](https://github.com/tomekzaw) in [#6611](https://github.com/software-mansion/react-native-reanimated/pull/6611)
- Fix static linking on iOS by [@tomekzaw](https://github.com/tomekzaw) in [#6614](https://github.com/software-mansion/react-native-reanimated/pull/6614)
- Do not make a synchronous call when canceling animation. by [@Szymon20000](https://github.com/Szymon20000) in [#6564](https://github.com/software-mansion/react-native-reanimated/pull/6564)
- refactor(Worklets): Merge TypeScript type files by [@tjzel](https://github.com/tjzel) in [#6556](https://github.com/software-mansion/react-native-reanimated/pull/6556)
- chore: Silence next-example linter warnings by [@tjzel](https://github.com/tjzel) in [#6633](https://github.com/software-mansion/react-native-reanimated/pull/6633)
- [LA] Update window update check by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6618](https://github.com/software-mansion/react-native-reanimated/pull/6618)
- fix: Side effects paths in package.json by [@MatiPl01](https://github.com/MatiPl01) in [#6634](https://github.com/software-mansion/react-native-reanimated/pull/6634)
- fix: create symlink to common-app by [@jakex7](https://github.com/jakex7) in [#6637](https://github.com/software-mansion/react-native-reanimated/pull/6637)
- fix: Installation of Reanimated from commit on CI by [@tjzel](https://github.com/tjzel) in [#6635](https://github.com/software-mansion/react-native-reanimated/pull/6635)
- refactor(Worklets): JavaScript NativeReanimatedModule by [@tjzel](https://github.com/tjzel) in [#6557](https://github.com/software-mansion/react-native-reanimated/pull/6557)
- fix: Invalid shared value access displaying when code is correct by [@MatiPl01](https://github.com/MatiPl01) in [#6631](https://github.com/software-mansion/react-native-reanimated/pull/6631)
- fix: Return value of set-reanimated-version.js script by [@tjzel](https://github.com/tjzel) in [#6649](https://github.com/software-mansion/react-native-reanimated/pull/6649)
- Add warning when passing incorrect transformOrigin by [@Latropos](https://github.com/Latropos) in [#6602](https://github.com/software-mansion/react-native-reanimated/pull/6602)
- refactor: Specify each example app workspace by [@tjzel](https://github.com/tjzel) in [#6652](https://github.com/software-mansion/react-native-reanimated/pull/6652)
- chore: Redo tvos example for 0.76 by [@tjzel](https://github.com/tjzel) in [#6654](https://github.com/software-mansion/react-native-reanimated/pull/6654)
- chore(Worklets): Add worklets validation to scripts by [@tjzel](https://github.com/tjzel) in [#6651](https://github.com/software-mansion/react-native-reanimated/pull/6651)
- chore: Add noop typescript worklets module by [@tjzel](https://github.com/tjzel) in [#6650](https://github.com/software-mansion/react-native-reanimated/pull/6650)
- chore: Bump macos example to 0.75 by [@tjzel](https://github.com/tjzel) in [#6653](https://github.com/software-mansion/react-native-reanimated/pull/6653)
- Bump React Native to 0.76 in example apps by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6636](https://github.com/software-mansion/react-native-reanimated/pull/6636)
- chore: Remove duplicated yarn by [@tjzel](https://github.com/tjzel) in [#6656](https://github.com/software-mansion/react-native-reanimated/pull/6656)
- chore(deps): bump rexml from 3.3.6 to 3.3.9 in /apps/paper-example by [@dependabot](https://github.com/dependabot) in [#6643](https://github.com/software-mansion/react-native-reanimated/pull/6643)
- chore(deps): bump http-proxy-middleware from 2.0.6 to 2.0.7 in /packages/docs-reanimated by [@dependabot](https://github.com/dependabot) in [#6638](https://github.com/software-mansion/react-native-reanimated/pull/6638)
- docs: Manage system color scheme changes by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6627](https://github.com/software-mansion/react-native-reanimated/pull/6627)
- chore(deps): bump rexml from 3.3.6 to 3.3.9 in /apps/fabric-example by [@dependabot](https://github.com/dependabot) in [#6662](https://github.com/software-mansion/react-native-reanimated/pull/6662)
- chore: Align with react-native@0.74 as oldest supported version by [@tjzel](https://github.com/tjzel) in [#6629](https://github.com/software-mansion/react-native-reanimated/pull/6629)
- fixed a typo— "grater" by [@akshar-dave](https://github.com/akshar-dave) in [#6675](https://github.com/software-mansion/react-native-reanimated/pull/6675)
- chore: Add pod install(update) to each app build script by [@tjzel](https://github.com/tjzel) in [#6575](https://github.com/software-mansion/react-native-reanimated/pull/6575)
- chore: Remove dead code for RN 73 and below by [@tjzel](https://github.com/tjzel) in [#6658](https://github.com/software-mansion/react-native-reanimated/pull/6658)
- docs: update landing copy by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6695](https://github.com/software-mansion/react-native-reanimated/pull/6695)
- chore: migrate to screens v4 and navigation v7 by [@alduzy](https://github.com/alduzy) in [#6622](https://github.com/software-mansion/react-native-reanimated/pull/6622)
- chore: Bump web example to 0.76 by [@alduzy](https://github.com/alduzy) in [#6679](https://github.com/software-mansion/react-native-reanimated/pull/6679)
- chore: Use updated MetroConfig type by [@tjzel](https://github.com/tjzel) in [#6717](https://github.com/software-mansion/react-native-reanimated/pull/6717)
- fix: missing headers on new arch by [@WoLewicki](https://github.com/WoLewicki) in [#6725](https://github.com/software-mansion/react-native-reanimated/pull/6725)
- Support for multiple surfaces on Fabric by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6647](https://github.com/software-mansion/react-native-reanimated/pull/6647)
- fix(example): Reloading to crashing screen by [@tjzel](https://github.com/tjzel) in [#6689](https://github.com/software-mansion/react-native-reanimated/pull/6689)
- chore: Remove reference for 0.72 tests on CI by [@tjzel](https://github.com/tjzel) in [#6716](https://github.com/software-mansion/react-native-reanimated/pull/6716)
- Add name to the Reanimated Plugin by [@tjzel](https://github.com/tjzel) in [#6705](https://github.com/software-mansion/react-native-reanimated/pull/6705)
- fix: Allow TypeScript in worklet classes by [@tjzel](https://github.com/tjzel) in [#6667](https://github.com/software-mansion/react-native-reanimated/pull/6667)
- chore: Describe `isWorkletRuntime` behavior on different runtimes by [@tjzel](https://github.com/tjzel) in [#6692](https://github.com/software-mansion/react-native-reanimated/pull/6692)
- Add fallback detection methods for Worklet Classes by [@tjzel](https://github.com/tjzel) in [#6706](https://github.com/software-mansion/react-native-reanimated/pull/6706)
- fix: Animation assignment with compiler-safe API by [@tjzel](https://github.com/tjzel) in [#6715](https://github.com/software-mansion/react-native-reanimated/pull/6715)
- feat(Worklets): Create a stub of Worklets Module by [@tjzel](https://github.com/tjzel) in [#6539](https://github.com/software-mansion/react-native-reanimated/pull/6539)
- release: 3.17.0-rc.0 by [@tjzel](https://github.com/tjzel) in [#6731](https://github.com/software-mansion/react-native-reanimated/pull/6731)
#### New Contributors
- [@mzaien](https://github.com/mzaien) made their first contribution in [#6598](https://github.com/software-mansion/react-native-reanimated/pull/6598)
- [@akshar-dave](https://github.com/akshar-dave) made their first contribution in [#6675](https://github.com/software-mansion/react-native-reanimated/pull/6675)

### 3.16.2
#### Key changes
- Fix for the new `useSharedValue` get/set API not working properly with `with*` animation assignments: [#6715](https://github.com/software-mansion/react-native-reanimated/pull/6715)
- Adding fallback methods for better detection of Worklet Classes [#6706](https://github.com/software-mansion/react-native-reanimated/pull/6706)
- Fix for crashing on TypeScript tokens in Worklet Classes [#6667](https://github.com/software-mansion/react-native-reanimated/pull/6667)

### 3.16.1
Fixes `USE_FRAMEWORKS=static` on iOS.

### 3.16.0
#### Features
- Support React Native 0.76 by [@tomekzaw](https://github.com/tomekzaw) in [#6499](https://github.com/software-mansion/react-native-reanimated/pull/6499)
- Add react-compiler safe API to mutables by [@tjzel](https://github.com/tjzel) in [#6312](https://github.com/software-mansion/react-native-reanimated/pull/6312)
- [Web LA] Add `skipEntering` by [@m-bert](https://github.com/m-bert) in [#6425](https://github.com/software-mansion/react-native-reanimated/pull/6425)
- Implement better reanimated logger with clean stack traces by [@MatiPl01](https://github.com/MatiPl01) in [#6385](https://github.com/software-mansion/react-native-reanimated/pull/6385)
- Use new logger and ReanimatedError for lib warnings and errors by [@MatiPl01](https://github.com/MatiPl01) in [#6387](https://github.com/software-mansion/react-native-reanimated/pull/6387)
- add support for isNavigationBarTranslucentAndroid by [@maciekstosio](https://github.com/maciekstosio) in [#6431](https://github.com/software-mansion/react-native-reanimated/pull/6431)
- Expose BaseLayoutAnimationConfig by [@tjzel](https://github.com/tjzel) in [#6558](https://github.com/software-mansion/react-native-reanimated/pull/6558)

#### Fixes

- Implement missing measurements on android by [@Latropos](https://github.com/Latropos) in [#6413](https://github.com/software-mansion/react-native-reanimated/pull/6413)
- [Web] Add `findNodeHandle` web version by [@m-bert](https://github.com/m-bert) in [#6403](https://github.com/software-mansion/react-native-reanimated/pull/6403)
- Don't update view tag when null by [@j-piasecki](https://github.com/j-piasecki) in [#6353](https://github.com/software-mansion/react-native-reanimated/pull/6353)
- Fix colour comparison on Android by [@Latropos](https://github.com/Latropos) in [#6383](https://github.com/software-mansion/react-native-reanimated/pull/6383)
- Update RN pager view patch file by [@szydlovsky](https://github.com/szydlovsky) in [#6397](https://github.com/software-mansion/react-native-reanimated/pull/6397)
- fix: Chrome debugger crash caused by incorrect viewTag by [@MatiPl01](https://github.com/MatiPl01) in [#6437](https://github.com/software-mansion/react-native-reanimated/pull/6437)
- fix: add missing include by [@okwasniewski](https://github.com/okwasniewski) in [#6439](https://github.com/software-mansion/react-native-reanimated/pull/6439)
- Enable Clangd in repo by [@tjzel](https://github.com/tjzel) in [#6430](https://github.com/software-mansion/react-native-reanimated/pull/6430)
- Skip zero delay by [@Latropos](https://github.com/Latropos) in [#6398](https://github.com/software-mansion/react-native-reanimated/pull/6398)
- fix: Recursion in worklets by [@tjzel](https://github.com/tjzel) in [#6445](https://github.com/software-mansion/react-native-reanimated/pull/6445)
- Change `requestAnimationFrame` flush condition by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6442](https://github.com/software-mansion/react-native-reanimated/pull/6442)
- User-defined logger config by [@MatiPl01](https://github.com/MatiPl01) in [#6409](https://github.com/software-mansion/react-native-reanimated/pull/6409)
- Fix handling of layout animations coinciding with view flattening by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6460](https://github.com/software-mansion/react-native-reanimated/pull/6460)
- Fix issues with skipping reanimated commit by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6498](https://github.com/software-mansion/react-native-reanimated/pull/6498)
- Add useEvent mock by [@piaskowyk](https://github.com/piaskowyk) in [#6511](https://github.com/software-mansion/react-native-reanimated/pull/6511)
- fix: Add JavaScript wrappers to captured console to prevent crashes in React Native 0.75 by [@tjzel](https://github.com/tjzel) in [#6520](https://github.com/software-mansion/react-native-reanimated/pull/6520)
- chore: Change overlooked job name by [@tjzel](https://github.com/tjzel) in [#6525](https://github.com/software-mansion/react-native-reanimated/pull/6525)
- Fix wrong exiting animation indices [New Architecture] by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6526](https://github.com/software-mansion/react-native-reanimated/pull/6526)
- chore: Fix TypeScript issues for `react-native@0.76` by [@tjzel](https://github.com/tjzel) in [#6527](https://github.com/software-mansion/react-native-reanimated/pull/6527)
- Move `ReaLayoutAnimator` to a separate file by [@tomekzaw](https://github.com/tomekzaw) in [#6530](https://github.com/software-mansion/react-native-reanimated/pull/6530)
- Enable V8 nightly CI by [@piaskowyk](https://github.com/piaskowyk) in [#6533](https://github.com/software-mansion/react-native-reanimated/pull/6533)
- Fix broken links in documentation by [@piaskowyk](https://github.com/piaskowyk) in [#6535](https://github.com/software-mansion/react-native-reanimated/pull/6535)
- Fix getViewProp on Android, RN.74 by [@Latropos](https://github.com/Latropos) in [#6441](https://github.com/software-mansion/react-native-reanimated/pull/6441)
- fix: Restore backwards C++ compatibility for NDK23 by [@tjzel](https://github.com/tjzel) in [#6553](https://github.com/software-mansion/react-native-reanimated/pull/6553)
- Remove `resolveTaskFactory` in build.gradle by [@tomekzaw](https://github.com/tomekzaw) in [#6560](https://github.com/software-mansion/react-native-reanimated/pull/6560)
- Fix prefab headers by [@tomekzaw](https://github.com/tomekzaw) in [#6566](https://github.com/software-mansion/react-native-reanimated/pull/6566)
- Add SVG color properties to list of color attributes to parse by [@jakex7](https://github.com/jakex7) in [#6567](https://github.com/software-mansion/react-native-reanimated/pull/6567)
- Add `outlineColor` to ColorProperties list by [@jakex7](https://github.com/jakex7) in [#6568](https://github.com/software-mansion/react-native-reanimated/pull/6568)
- Bump React Native to 0.76.0-rc.3 by [@tomekzaw](https://github.com/tomekzaw) in [#6565](https://github.com/software-mansion/react-native-reanimated/pull/6565)
- Add `HostFunction` handling to `_scheduleOnJS` by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6571](https://github.com/software-mansion/react-native-reanimated/pull/6571)
- Add release dedicated GitHub Action by [@tjzel](https://github.com/tjzel) in [#6569](https://github.com/software-mansion/react-native-reanimated/pull/6569)
- Lazy initalize layout aniamtions in the Commit Hook by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6586](https://github.com/software-mansion/react-native-reanimated/pull/6586)
- Bump python version and freeze cpplint by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6587](https://github.com/software-mansion/react-native-reanimated/pull/6587)
- fix: build error with c++17 by [@jeanregisser](https://github.com/jeanregisser) in [#6590](https://github.com/software-mansion/react-native-reanimated/pull/6590)
- Use `Number` instead of `parseInt` by [@Latropos](https://github.com/Latropos) in [#6593](https://github.com/software-mansion/react-native-reanimated/pull/6593)
- Bump reanimated version to 3.16.0 by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6599](https://github.com/software-mansion/react-native-reanimated/pull/6599)

#### Docs changes

- docs: Add example to useHandler docs by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6369](https://github.com/software-mansion/react-native-reanimated/pull/6369)
- docs: Rewrite Custom Animations page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6346](https://github.com/software-mansion/react-native-reanimated/pull/6346)
- docs: Rewrite useAnimatedScrollHandler page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6374](https://github.com/software-mansion/react-native-reanimated/pull/6374)
- dosc: Rewrite useEvent page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6360](https://github.com/software-mansion/react-native-reanimated/pull/6360)
- docs: Move Platform Compatibility to MDXComponents by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6401](https://github.com/software-mansion/react-native-reanimated/pull/6401)
- docs: add `PlatformCompatibility` component by [@tomekzaw](https://github.com/tomekzaw) in [#6394](https://github.com/software-mansion/react-native-reanimated/pull/6394)
- docs: Fix text colors in docs examples by [@MatiPl01](https://github.com/MatiPl01) in [#6417](https://github.com/software-mansion/react-native-reanimated/pull/6417)
- docs: Fix incorrect links in docs by [@MatiPl01](https://github.com/MatiPl01) in [#6436](https://github.com/software-mansion/react-native-reanimated/pull/6436)
- docs: Styling for mobile Platform Compatibility by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6456](https://github.com/software-mansion/react-native-reanimated/pull/6456)
- docs: CurvedTransition typo by [@dynamichny](https://github.com/dynamichny) in [#6463](https://github.com/software-mansion/react-native-reanimated/pull/6463)
- docs: Fix `measure` InteracitveExample by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6452](https://github.com/software-mansion/react-native-reanimated/pull/6452)
- Extract logic to build the tests by [@Latropos](https://github.com/Latropos) in [#6408](https://github.com/software-mansion/react-native-reanimated/pull/6408)
- docs: Add metro config wrapper and reanimated logger docs by [@MatiPl01](https://github.com/MatiPl01) in [#6467](https://github.com/software-mansion/react-native-reanimated/pull/6467)
- docs: fix typos by [@shubh73](https://github.com/shubh73) in [#6402](https://github.com/software-mansion/react-native-reanimated/pull/6402)
- Add runtime tests for animations in StrictMode by [@piaskowyk](https://github.com/piaskowyk) in [#6305](https://github.com/software-mansion/react-native-reanimated/pull/6305)
- docs: Rewrite Shared Element Transition page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6455](https://github.com/software-mansion/react-native-reanimated/pull/6455)
- docs: Bump `@swmansion/t-rex-ui` to 0.0.14 by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6522](https://github.com/software-mansion/react-native-reanimated/pull/6522)
- More test cases - custom layout transitions by [@Latropos](https://github.com/Latropos) in [#6458](https://github.com/software-mansion/react-native-reanimated/pull/6458)
- docs: Rewrite Web Support page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6516](https://github.com/software-mansion/react-native-reanimated/pull/6516)
- docs: Add AvailableFrom label by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6523](https://github.com/software-mansion/react-native-reanimated/pull/6523)
- Fix layout animations flickering on Android [New Architecture] by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6518](https://github.com/software-mansion/react-native-reanimated/pull/6518)
- docs: Rewrite Testing with Jest page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6503](https://github.com/software-mansion/react-native-reanimated/pull/6503)
- docs: add Entering/Exiting Playground by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6468](https://github.com/software-mansion/react-native-reanimated/pull/6468)
- docs: Mark debugging docs as unreleased, remove recommended metro config step by [@MatiPl01](https://github.com/MatiPl01) in [#6529](https://github.com/software-mansion/react-native-reanimated/pull/6529)

#### Internal changes

- chore: Make GitHub actions names match their titles, cleanup by [@tjzel](https://github.com/tjzel) in [#6391](https://github.com/software-mansion/react-native-reanimated/pull/6391)
- Regenerate some test snapshots by [@Latropos](https://github.com/Latropos) in [#6382](https://github.com/software-mansion/react-native-reanimated/pull/6382)
- chore: Fix precommit script by [@tjzel](https://github.com/tjzel) in [#6407](https://github.com/software-mansion/react-native-reanimated/pull/6407)
- Remove duplicated logic of error tests by [@Latropos](https://github.com/Latropos) in [#6358](https://github.com/software-mansion/react-native-reanimated/pull/6358)
- refactor: Split Java and ObjC code into Reanimated and Worklets dirs by [@tjzel](https://github.com/tjzel) in [#6366](https://github.com/software-mansion/react-native-reanimated/pull/6366)
- chore: Bump RN to 0.75.2 in examples by [@tjzel](https://github.com/tjzel) in [#6464](https://github.com/software-mansion/react-native-reanimated/pull/6464)
- chore: Enforce the use of ReanimatedError instead of Error by [@MatiPl01](https://github.com/MatiPl01) in [#6454](https://github.com/software-mansion/react-native-reanimated/pull/6454)
- Fix keyframe types by [@Latropos](https://github.com/Latropos) in [#6438](https://github.com/software-mansion/react-native-reanimated/pull/6438)
- chore: Apply various native code cleanups by [@tjzel](https://github.com/tjzel) in [#6470](https://github.com/software-mansion/react-native-reanimated/pull/6470)
- Set CMake version on Android just like react-native by [@tomekzaw](https://github.com/tomekzaw) in [#6474](https://github.com/software-mansion/react-native-reanimated/pull/6474)
- Use string interpolation in `RNReanimated.podspec` by [@tomekzaw](https://github.com/tomekzaw) in [#6473](https://github.com/software-mansion/react-native-reanimated/pull/6473)
- chore: Remove codegen resolution by [@tjzel](https://github.com/tjzel) in [#6488](https://github.com/software-mansion/react-native-reanimated/pull/6488)
- chore: Bump prettier by [@tjzel](https://github.com/tjzel) in [#6486](https://github.com/software-mansion/react-native-reanimated/pull/6486)
- chore: Add separate tsconfig for metro-config by [@tjzel](https://github.com/tjzel) in [#6487](https://github.com/software-mansion/react-native-reanimated/pull/6487)
- chore: Fix codegen dir in examples by [@tjzel](https://github.com/tjzel) in [#6490](https://github.com/software-mansion/react-native-reanimated/pull/6490)
- chore: Bump react-native-builder-bob by [@tjzel](https://github.com/tjzel) in [#6485](https://github.com/software-mansion/react-native-reanimated/pull/6485)
- Monorepo Support: Use node resolver to locate React Native package by [@morganick](https://github.com/morganick) in [#6482](https://github.com/software-mansion/react-native-reanimated/pull/6482)
- chore: Enable TSDoc and JSDoc formatting by [@tjzel](https://github.com/tjzel) in [#6484](https://github.com/software-mansion/react-native-reanimated/pull/6484)
- chore: Enable .js TypeScript checks in repo by [@tjzel](https://github.com/tjzel) in [#6483](https://github.com/software-mansion/react-native-reanimated/pull/6483)
- chore: Fix deprecated `this` captures in lambdas for NDK 27 by [@tjzel](https://github.com/tjzel) in [#6495](https://github.com/software-mansion/react-native-reanimated/pull/6495)
- chore: Add `eslint-plugin-reanimated` build directory to .gitignore by [@tjzel](https://github.com/tjzel) in [#6493](https://github.com/software-mansion/react-native-reanimated/pull/6493)
- fix: Remove error-prone package.json addition from `react-native-builder-bob` by [@tjzel](https://github.com/tjzel) in [#6494](https://github.com/software-mansion/react-native-reanimated/pull/6494)
- chore(TypeScript): Add ViewDescriptorsWrapper type to fix types by [@tjzel](https://github.com/tjzel) in [#6481](https://github.com/software-mansion/react-native-reanimated/pull/6481)
- chore: Hotfix formatting by [@tjzel](https://github.com/tjzel) in [#6496](https://github.com/software-mansion/react-native-reanimated/pull/6496)
- chore: Enable strict mode by default, remove fatal log, add missing web check by [@MatiPl01](https://github.com/MatiPl01) in [#6477](https://github.com/software-mansion/react-native-reanimated/pull/6477)
- chore: Ignore comments in validation scripts by [@tjzel](https://github.com/tjzel) in [#6554](https://github.com/software-mansion/react-native-reanimated/pull/6554)
- chore: Bump prettier in docs by [@tjzel](https://github.com/tjzel) in [#6497](https://github.com/software-mansion/react-native-reanimated/pull/6497)
- refactor: Remove 'worklets' dependency on `NativeReanimatedModule` by [@tjzel](https://github.com/tjzel) in [#6357](https://github.com/software-mansion/react-native-reanimated/pull/6357)
- refactor: Less error prone `_value` in Mutables. by [@tjzel](https://github.com/tjzel) in [#6311](https://github.com/software-mansion/react-native-reanimated/pull/6311)
- Remove empty.cpp by [@tomekzaw](https://github.com/tomekzaw) in [#6540](https://github.com/software-mansion/react-native-reanimated/pull/6540)
- Convert double-quoted includes to angle includes by [@tomekzaw](https://github.com/tomekzaw) in [#6537](https://github.com/software-mansion/react-native-reanimated/pull/6537)
- refactor: Obtain JsCallInvoker directly from context by [@tjzel](https://github.com/tjzel) in [#6542](https://github.com/software-mansion/react-native-reanimated/pull/6542)
- Merge `packagingOptions` in build.gradle by [@tomekzaw](https://github.com/tomekzaw) in [#6541](https://github.com/software-mansion/react-native-reanimated/pull/6541)
- Convert all iOS includes to angle-bracket imports by [@tomekzaw](https://github.com/tomekzaw) in [#6543](https://github.com/software-mansion/react-native-reanimated/pull/6543)
- Change namespace `reanimated` to `worklets` by [@tomekzaw](https://github.com/tomekzaw) in [#6544](https://github.com/software-mansion/react-native-reanimated/pull/6544)
- Allow to fire compatibility check action with label by [@tjzel](https://github.com/tjzel) in [#6545](https://github.com/software-mansion/react-native-reanimated/pull/6545)
- fix: Remove path from Compatibility Action by [@tjzel](https://github.com/tjzel) in [#6547](https://github.com/software-mansion/react-native-reanimated/pull/6547)
- Move Android sources to `android/` subdirectory and update includes by [@tomekzaw](https://github.com/tomekzaw) in [#6549](https://github.com/software-mansion/react-native-reanimated/pull/6549)
- fix: Change import to uppercase by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6388](https://github.com/software-mansion/react-native-reanimated/pull/6388)
- [reJest] Migrate to use the new runtimetests API by [@Latropos](https://github.com/Latropos) in [#6356](https://github.com/software-mansion/react-native-reanimated/pull/6356)
- chore: Pretty pre-commit by [@tjzel](https://github.com/tjzel) in [#6423](https://github.com/software-mansion/react-native-reanimated/pull/6423)
- chore: Improve build pipeline of Reanimated Babel plugin by [@tjzel](https://github.com/tjzel) in [#6424](https://github.com/software-mansion/react-native-reanimated/pull/6424)
- chore: Rename LiquidSwipe Button by [@tjzel](https://github.com/tjzel) in [#6428](https://github.com/software-mansion/react-native-reanimated/pull/6428)
- chore: Upgrade React Native to 0.75.1 by [@tjzel](https://github.com/tjzel) in [#6420](https://github.com/software-mansion/react-native-reanimated/pull/6420)
- chore: Clean up reanimated logger and error implementation by [@MatiPl01](https://github.com/MatiPl01) in [#6453](https://github.com/software-mansion/react-native-reanimated/pull/6453)
- Add tests of keyframe animations by [@Latropos](https://github.com/Latropos) in [#6433](https://github.com/software-mansion/react-native-reanimated/pull/6433)
- Add Reanimated compatibility GitHub action by [@tjzel](https://github.com/tjzel) in [#6399](https://github.com/software-mansion/react-native-reanimated/pull/6399)
- Fix github workflows by [@Latropos](https://github.com/Latropos) in [#6412](https://github.com/software-mansion/react-native-reanimated/pull/6412)
- Add mutable value read/write during render warning by [@MatiPl01](https://github.com/MatiPl01) in [#6310](https://github.com/software-mansion/react-native-reanimated/pull/6310)
- Fix `inline style` tests in `Jest` by [@m-bert](https://github.com/m-bert) in [#6400](https://github.com/software-mansion/react-native-reanimated/pull/6400)
- Extract logic from TestRunner by [@Latropos](https://github.com/Latropos) in [#6390](https://github.com/software-mansion/react-native-reanimated/pull/6390)
- Add main branch protection scripts by [@tjzel](https://github.com/tjzel) in [#6555](https://github.com/software-mansion/react-native-reanimated/pull/6555)
#### New Contributors
- [@dynamichny](https://github.com/dynamichny) made their first contribution in [#6463](https://github.com/software-mansion/react-native-reanimated/pull/6463)
- [@morganick](https://github.com/morganick) made their first contribution in [#6482](https://github.com/software-mansion/react-native-reanimated/pull/6482)
- [@shubh73](https://github.com/shubh73) made their first contribution in [#6402](https://github.com/software-mansion/react-native-reanimated/pull/6402)
- [@jakex7](https://github.com/jakex7) made their first contribution in [#6567](https://github.com/software-mansion/react-native-reanimated/pull/6567)
- [@jeanregisser](https://github.com/jeanregisser) made their first contribution in [#6590](https://github.com/software-mansion/react-native-reanimated/pull/6590)

### 3.15.5
#### What's Changed
- Picking [#6590](https://github.com/software-mansion/react-native-reanimated/pull/6590). It fixes a typo which made 3.15.4 hotfix not work.

### 3.15.4
Restoring compatibility for NDK23.

### 3.15.3
New architecture bug fixes

### 3.15.2
Preliminary support for NDK 27

### 3.15.1
- [#6445](https://github.com/software-mansion/react-native-reanimated/pull/6445)
- [#6442](https://github.com/software-mansion/react-native-reanimated/pull/6442)

### 3.15.0

#### What's Changed

##### Features

- Add `ReducedMotionConfig` component by [@piaskowyk](https://github.com/piaskowyk) in [#6164](https://github.com/software-mansion/react-native-reanimated/pull/6164)
- [Web LA] Add `EntryExitTransition` by [@m-bert](https://github.com/m-bert) in [#6232](https://github.com/software-mansion/react-native-reanimated/pull/6232)
- Name every worklet function by [@tjzel](https://github.com/tjzel) in [#6163](https://github.com/software-mansion/react-native-reanimated/pull/6163)
- Workletize top-level functions in a file with 'worklet' directive by [@tjzel](https://github.com/tjzel) in [#5554](https://github.com/software-mansion/react-native-reanimated/pull/5554)
- Workletizable Context Objects by [@tjzel](https://github.com/tjzel) in [#6284](https://github.com/software-mansion/react-native-reanimated/pull/6284)
- [Web LA] Add `CurvedTransition` by [@m-bert](https://github.com/m-bert) in [#6239](https://github.com/software-mansion/react-native-reanimated/pull/6239)
- Workletizable Classes by [@tjzel](https://github.com/tjzel) in [#6230](https://github.com/software-mansion/react-native-reanimated/pull/6230)
- Expose `worklets` as prefab by [@tomekzaw](https://github.com/tomekzaw) in [#6372](https://github.com/software-mansion/react-native-reanimated/pull/6372)
- Support React Native 0.75 by [@tomekzaw](https://github.com/tomekzaw) in [#6185](https://github.com/software-mansion/react-native-reanimated/pull/6185)

##### Fixes

- Fix useSharedValue type definition in docs by [@MatiPl01](https://github.com/MatiPl01) in [#6260](https://github.com/software-mansion/react-native-reanimated/pull/6260)
- [Web] Fix missing RNRenderer export ([#6265](https://github.com/software-mansion/react-native-reanimated/issues/6265)) by [@lkinasiewicz](https://github.com/lkinasiewicz) in [#6266](https://github.com/software-mansion/react-native-reanimated/pull/6266)
- Prevent disabling cleanup in progress transitions on iOS by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6270](https://github.com/software-mansion/react-native-reanimated/pull/6270)
  mansion/react-native-reanimated/pull/6282
- [Web] Fix animations on Chromium 73 and older ([#6269](https://github.com/software-mansion/react-native-reanimated/issues/6269)) by [@lkinasiewicz](https://github.com/lkinasiewicz) in [#6271](https://github.com/software-mansion/react-native-reanimated/pull/6271)
- Fix Reduced Motion example by [@piaskowyk](https://github.com/piaskowyk) in [#6288](https://github.com/software-mansion/react-native-reanimated/pull/6288)
- fix: class factory included in sort by [@tjzel](https://github.com/tjzel) in [#6314](https://github.com/software-mansion/react-native-reanimated/pull/6314)
- [Web LA] Fix `easing` by [@m-bert](https://github.com/m-bert) in [#6304](https://github.com/software-mansion/react-native-reanimated/pull/6304)
- [Web LA] Start `exiting` after position fix by [@m-bert](https://github.com/m-bert) in [#6308](https://github.com/software-mansion/react-native-reanimated/pull/6308)
- fix: Plugin precommit script by [@tjzel](https://github.com/tjzel) in [#6328](https://github.com/software-mansion/react-native-reanimated/pull/6328)
- Fix `Remove` mutation parsing in Layout Animations by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6286](https://github.com/software-mansion/react-native-reanimated/pull/6286)
- Bugfix - don't require render in every test by [@Latropos](https://github.com/Latropos) in [#6318](https://github.com/software-mansion/react-native-reanimated/pull/6318)
- Fix spotless config by [@tomekzaw](https://github.com/tomekzaw) in [#6349](https://github.com/software-mansion/react-native-reanimated/pull/6349)
- fix: proper types for userAgent and vendor by [@WoLewicki](https://github.com/WoLewicki) in [#6361](https://github.com/software-mansion/react-native-reanimated/pull/6361)
- Fix handling UTF-8 object keys by [@coado](https://github.com/coado) in [#6373](https://github.com/software-mansion/react-native-reanimated/pull/6373)
- Fix pendulum example to not crash on empty mass input field by [@latekvo](https://github.com/latekvo) in [#6379](https://github.com/software-mansion/react-native-reanimated/pull/6379)
- Fix next js build CI by [@szydlovsky](https://github.com/szydlovsky) in [#6381](https://github.com/software-mansion/react-native-reanimated/pull/6381)
- fix: Light mode colors in the make mutable example in docs by [@MatiPl01](https://github.com/MatiPl01) in [#6375](https://github.com/software-mansion/react-native-reanimated/pull/6375)

##### Improvements

- Put back the README.md file in the npm package by [@piaskowyk](https://github.com/piaskowyk) in [#6256](https://github.com/software-mansion/react-native-reanimated/pull/6256)
- [Web LA] Fill in missing keyframes in default animations by [@m-bert](https://github.com/m-bert) in [#6259](https://github.com/software-mansion/react-native-reanimated/pull/6259)
- [Web LA] Add `withInitialValues` modifier by [@m-bert](https://github.com/m-bert) in [#6254](https://github.com/software-mansion/react-native-reanimated/pull/6254)
- Deprecate `combineTransition` by [@piaskowyk](https://github.com/piaskowyk) in [#6161](https://github.com/software-mansion/react-native-reanimated/pull/6161)
- chore: Reanimated package.json metadata tweaks by [@Simek](https://github.com/Simek) in [#6300](https://github.com/software-mansion/react-native-reanimated/pull/6300)
- Optimize Shadow Tree cloning by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6214](https://github.com/software-mansion/react-native-reanimated/pull/6214)
- Remove `ReanimatedHiddenHeaders`, `LoggerInterface` and `SpeedChecker` by [@tomekzaw](https://github.com/tomekzaw) in [#6363](https://github.com/software-mansion/react-native-reanimated/pull/6363)
- Modify reanimated props updates by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6330](https://github.com/software-mansion/react-native-reanimated/pull/6330)

##### Docs changes

- fix: docs: Access before initialization on withSpring and withTiming by [@patrycjakalinska](https://github.com/patrycjakalinska) in https://github.com/software-
- Extend plugin's documentation by [@tjzel](https://github.com/tjzel) in [#6227](https://github.com/software-mansion/react-native-reanimated/pull/6227)
- docs: Add Worklets page by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6257](https://github.com/software-mansion/react-native-reanimated/pull/6257)
- docs: Replace HireUsSection with `@swmansion/t-rex-ui` component by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6274](https://github.com/software-mansion/react-native-reanimated/pull/6274)
- Add `ReduceMotionConfig` docs by [@piaskowyk](https://github.com/piaskowyk) in [#6165](https://github.com/software-mansion/react-native-reanimated/pull/6165)
- docs: Rewrite getRelativeCoords documentation page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6249](https://github.com/software-mansion/react-native-reanimated/pull/6249)
- update layout transitions docs by [@Bayramito](https://github.com/Bayramito) in [#6275](https://github.com/software-mansion/react-native-reanimated/pull/6275)
- docs: Rewrite Keyframe Animations documentation page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6181](https://github.com/software-mansion/react-native-reanimated/pull/6181)
- Fix link to docs by [@piaskowyk](https://github.com/piaskowyk) in [#6303](https://github.com/software-mansion/react-native-reanimated/pull/6303)
- docs: Add WorkletContextObjects and WorkletClasses by [@tjzel](https://github.com/tjzel) in [#6309](https://github.com/software-mansion/react-native-reanimated/pull/6309)
- docs: Rewrite dispatchCommand page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6296](https://github.com/software-mansion/react-native-reanimated/pull/6296)
- docs: Recenter slider thumb by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6313](https://github.com/software-mansion/react-native-reanimated/pull/6313)
- Add list itemLayoutAnimation documentation page and example by [@MatiPl01](https://github.com/MatiPl01) in [#6279](https://github.com/software-mansion/react-native-reanimated/pull/6279)
- docs: Rewrite Layout Transition documentation page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6144](https://github.com/software-mansion/react-native-reanimated/pull/6144)
- docs: Add keyExtractor remark to itemLayoutAnimation documentation by [@MatiPl01](https://github.com/MatiPl01) in https://github.com/software-mansion/
- docs: Rewrite interpolateColor page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6332](https://github.com/software-mansion/react-native-reanimated/pull/6332)
- docs: update interpolate value argument description by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6347](https://github.com/software-mansion/react-native-reanimated/pull/6347)
- docs: add info about prebuild to installation steps by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6340](https://github.com/software-mansion/react-native-reanimated/pull/6340)
- docs: fix broken link in reanimated babel plugin docs by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6355](https://github.com/software-mansion/react-native-reanimated/pull/6355)
- docs: makeMutable documentation and examples by [@MatiPl01](https://github.com/MatiPl01) in [#6261](https://github.com/software-mansion/react-native-reanimated/pull/6261)
- docs: Rewrite useHandler page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6345](https://github.com/software-mansion/react-native-reanimated/pull/6345)
- docs: add disclaimer about ready-to-use packages in Reanimated Cookbook by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6182](https://github.com/software-mansion/react-native-reanimated/pull/6182)

##### Internal changes

- Improve `PerformanceMonitor`'s functionality by [@latekvo](https://github.com/latekvo) in [#6241](https://github.com/software-mansion/react-native-reanimated/pull/6241)
- Extract async code to separate classes by [@Latropos](https://github.com/Latropos) in [#6258](https://github.com/software-mansion/react-native-reanimated/pull/6258)
- [reJest] waitForAnimationUpdates by [@piaskowyk](https://github.com/piaskowyk) in [#6236](https://github.com/software-mansion/react-native-reanimated/pull/6236)
- [reJest] Use `waitForAnimationUpdates` instead of `wait` by [@piaskowyk](https://github.com/piaskowyk) in [#6237](https://github.com/software-mansion/react-native-reanimated/pull/6237)
- Introduce Import buttons to run tests more easily by [@Latropos](https://github.com/Latropos) in [#6216](https://github.com/software-mansion/react-native-reanimated/pull/6216)
- Fix fading snapshot by [@Latropos](https://github.com/Latropos) in [#6273](https://github.com/software-mansion/react-native-reanimated/pull/6273)
- [reJest] Fixes problem with opacity comparation by [@piaskowyk](https://github.com/piaskowyk) in [#6233](https://github.com/software-mansion/react-native-reanimated/pull/6233)
- refactor: Improve UX of runtime tests menu by [@tjzel](https://github.com/tjzel) in [#6283](https://github.com/software-mansion/react-native-reanimated/pull/6283)
- Improve formatting of snapnshot mismatch comparison by [@Latropos](https://github.com/Latropos) in [#6272](https://github.com/software-mansion/react-native-reanimated/pull/6272)
- Mock window dimensions by [@Latropos](https://github.com/Latropos) in [#6235](https://github.com/software-mansion/react-native-reanimated/pull/6235)
- Remove header to fix broken tests on android by [@Latropos](https://github.com/Latropos) in [#6289](https://github.com/software-mansion/react-native-reanimated/pull/6289)
- Fix function names by [@Latropos](https://github.com/Latropos) in [#6290](https://github.com/software-mansion/react-native-reanimated/pull/6290)
- Prefer `waitForAnimationUpdates` over `wait` by [@Latropos](https://github.com/Latropos) in [#6291](https://github.com/software-mansion/react-native-reanimated/pull/6291)
- Rename ReJest main folder by [@Latropos](https://github.com/Latropos) in [#6292](https://github.com/software-mansion/react-native-reanimated/pull/6292)
- Introduce file structure to tests by [@Latropos](https://github.com/Latropos) in [#6293](https://github.com/software-mansion/react-native-reanimated/pull/6293)
- Use seed in randomised tests by [@Latropos](https://github.com/Latropos) in [#6287](https://github.com/software-mansion/react-native-reanimated/pull/6287)
- fix: tests not included by default by [@tjzel](https://github.com/tjzel) in [#6306](https://github.com/software-mansion/react-native-reanimated/pull/6306)
- refactor: split makeMutable to web and native implementations by [@tjzel](https://github.com/tjzel) in [#6307](https://github.com/software-mansion/react-native-reanimated/pull/6307)
- chore: Add verbosity to precommit by [@tjzel](https://github.com/tjzel) in [#6336](https://github.com/software-mansion/react-native-reanimated/pull/6336)
- Bring back useFrameCallback cleanup by [@szydlovsky](https://github.com/szydlovsky) in [#6323](https://github.com/software-mansion/react-native-reanimated/pull/6323)
- refactor: Untangle types file dependencies by [@tjzel](https://github.com/tjzel) in [#6319](https://github.com/software-mansion/react-native-reanimated/pull/6319)
  react-native-reanimated/pull/6326
- refactor: Split cpp code base by [@tjzel](https://github.com/tjzel) in [#6329](https://github.com/software-mansion/react-native-reanimated/pull/6329)
- refactor: Split cmake and podspec for worklets by [@tjzel](https://github.com/tjzel) in [#6334](https://github.com/software-mansion/react-native-reanimated/pull/6334)
- Extract summary & logging from TestRunner. by [@Latropos](https://github.com/Latropos) in [#6297](https://github.com/software-mansion/react-native-reanimated/pull/6297)
- Move commonjs exports down for worklet files by [@tjzel](https://github.com/tjzel) in [#6316](https://github.com/software-mansion/react-native-reanimated/pull/6316)
- Unify snapshots comparison by [@Latropos](https://github.com/Latropos) in [#6295](https://github.com/software-mansion/react-native-reanimated/pull/6295)
- Extract `valueRegistry` from `TestRunner` by [@Latropos](https://github.com/Latropos) in [#6317](https://github.com/software-mansion/react-native-reanimated/pull/6317)
- Unify nullable comparison by [@Latropos](https://github.com/Latropos) in [#6344](https://github.com/software-mansion/react-native-reanimated/pull/6344)
- Test Layout Transition with size change by [@Latropos](https://github.com/Latropos) in [#6178](https://github.com/software-mansion/react-native-reanimated/pull/6178)
- Implement toThrow by [@Latropos](https://github.com/Latropos) in [#6267](https://github.com/software-mansion/react-native-reanimated/pull/6267)
- Print colors in tests 🎨 by [@Latropos](https://github.com/Latropos) in [#6327](https://github.com/software-mansion/react-native-reanimated/pull/6327)
- Extract `AnimationUpdatesRecorder` from `TestRunner` by [@Latropos](https://github.com/Latropos) in [#6342](https://github.com/software-mansion/react-native-reanimated/pull/6342)
- Extract `mockWindowDimensions` from `TestRunner` by [@Latropos](https://github.com/Latropos) in [#6343](https://github.com/software-mansion/react-native-reanimated/pull/6343)
- Remove fontawesome dependency from example app by [@szarbartosz](https://github.com/szarbartosz) in [#6184](https://github.com/software-mansion/react-native-reanimated/pull/6184)

#### New Contributors

[@Bayramito](https://github.com/Bayramito), [@Simek](https://github.com/Simek), [@szarbartosz](https://github.com/szarbartosz), [@coado](https://github.com/coado)

### 3.14.0

#### What's Changed
This release contains mainly community-requested bugfixes.

- [SET] instance check before invoking a method via reflection by [@piaskowyk](https://github.com/piaskowyk) in [#6211](https://github.com/software-mansion/react-native-reanimated/pull/6211)
- Remove unnecessary color processing in `interpolateColor` by [@szydlovsky](https://github.com/szydlovsky) in [#6213](https://github.com/software-mansion/react-native-reanimated/pull/6213)
- Fix duration of fading transition by [@Latropos](https://github.com/Latropos) in [#6174](https://github.com/software-mansion/react-native-reanimated/pull/6174)
- Revert dynamic styles PR by [@szydlovsky](https://github.com/szydlovsky) in [#6218](https://github.com/software-mansion/react-native-reanimated/pull/6218)
- Append `-Wpedantic` only for example apps by [@tomekzaw](https://github.com/tomekzaw) in [#6250](https://github.com/software-mansion/react-native-reanimated/pull/6250)

and more

#### New Contributors

- [@bohdanprog](https://github.com/bohdanprog)

### 3.13.0
#### What's Changed
##### Features
- Layout Animations for the New Architecture by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6055](https://github.com/software-mansion/react-native-reanimated/pull/6055)
- [Web LA] Add `JumpingTransition` by [@m-bert](https://github.com/m-bert) in [#6148](https://github.com/software-mansion/react-native-reanimated/pull/6148)
- [SET] Tab Navigator support by [@piaskowyk](https://github.com/piaskowyk) in [#5793](https://github.com/software-mansion/react-native-reanimated/pull/5793)
- [Web LA] Custom `Keyframe` animations by [@m-bert](https://github.com/m-bert) in [#6135](https://github.com/software-mansion/react-native-reanimated/pull/6135)
- Allow worklet referencing in plugin by [@tjzel](https://github.com/tjzel) in [#5911](https://github.com/software-mansion/react-native-reanimated/pull/5911)

##### Fixes
- Fix crash when current activity is null by [@maciekstosio](https://github.com/maciekstosio) in [#6022](https://github.com/software-mansion/react-native-reanimated/pull/6022)
- Fix missing imports for RN72 compatibility by [@gronxb](https://github.com/gronxb) in [#6097](https://github.com/software-mansion/react-native-reanimated/pull/6097) (PR had to be moved but credits to him)
- Fix configuring unconfigurable properties by [@tjzel](https://github.com/tjzel) in [#6098](https://github.com/software-mansion/react-native-reanimated/pull/6098)
- Fix mistakes in example app by [@maciekstosio](https://github.com/maciekstosio) in [#6099](https://github.com/software-mansion/react-native-reanimated/pull/6099)
- fix: getAnimatableRef on web by [@intergalacticspacehighway](https://github.com/intergalacticspacehighway) in [#6088](https://github.com/software-mansion/react-native-reanimated/pull/6088)
- Set default keyboard state by [@piaskowyk](https://github.com/piaskowyk) in [#6101](https://github.com/software-mansion/react-native-reanimated/pull/6101)
- Fixes of dark-theme and values in docs by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6058](https://github.com/software-mansion/react-native-reanimated/pull/6058)
- Make animated component's event tag properly update by [@szydlovsky](https://github.com/szydlovsky) in [#6030](https://github.com/software-mansion/react-native-reanimated/pull/6030)
- Fix slow animation mode on Android by [@piaskowyk](https://github.com/piaskowyk) in [#6014](https://github.com/software-mansion/react-native-reanimated/pull/6014)
- docs: Add missing dark themes by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6110](https://github.com/software-mansion/react-native-reanimated/pull/6110)
- docs: fix transparent sidebar by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6117](https://github.com/software-mansion/react-native-reanimated/pull/6117)
- Fix SET in Expo Go by [@piaskowyk](https://github.com/piaskowyk) in [#6116](https://github.com/software-mansion/react-native-reanimated/pull/6116)
- Fix broken link in documentation by [@piaskowyk](https://github.com/piaskowyk) in [#6120](https://github.com/software-mansion/react-native-reanimated/pull/6120)
- docs: Fix withTiming playground Power slider visibility by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6128](https://github.com/software-mansion/react-native-reanimated/pull/6128)
- [Web LA] Fix default transitions. by [@m-bert](https://github.com/m-bert) in [#6124](https://github.com/software-mansion/react-native-reanimated/pull/6124)
- Fix tree shaking in JSReanimated by [@tomekzaw](https://github.com/tomekzaw) in [#6130](https://github.com/software-mansion/react-native-reanimated/pull/6130)
- Fix useFrameCallback cleanup by [@szydlovsky](https://github.com/szydlovsky) in [#6143](https://github.com/software-mansion/react-native-reanimated/pull/6143)
- Fix web exiting animation in StrictMode by [@piaskowyk](https://github.com/piaskowyk) in [#6129](https://github.com/software-mansion/react-native-reanimated/pull/6129)
- Properly stringify tiny color values by [@swansontec](https://github.com/swansontec) in [#6153](https://github.com/software-mansion/react-native-reanimated/pull/6153)
- fix empty export on web by [@EvanBacon](https://github.com/EvanBacon) in [#6171](https://github.com/software-mansion/react-native-reanimated/pull/6171)
- Fix "Not implemented" exception with macros by [@tjzel](https://github.com/tjzel) in [#6137](https://github.com/software-mansion/react-native-reanimated/pull/6137)
- Fix FadingTransition by [@piaskowyk](https://github.com/piaskowyk) in [#6183](https://github.com/software-mansion/react-native-reanimated/pull/6183)
- [Web LA] Fix chrome flickers by [@m-bert](https://github.com/m-bert) in [#6172](https://github.com/software-mansion/react-native-reanimated/pull/6172)
- fix side effects by [@EvanBacon](https://github.com/EvanBacon) in [#6188](https://github.com/software-mansion/react-native-reanimated/pull/6188)

##### Improvements

- improved composed handler docs to match our standards by [@szydlovsky](https://github.com/szydlovsky) in [#6071](https://github.com/software-mansion/react-native-reanimated/pull/6071)
- docs: update compatibility table for fabric by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6068](https://github.com/software-mansion/react-native-reanimated/pull/6068)
- docs: remove redundant `'worklet';` in `useComposedEventHandler` by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6078](https://github.com/software-mansion/react-native-reanimated/pull/6078)
- docs(example): update readme with build step by [@frankcalise](https://github.com/frankcalise) in [#6089](https://github.com/software-mansion/react-native-reanimated/pull/6089)
- Add Slider example to Reanimated Cookbook by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6094](https://github.com/software-mansion/react-native-reanimated/pull/6094)
- docs: update Hire us to directly lead to contact form by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6087](https://github.com/software-mansion/react-native-reanimated/pull/6087)
- Add 2048 example by [@tomekzaw](https://github.com/tomekzaw) in [#6032](https://github.com/software-mansion/react-native-reanimated/pull/6032)
- [Web LA] Add warning about `transform` by [@m-bert](https://github.com/m-bert) in [#6064](https://github.com/software-mansion/react-native-reanimated/pull/6064)
- Adjust Playground dark theme by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6122](https://github.com/software-mansion/react-native-reanimated/pull/6122)
- docs: add contributing docs page by [@maciekstosio](https://github.com/maciekstosio) in [#6061](https://github.com/software-mansion/react-native-reanimated/pull/6061)
- docs: Adjust expandable code by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6133](https://github.com/software-mansion/react-native-reanimated/pull/6133)
- Add Floating Action Button example to Reanimated Cookbook by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6079](https://github.com/software-mansion/react-native-reanimated/pull/6079)
- Update useWorkletCallback.ts by [@vonovak](https://github.com/vonovak) in [#6140](https://github.com/software-mansion/react-native-reanimated/pull/6140)
- Remove `getJSValue` in favor of `toJSValue` by [@tomekzaw](https://github.com/tomekzaw) in [#6042](https://github.com/software-mansion/react-native-reanimated/pull/6042)
- Enable `-Wpedantic` flag on Android and use `std::vector` instead of VLA to pass arguments to `_scheduleOnJS` by [@tomekzaw](https://github.com/tomekzaw) in [#6157](https://github.com/software-mansion/react-native-reanimated/pull/6157)
- Add remark about reading SharedValue from the js thread by [@j-piasecki](https://github.com/j-piasecki) in [#6160](https://github.com/software-mansion/react-native-reanimated/pull/6160)
- docs: fix 'Edit this page' link by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6176](https://github.com/software-mansion/react-native-reanimated/pull/6176)
- docs: Edit this page button should go directly to edit page by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6177](https://github.com/software-mansion/react-native-reanimated/pull/6177)
- Fix lint error on main by [@tomekzaw](https://github.com/tomekzaw) in [#6179](https://github.com/software-mansion/react-native-reanimated/pull/6179)
- Strict DOM example by [@piaskowyk](https://github.com/piaskowyk) in [#6175](https://github.com/software-mansion/react-native-reanimated/pull/6175)
- [LA] Replace Layout Transitions example by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6151](https://github.com/software-mansion/react-native-reanimated/pull/6151)
- Merge ViewDescriptors implementation by [@piaskowyk](https://github.com/piaskowyk) in [#6123](https://github.com/software-mansion/react-native-reanimated/pull/6123)
- [LA] Replace Keyframe example by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6180](https://github.com/software-mansion/react-native-reanimated/pull/6180)

##### Internal Changes

- Monorepo by [@tjzel](https://github.com/tjzel) in [#5992](https://github.com/software-mansion/react-native-reanimated/pull/5992)
- Monorepo - move README by [@tjzel](https://github.com/tjzel) in [#6096](https://github.com/software-mansion/react-native-reanimated/pull/6096)
- Add missing unit tests (bezier, color converter, interpolate) by [@Latropos](https://github.com/Latropos) in [#6034](https://github.com/software-mansion/react-native-reanimated/pull/6034)
- Fix nightly build CI by [@szydlovsky](https://github.com/szydlovsky) in [#6106](https://github.com/software-mansion/react-native-reanimated/pull/6106)
- Make all links from Reanimated Cookbook relative by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6105](https://github.com/software-mansion/react-native-reanimated/pull/6105)
- Clean up docs from redundant files by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6104](https://github.com/software-mansion/react-native-reanimated/pull/6104)
- Fix and rename publish docs CI by [@szydlovsky](https://github.com/szydlovsky) in [#6108](https://github.com/software-mansion/react-native-reanimated/pull/6108)
- Fix one more path in docs publish CI by [@szydlovsky](https://github.com/szydlovsky) in [#6109](https://github.com/software-mansion/react-native-reanimated/pull/6109)
- Fix docs-check CI trigger path by [@szydlovsky](https://github.com/szydlovsky) in [#6112](https://github.com/software-mansion/react-native-reanimated/pull/6112)
- Fix `web-example` by [@m-bert](https://github.com/m-bert) in [#6111](https://github.com/software-mansion/react-native-reanimated/pull/6111)
- Screen transition example update - use proper import from screens instead of mock by [@piaskowyk](https://github.com/piaskowyk) in [#6118](https://github.com/software-mansion/react-native-reanimated/pull/6118)
- Fix eslint rules and types of tests by [@Latropos](https://github.com/Latropos) in [#6103](https://github.com/software-mansion/react-native-reanimated/pull/6103)
- Fix hot-reload in web-example by [@piaskowyk](https://github.com/piaskowyk) in [#6121](https://github.com/software-mansion/react-native-reanimated/pull/6121)
- Remove unused file by [@piaskowyk](https://github.com/piaskowyk) in [#6125](https://github.com/software-mansion/react-native-reanimated/pull/6125)
- Support snapshots of many views by [@Latropos](https://github.com/Latropos) in [#6047](https://github.com/software-mansion/react-native-reanimated/pull/6047)
- Remove redundant `jestUtils` file by [@tjzel](https://github.com/tjzel) in [#6138](https://github.com/software-mansion/react-native-reanimated/pull/6138)
- Use vanilla `babel.config.js` in plugin's unit tests by [@tjzel](https://github.com/tjzel) in [#6139](https://github.com/software-mansion/react-native-reanimated/pull/6139)
- Run formatter by [@piaskowyk](https://github.com/piaskowyk) in [#6142](https://github.com/software-mansion/react-native-reanimated/pull/6142)
- Fix C++ linter on CI by [@piaskowyk](https://github.com/piaskowyk) in [#6147](https://github.com/software-mansion/react-native-reanimated/pull/6147)
- Add tests of predefined exiting by [@Latropos](https://github.com/Latropos) in [#6136](https://github.com/software-mansion/react-native-reanimated/pull/6136)
- Make `close when stale` time 14 days by [@szydlovsky](https://github.com/szydlovsky) in [#6152](https://github.com/software-mansion/react-native-reanimated/pull/6152)
- Add tests of "withSequence" and clean up imports by [@Latropos](https://github.com/Latropos) in [#6050](https://github.com/software-mansion/react-native-reanimated/pull/6050)
- Tests of `withDelay` by [@Latropos](https://github.com/Latropos) in [#6150](https://github.com/software-mansion/react-native-reanimated/pull/6150)
- Fix all autoFixable problems inside app/common by [@Latropos](https://github.com/Latropos) in [#6162](https://github.com/software-mansion/react-native-reanimated/pull/6162)
- Layout Transition test by [@Latropos](https://github.com/Latropos) in [#6168](https://github.com/software-mansion/react-native-reanimated/pull/6168)
- Delete duplicate `gradle-wrapper.properties` by [@tomekzaw](https://github.com/tomekzaw) in [#6187](https://github.com/software-mansion/react-native-reanimated/pull/6187)
- docs: Move ExampleVideo to MDXComponents by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6145](https://github.com/software-mansion/react-native-reanimated/pull/6145)
- docs: bump `@swmansion/t-rex-ui` to 0.0.12 by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6169](https://github.com/software-mansion/react-native-reanimated/pull/6169)
- Testing colors by [@Latropos](https://github.com/Latropos) in [#6193](https://github.com/software-mansion/react-native-reanimated/pull/6193)

#### New Contributors
[@intergalacticspacehighway](https://github.com/intergalacticspacehighway) [@swansontec](https://github.com/swansontec) [@gronxb](https://github.com/gronxb)

### 3.12.1

### 3.13.0-rc.2
#### What's Changed
- Fix crash when current activity is null by [@maciekstosio](https://github.com/maciekstosio) in [#6022](https://github.com/software-mansion/react-native-reanimated/pull/6022)
- improved composed handler docs to match our standards by [@szydlovsky](https://github.com/szydlovsky) in [#6071](https://github.com/software-mansion/react-native-reanimated/pull/6071)
- docs: update compatibility table for fabric by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6068](https://github.com/software-mansion/react-native-reanimated/pull/6068)
- Monorepo by [@tjzel](https://github.com/tjzel) in [#5992](https://github.com/software-mansion/react-native-reanimated/pull/5992)
- Bump rexml from 3.2.6 to 3.2.9 in /apps/tvos-example by [@dependabot](https://github.com/dependabot) in [#6095](https://github.com/software-mansion/react-native-reanimated/pull/6095)
- Monorepo - move README by [@tjzel](https://github.com/tjzel) in [#6096](https://github.com/software-mansion/react-native-reanimated/pull/6096)
- Allow worklet referencing in plugin by [@tjzel](https://github.com/tjzel) in [#5911](https://github.com/software-mansion/react-native-reanimated/pull/5911)
- Fix missing imports for RN72 compatibility by [@szydlovsky](https://github.com/szydlovsky) in [#6097](https://github.com/software-mansion/react-native-reanimated/pull/6097)
- Fix configuring unconfigurable properties by [@tjzel](https://github.com/tjzel) in [#6098](https://github.com/software-mansion/react-native-reanimated/pull/6098)
- Fix mistakes in example app by [@maciekstosio](https://github.com/maciekstosio) in [#6099](https://github.com/software-mansion/react-native-reanimated/pull/6099)
- Add missing unit tests (bezier, color converter, interpolate) by [@Latropos](https://github.com/Latropos) in [#6034](https://github.com/software-mansion/react-native-reanimated/pull/6034)
- docs: remove redundant `'worklet';` in `useComposedEventHandler` by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6078](https://github.com/software-mansion/react-native-reanimated/pull/6078)
- docs(example): update readme with build step by [@frankcalise](https://github.com/frankcalise) in [#6089](https://github.com/software-mansion/react-native-reanimated/pull/6089)
- fix: getAnimatableRef on web by [@intergalacticspacehighway](https://github.com/intergalacticspacehighway) in [#6088](https://github.com/software-mansion/react-native-reanimated/pull/6088)
- Set default keyboard state by [@piaskowyk](https://github.com/piaskowyk) in [#6101](https://github.com/software-mansion/react-native-reanimated/pull/6101)
- Fixes of dark-theme and values in docs by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6058](https://github.com/software-mansion/react-native-reanimated/pull/6058)
- Add Slider example to Reanimated Cookbook by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6094](https://github.com/software-mansion/react-native-reanimated/pull/6094)
- docs: update Hire us to directly lead to contact form by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6087](https://github.com/software-mansion/react-native-reanimated/pull/6087)
- Make animated component's event tag properly update by [@szydlovsky](https://github.com/szydlovsky) in [#6030](https://github.com/software-mansion/react-native-reanimated/pull/6030)
- Fix slow animation mode on Android by [@piaskowyk](https://github.com/piaskowyk) in [#6014](https://github.com/software-mansion/react-native-reanimated/pull/6014)
- Add 2048 example by [@tomekzaw](https://github.com/tomekzaw) in [#6032](https://github.com/software-mansion/react-native-reanimated/pull/6032)
- Fix nightly build CI by [@szydlovsky](https://github.com/szydlovsky) in [#6106](https://github.com/software-mansion/react-native-reanimated/pull/6106)
- Bump braces from 3.0.2 to 3.0.3 in /packages/react-native-reanimated/plugin by [@dependabot](https://github.com/dependabot) in [#6107](https://github.com/software-mansion/react-native-reanimated/pull/6107)
- Make all links from Reanimated Cookbook relative by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6105](https://github.com/software-mansion/react-native-reanimated/pull/6105)
- Clean up docs from redundant files by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6104](https://github.com/software-mansion/react-native-reanimated/pull/6104)
- Fix and rename publish docs CI by [@szydlovsky](https://github.com/szydlovsky) in [#6108](https://github.com/software-mansion/react-native-reanimated/pull/6108)
- Fix one more path in docs publish CI by [@szydlovsky](https://github.com/szydlovsky) in [#6109](https://github.com/software-mansion/react-native-reanimated/pull/6109)
- Fix docs-check CI trigger path by [@szydlovsky](https://github.com/szydlovsky) in [#6112](https://github.com/software-mansion/react-native-reanimated/pull/6112)
- Fix `web-example` by [@m-bert](https://github.com/m-bert) in [#6111](https://github.com/software-mansion/react-native-reanimated/pull/6111)
- docs: Add missing dark themes by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6110](https://github.com/software-mansion/react-native-reanimated/pull/6110)
- Screen transition example update - use proper import from screens instead of mock by [@piaskowyk](https://github.com/piaskowyk) in [#6118](https://github.com/software-mansion/react-native-reanimated/pull/6118)
- docs: fix transparent sidebar by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6117](https://github.com/software-mansion/react-native-reanimated/pull/6117)
- Fix SET in Expo Go by [@piaskowyk](https://github.com/piaskowyk) in [#6116](https://github.com/software-mansion/react-native-reanimated/pull/6116)
- [Web LA] Add warning about `transform` by [@m-bert](https://github.com/m-bert) in [#6064](https://github.com/software-mansion/react-native-reanimated/pull/6064)
- Fix broken link in documentation by [@piaskowyk](https://github.com/piaskowyk) in [#6120](https://github.com/software-mansion/react-native-reanimated/pull/6120)
- Fix eslint rules and types of tests by [@Latropos](https://github.com/Latropos) in [#6103](https://github.com/software-mansion/react-native-reanimated/pull/6103)
- Fix hot-reload in web-example by [@piaskowyk](https://github.com/piaskowyk) in [#6121](https://github.com/software-mansion/react-native-reanimated/pull/6121)
- Adjust Playground dark theme by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6122](https://github.com/software-mansion/react-native-reanimated/pull/6122)
- Remove unused file by [@piaskowyk](https://github.com/piaskowyk) in [#6125](https://github.com/software-mansion/react-native-reanimated/pull/6125)
- docs: add contributing docs page by [@maciekstosio](https://github.com/maciekstosio) in [#6061](https://github.com/software-mansion/react-native-reanimated/pull/6061)
- docs: Fix withTiming playground Power slider visibility by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6128](https://github.com/software-mansion/react-native-reanimated/pull/6128)
- Support snapshots of many views by [@Latropos](https://github.com/Latropos) in [#6047](https://github.com/software-mansion/react-native-reanimated/pull/6047)
- Bump ws from 6.2.2 to 6.2.3 in /packages/docs-reanimated by [@dependabot](https://github.com/dependabot) in [#6131](https://github.com/software-mansion/react-native-reanimated/pull/6131)
- Bump ws from 6.2.2 to 6.2.3 by [@dependabot](https://github.com/dependabot) in [#6132](https://github.com/software-mansion/react-native-reanimated/pull/6132)
- Layout Animations for the New Architecture by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#6055](https://github.com/software-mansion/react-native-reanimated/pull/6055)
- docs: Adjust expandable code by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6133](https://github.com/software-mansion/react-native-reanimated/pull/6133)
- Add Floating Action Button example to Reanimated Cookbook by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6079](https://github.com/software-mansion/react-native-reanimated/pull/6079)
- [Web LA] Fix default transitions. by [@m-bert](https://github.com/m-bert) in [#6124](https://github.com/software-mansion/react-native-reanimated/pull/6124)

#### New Contributors
- [@intergalacticspacehighway](https://github.com/intergalacticspacehighway) made their first contribution in [#6088](https://github.com/software-mansion/react-native-reanimated/pull/6088)

### 3.13.0-rc.1
#### What's Changed
- Fix crash when current activity is null by [@maciekstosio](https://github.com/maciekstosio) in [#6022](https://github.com/software-mansion/react-native-reanimated/pull/6022)
- improved composed handler docs to match our standards by [@szydlovsky](https://github.com/szydlovsky) in [#6071](https://github.com/software-mansion/react-native-reanimated/pull/6071)
- docs: update compatibility table for fabric by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#6068](https://github.com/software-mansion/react-native-reanimated/pull/6068)
- Monorepo by [@tjzel](https://github.com/tjzel) in [#5992](https://github.com/software-mansion/react-native-reanimated/pull/5992)
- Bump rexml from 3.2.6 to 3.2.9 in /apps/tvos-example by [@dependabot](https://github.com/dependabot) in [#6095](https://github.com/software-mansion/react-native-reanimated/pull/6095)
- Monorepo - move README by [@tjzel](https://github.com/tjzel) in [#6096](https://github.com/software-mansion/react-native-reanimated/pull/6096)
- Allow worklet referencing in plugin by [@tjzel](https://github.com/tjzel) in [#5911](https://github.com/software-mansion/react-native-reanimated/pull/5911)
- Fix missing imports for RN72 compatibility by [@szydlovsky](https://github.com/szydlovsky) in [#6097](https://github.com/software-mansion/react-native-reanimated/pull/6097)
- Fix configuring unconfigurable properties by [@tjzel](https://github.com/tjzel) in [#6098](https://github.com/software-mansion/react-native-reanimated/pull/6098)

### 3.13.0-rc.0
First monorepo release for testing and compatibility purposes.

### 3.12.0
#### What's Changed
##### Features
- Add `useComposedEventHandler` hook by [@szydlovsky](https://github.com/szydlovsky) in [#5890](https://github.com/software-mansion/react-native-reanimated/pull/5890)
- [Web LA] Remove `existingTransform` by [@m-bert](https://github.com/m-bert) in [#6060](https://github.com/software-mansion/react-native-reanimated/pull/6060)

##### Fixes
- [Android][Keyboard] More consistent inequality check to compute keyboard state by [@antFrancon](https://github.com/antFrancon) in [#5874](https://github.com/software-mansion/react-native-reanimated/pull/5874)
- fix typo on object key for `targetValues` in custom-animations.mdx by [@JDMathew](https://github.com/JDMathew) in [#5994](https://github.com/software-mansion/react-native-reanimated/pull/5994)
- Make animated components use different tags for events by [@szydlovsky](https://github.com/szydlovsky) in [#5960](https://github.com/software-mansion/react-native-reanimated/pull/5960)
- Prevent crash on non-existent view updates in Android by [@thomas-rx](https://github.com/thomas-rx) in [#5767](https://github.com/software-mansion/react-native-reanimated/pull/5767)
- Fix location after shared element transition by [@piaskowyk](https://github.com/piaskowyk) in [#6010](https://github.com/software-mansion/react-native-reanimated/pull/6010)
- fix: use proper classes for bridgeless by [@WoLewicki](https://github.com/WoLewicki) in [#5997](https://github.com/software-mansion/react-native-reanimated/pull/5997)
- Align handling colors with RN by [@maciekstosio](https://github.com/maciekstosio) in [#5825](https://github.com/software-mansion/react-native-reanimated/pull/5825)
- Make animation RollInLeft work with modifers by [@Latropos](https://github.com/Latropos) in [#6039](https://github.com/software-mansion/react-native-reanimated/pull/6039)
- docs: fix useAnimatedKeyboard page crash by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6056](https://github.com/software-mansion/react-native-reanimated/pull/6056)

##### Improvements
- Give more meaningful warning when modifying a Shareable by [@tjzel](https://github.com/tjzel) in [#5548](https://github.com/software-mansion/react-native-reanimated/pull/5548)
- Update useAnimatedKeyboard docs by [@maciekstosio](https://github.com/maciekstosio) in [#5866](https://github.com/software-mansion/react-native-reanimated/pull/5866)
- Change the docs to mention, that `.springify()` works with `.duration()` by [@Latropos](https://github.com/Latropos) in [#5990](https://github.com/software-mansion/react-native-reanimated/pull/5990)
- Remove `CellRendererComponent` from Animated.FlatList props by [@Latropos](https://github.com/Latropos) in [#5951](https://github.com/software-mansion/react-native-reanimated/pull/5951)

##### Internal Changes
- Add `warning` and `failing` test decorators by [@Latropos](https://github.com/Latropos) in [#5929](https://github.com/software-mansion/react-native-reanimated/pull/5929)
- Remove outdated code for unsupported React Native versions by [@tomekzaw](https://github.com/tomekzaw) in [#5979](https://github.com/software-mansion/react-native-reanimated/pull/5979)
- Remove REAInitializer by [@tomekzaw](https://github.com/tomekzaw) in [#5681](https://github.com/software-mansion/react-native-reanimated/pull/5681)
- Make `useScrollviewOffset` ref nullable and simplify its code by [@szydlovsky](https://github.com/szydlovsky) in [#6009](https://github.com/software-mansion/react-native-reanimated/pull/6009)
- docs: add @swmansion/t-rex-ui by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#6015](https://github.com/software-mansion/react-native-reanimated/pull/6015)
- Add more tests - useSharedValue, useAnimatedStyle , useDerivedValue by [@Latropos](https://github.com/Latropos) in [#5981](https://github.com/software-mansion/react-native-reanimated/pull/5981)
- Test predefined entering animation by [@Latropos](https://github.com/Latropos) in [#5995](https://github.com/software-mansion/react-native-reanimated/pull/5995)
- Tests: cancelAnimation, useFrameCallback, measure, withDecay by [@Latropos](https://github.com/Latropos) in [#6016](https://github.com/software-mansion/react-native-reanimated/pull/6016)

#### New Contributors
[@antFrancon](https://github.com/antFrancon), [@JDMathew](https://github.com/JDMathew), [@thomas-rx](https://github.com/thomas-rx), [@exploIF](https://github.com/exploIF)

#### 🙌 Thank you for your contributions!

### 3.10.1
Release contains backported changes from [3.11.0](https://github.com/software-mansion/react-native-reanimated/releases/tag/3.11.0) for Expo SDK 51

### 3.11.0
#### What's Changed
- Fix EXC_BAD_ACCESS crash on iOS in `[REAAnimationsManager clearSharedTransitionConfigForTag:]` by [@tomekzaw](https://github.com/tomekzaw) in [#5975](https://github.com/software-mansion/react-native-reanimated/pull/5975)
- Fix uncaught exception 'NSUnknownKeyException' on app reload on iOS by [@tomekzaw](https://github.com/tomekzaw) in [#5976](https://github.com/software-mansion/react-native-reanimated/pull/5976)
- Test two ways to use sharedValue in `useAnimatedStyle` by [@Latropos](https://github.com/Latropos) in [#5893](https://github.com/software-mansion/react-native-reanimated/pull/5893)
- docs: fix grammar by [@wodin](https://github.com/wodin) in [#5978](https://github.com/software-mansion/react-native-reanimated/pull/5978)
- fix: build issues on visionOS by [@okwasniewski](https://github.com/okwasniewski) in [#5980](https://github.com/software-mansion/react-native-reanimated/pull/5980)

### 3.10.0
#### What's Changed
- Prevent iOS bridgeless initialization from getting the wrong bridge by [@gabrieldonadel](https://github.com/gabrieldonadel) in [#5953](https://github.com/software-mansion/react-native-reanimated/pull/5953)
- Fix crashes when reloading app quickly on Android by [@lukmccall](https://github.com/lukmccall) in [#5958](https://github.com/software-mansion/react-native-reanimated/pull/5958)
- Use `[RCTUIManager viewForReactTag:]` instead of `viewRegistry` to avoid infinite loop in `[RCTComponentViewRegistry objectForKey:]` by [@tomekzaw](https://github.com/tomekzaw) in [#5957](https://github.com/software-mansion/react-native-reanimated/pull/5957)
- Crash while using useAnimatedKeyboard in flat list by [@maciekstosio](https://github.com/maciekstosio) in [#5918](https://github.com/software-mansion/react-native-reanimated/pull/5918)
- Fix calculating keyboard height by [@maciekstosio](https://github.com/maciekstosio) in [#5851](https://github.com/software-mansion/react-native-reanimated/pull/5851)
#### New Contributors
@devjs100 [@maciekstosio](https://github.com/maciekstosio)
#### 🙌 Thank you for your contributions!
Package build: https://github.com/software-mansion/react-native-reanimated/actions/runs/8907195489

### 3.9.0
#### What's Changed
##### Main changes
- Support for `react-native@0.74`
- Add screen transition animation by [@piaskowyk](https://github.com/piaskowyk) in [#5274](https://github.com/software-mansion/react-native-reanimated/pull/5274)
- reJest - mikro-framework for Reanimated public API runtime tests by [@Latropos](https://github.com/Latropos) [@piaskowyk](https://github.com/piaskowyk) in [#5400](https://github.com/software-mansion/react-native-reanimated/pull/5400)
- Add web implementation for useScrollViewOffset by [@szydlovsky](https://github.com/szydlovsky) in [#5805](https://github.com/software-mansion/react-native-reanimated/pull/5805)
- FPSCounter component in [#5770](https://github.com/software-mansion/react-native-reanimated/pull/5770)
- Add "Reanimated Cookbook" section to documentation by [@MajronMan](https://github.com/MajronMan) in [#5419](https://github.com/software-mansion/react-native-reanimated/pull/5419)

##### Internal changes
- Migrate to TurboModule by [@WoLewicki](https://github.com/WoLewicki) in [#5751](https://github.com/software-mansion/react-native-reanimated/pull/5751)
- fix: remove top level is_fabric check by [@WoLewicki](https://github.com/WoLewicki) in [#5779](https://github.com/software-mansion/react-native-reanimated/pull/5779)
- Bridgeless with runtimeExecutor by [@WoLewicki](https://github.com/WoLewicki) in [#5734](https://github.com/software-mansion/react-native-reanimated/pull/5734)
- Migrate to yarn3 by [@tjzel](https://github.com/tjzel) in [#5863](https://github.com/software-mansion/react-native-reanimated/pull/5863)
- Bump GitHub Actions to macOS 14 by [@tomekzaw](https://github.com/tomekzaw) in [#5904](https://github.com/software-mansion/react-native-reanimated/pull/5904)
- Add Checkspell CI job by [@xnameTM](https://github.com/xnameTM) in [#5888](https://github.com/software-mansion/react-native-reanimated/pull/5888)

##### Fxies
- Allow SETs configuration to be updated on rerender by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#5495](https://github.com/software-mansion/react-native-reanimated/pull/5495)
- Fix dynamically added/removed animated styles on iOS/Android by [@tjzel](https://github.com/tjzel) in [#5268](https://github.com/software-mansion/react-native-reanimated/pull/5268)
- Support `jsi::NativeState` in Shareables by [@mrousavy](https://github.com/mrousavy) in [#5785](https://github.com/software-mansion/react-native-reanimated/pull/5785)
- Add proper listeners cleanup to native useScrollViewOffset by [@szydlovsky](https://github.com/szydlovsky) in [#5831](https://github.com/software-mansion/react-native-reanimated/pull/5831)
- Fix useScrollViewOffset taking wrong viewTag by [@tjzel](https://github.com/tjzel) in [#5790](https://github.com/software-mansion/react-native-reanimated/pull/5790)
- Fix web useScrollViewOffset on wrapped scrolls by [@szydlovsky](https://github.com/szydlovsky) in [#5861](https://github.com/software-mansion/react-native-reanimated/pull/5861)
- WorkletEventHandler revamp by [@szydlovsky](https://github.com/szydlovsky) in [#5845](https://github.com/software-mansion/react-native-reanimated/pull/5845)
- [Web LA] Fix `null` elements error by [@m-bert](https://github.com/m-bert) in [#5881](https://github.com/software-mansion/react-native-reanimated/pull/5881)
- Fix layout animations that use custom animations changing colours by [@szydlovsky](https://github.com/szydlovsky) in [#5903](https://github.com/software-mansion/react-native-reanimated/pull/5903)
- Fix `getRelativeCoords` computing by [@szydlovsky](https://github.com/szydlovsky) in [#5926](https://github.com/software-mansion/react-native-reanimated/pull/5926)
- fix: copy state in reanimated commit hook by [@WoLewicki](https://github.com/WoLewicki) in [#5934](https://github.com/software-mansion/react-native-reanimated/pull/5934)

##### Improvements
- Make "Reanimated" title in docs interactive. by [@latekvo](https://github.com/latekvo) in [#5766](https://github.com/software-mansion/react-native-reanimated/pull/5766)
- Better error when passing easing from 'react-native' instead of 'reanimated' by [@Latropos](https://github.com/Latropos) in [#5639](https://github.com/software-mansion/react-native-reanimated/pull/5639)
- Include original remote function name in "Tried to synchronously call" error message by [@tomekzaw](https://github.com/tomekzaw) in [#5843](https://github.com/software-mansion/react-native-reanimated/pull/5843)

#### New Contributors
[@vietdung97](https://github.com/vietdung97) [@latekvo](https://github.com/latekvo) [@frankcalise](https://github.com/frankcalise) [@MajronMan](https://github.com/MajronMan) [@alduzy](https://github.com/alduzy)

#### 🙌 Thank you for your contributions!
Package build: https://github.com/software-mansion/react-native-reanimated/actions/runs/8846918580

### 3.9.0-rc.1
Support for React Native 0.74.0-rc.9

### 3.9.0-rc.0
#### What's Changed
- Add 3.8.0 to compatibility table by [@tjzel](https://github.com/tjzel) in [#5772](https://github.com/software-mansion/react-native-reanimated/pull/5772)
- migrate to turbomodule by [@WoLewicki](https://github.com/WoLewicki) in [#5751](https://github.com/software-mansion/react-native-reanimated/pull/5751)
- fix: remove top level is_fabric check by [@WoLewicki](https://github.com/WoLewicki) in [#5779](https://github.com/software-mansion/react-native-reanimated/pull/5779)
- reJest - mikro-framework for Reanimated public API runtime tests by [@Latropos](https://github.com/Latropos) in [#5400](https://github.com/software-mansion/react-native-reanimated/pull/5400)
- Add macos platform to issue template by [@jfedak](https://github.com/jfedak) in [#5786](https://github.com/software-mansion/react-native-reanimated/pull/5786)
- Check value callback whether it is valid or not by [@vietdung97](https://github.com/vietdung97) in [#5784](https://github.com/software-mansion/react-native-reanimated/pull/5784)
- Add `jestUtils` to mocks by [@tjzel](https://github.com/tjzel) in [#5791](https://github.com/software-mansion/react-native-reanimated/pull/5791)
- Allow SETs configuration to be updated on rerender by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#5495](https://github.com/software-mansion/react-native-reanimated/pull/5495)
- Bump follow-redirects from 1.15.4 to 1.15.6 in /docs by [@dependabot](https://github.com/dependabot) in [#5798](https://github.com/software-mansion/react-native-reanimated/pull/5798)
- Bump follow-redirects from 1.15.4 to 1.15.6 by [@dependabot](https://github.com/dependabot) in [#5797](https://github.com/software-mansion/react-native-reanimated/pull/5797)
- Bump follow-redirects from 1.15.4 to 1.15.6 in /WebExample by [@dependabot](https://github.com/dependabot) in [#5796](https://github.com/software-mansion/react-native-reanimated/pull/5796)
- Bump follow-redirects from 1.15.4 to 1.15.6 in /NextExample by [@dependabot](https://github.com/dependabot) in [#5799](https://github.com/software-mansion/react-native-reanimated/pull/5799)
- Make "Reanimated" title in docs interactive. by [@latekvo](https://github.com/latekvo) in [#5766](https://github.com/software-mansion/react-native-reanimated/pull/5766)
- Fix example in our example app by [@Latropos](https://github.com/Latropos) in [#5783](https://github.com/software-mansion/react-native-reanimated/pull/5783)
- Fix ocassional text interactivity issues. by [@latekvo](https://github.com/latekvo) in [#5803](https://github.com/software-mansion/react-native-reanimated/pull/5803)
- Fix dynamically added/removed animated styles on iOS/Android by [@tjzel](https://github.com/tjzel) in [#5268](https://github.com/software-mansion/react-native-reanimated/pull/5268)
- Support `jsi::NativeState` in Shareables by [@mrousavy](https://github.com/mrousavy) in [#5785](https://github.com/software-mansion/react-native-reanimated/pull/5785)
- Add web implementation for useScrollViewOffset by [@szydlovsky](https://github.com/szydlovsky) in [#5805](https://github.com/software-mansion/react-native-reanimated/pull/5805)
- Replace `systemUptime` calls with `CACurrentMediaTime()` to comply with Apple privacy requirements by [@tomekzaw](https://github.com/tomekzaw) in [#5819](https://github.com/software-mansion/react-native-reanimated/pull/5819)
- Better error when passing easing from 'react-native' instead of 'reanimated' by [@Latropos](https://github.com/Latropos) in [#5639](https://github.com/software-mansion/react-native-reanimated/pull/5639)
- Add information about type of `toValue` to our documentation by [@Latropos](https://github.com/Latropos) in [#5806](https://github.com/software-mansion/react-native-reanimated/pull/5806)
- Add screen transition animation by [@piaskowyk](https://github.com/piaskowyk) in [#5274](https://github.com/software-mansion/react-native-reanimated/pull/5274)
- Bump webpack-dev-middleware from 5.3.3 to 5.3.4 in /docs by [@dependabot](https://github.com/dependabot) in [#5827](https://github.com/software-mansion/react-native-reanimated/pull/5827)
- Bump webpack-dev-middleware from 5.3.3 to 5.3.4 in /WebExample by [@dependabot](https://github.com/dependabot) in [#5828](https://github.com/software-mansion/react-native-reanimated/pull/5828)
- Add proper listeners cleanup to native useScrollViewOffset by [@szydlovsky](https://github.com/szydlovsky) in [#5831](https://github.com/software-mansion/react-native-reanimated/pull/5831)
- Update useScrollViewOffset docs by [@szydlovsky](https://github.com/szydlovsky) in [#5824](https://github.com/software-mansion/react-native-reanimated/pull/5824)
- Fix default Sensor interval causing a security exception by [@latekvo](https://github.com/latekvo) in [#5812](https://github.com/software-mansion/react-native-reanimated/pull/5812)
- Screen Transition update public API by [@piaskowyk](https://github.com/piaskowyk) in [#5833](https://github.com/software-mansion/react-native-reanimated/pull/5833)
- Add documentation that event handlers cannot be used with more than one component. by [@Latropos](https://github.com/Latropos) in [#5809](https://github.com/software-mansion/react-native-reanimated/pull/5809)
- docs: hide AnimationToValue component from sidebar by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#5835](https://github.com/software-mansion/react-native-reanimated/pull/5835)
- Make /app good for for 0.74 by [@tjzel](https://github.com/tjzel) in [#5830](https://github.com/software-mansion/react-native-reanimated/pull/5830)
- Don't call hooks conditionally in `useScrollViewOffset` by [@tjzel](https://github.com/tjzel) in [#5839](https://github.com/software-mansion/react-native-reanimated/pull/5839)
- Add support for React Native 0.74 by [@tjzel](https://github.com/tjzel) in [#5815](https://github.com/software-mansion/react-native-reanimated/pull/5815)
- Bump examples to 0.74 by [@tjzel](https://github.com/tjzel) in [#5834](https://github.com/software-mansion/react-native-reanimated/pull/5834)
- Bump express from 4.18.2 to 4.19.2 in /docs by [@dependabot](https://github.com/dependabot) in [#5841](https://github.com/software-mansion/react-native-reanimated/pull/5841)
- Bump express from 4.18.2 to 4.19.2 in /WebExample by [@dependabot](https://github.com/dependabot) in [#5842](https://github.com/software-mansion/react-native-reanimated/pull/5842)
- Add support for cloning `Error` by [@tomekzaw](https://github.com/tomekzaw) in [#5844](https://github.com/software-mansion/react-native-reanimated/pull/5844)
- Bump Gesture Handler version in documentation by [@m-bert](https://github.com/m-bert) in [#5849](https://github.com/software-mansion/react-native-reanimated/pull/5849)
- FPSCounter by [@piaskowyk](https://github.com/piaskowyk) in [#5770](https://github.com/software-mansion/react-native-reanimated/pull/5770)
- Include original remote function name in "Tried to synchronously call" error message by [@tomekzaw](https://github.com/tomekzaw) in [#5843](https://github.com/software-mansion/react-native-reanimated/pull/5843)
- Fix layout animations example in landing page by [@m-bert](https://github.com/m-bert) in [#5848](https://github.com/software-mansion/react-native-reanimated/pull/5848)
- Implement `not` for runtime tests by [@Latropos](https://github.com/Latropos) in [#5813](https://github.com/software-mansion/react-native-reanimated/pull/5813)
- Increase screen transition velocity by [@piaskowyk](https://github.com/piaskowyk) in [#5847](https://github.com/software-mansion/react-native-reanimated/pull/5847)
- Include factory in easing warning by [@Latropos](https://github.com/Latropos) in [#5859](https://github.com/software-mansion/react-native-reanimated/pull/5859)
- Fix useScrollViewOffset taking wrong viewTag by [@tjzel](https://github.com/tjzel) in [#5790](https://github.com/software-mansion/react-native-reanimated/pull/5790)
- Fix web useScrollViewOffset on wrapped scrolls by [@szydlovsky](https://github.com/szydlovsky) in [#5861](https://github.com/software-mansion/react-native-reanimated/pull/5861)
- docs(README-Fabric): updated next tag to nightly by [@frankcalise](https://github.com/frankcalise) in [#5865](https://github.com/software-mansion/react-native-reanimated/pull/5865)
- Bridgeless with runtimeExecutor by [@WoLewicki](https://github.com/WoLewicki) in [#5734](https://github.com/software-mansion/react-native-reanimated/pull/5734)
- Use one constructor for NativeReanimatedModule with bridgeless by [@tjzel](https://github.com/tjzel) in [#5868](https://github.com/software-mansion/react-native-reanimated/pull/5868)

#### New Contributors
- [@vietdung97](https://github.com/vietdung97) made their first contribution in [#5784](https://github.com/software-mansion/react-native-reanimated/pull/5784)
- [@latekvo](https://github.com/latekvo) made their first contribution in [#5766](https://github.com/software-mansion/react-native-reanimated/pull/5766)
- [@frankcalise](https://github.com/frankcalise) made their first contribution in [#5865](https://github.com/software-mansion/react-native-reanimated/pull/5865)

### 3.8.1
Fixes:
- Add jestUtils to mocks ([#5791](https://github.com/software-mansion/react-native-reanimated/pull/5791))
- Check value callback whether it is valid or not ([#5784](https://github.com/software-mansion/react-native-reanimated/pull/5784))

### 3.8.0
#### What's Changed
##### New features
- Add `isWorklet` function by [@tomekzaw](https://github.com/tomekzaw) in [#4894](https://github.com/software-mansion/react-native-reanimated/pull/4894)
- Make animatedStyle keep reference through renders by [@Latropos](https://github.com/Latropos) in [#5333](https://github.com/software-mansion/react-native-reanimated/pull/5333)
- Expose `isWorklet` in public API by [@tjzel](https://github.com/tjzel) in [#5667](https://github.com/software-mansion/react-native-reanimated/pull/5667)
- Setup custom eslint plugin by [@Latropos](https://github.com/Latropos) in [#5553](https://github.com/software-mansion/react-native-reanimated/pull/5553)
- Add closable App.js banner to docs landing page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#5709](https://github.com/software-mansion/react-native-reanimated/pull/5709)
##### Fixes
- fix(android,animated-sensor): Fix HMR for Animated Sensor by [@Nodonisko](https://github.com/Nodonisko) in [#5646](https://github.com/software-mansion/react-native-reanimated/pull/5646)
- Fix hidden testimonials on landing page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#5675](https://github.com/software-mansion/react-native-reanimated/pull/5675)
- Fix warning about overwriting style with layout animation by [@Latropos](https://github.com/Latropos) in [#5644](https://github.com/software-mansion/react-native-reanimated/pull/5644)
- [Example] Fix chess pieces getting clipped on Android by [@tjzel](https://github.com/tjzel) in [#5691](https://github.com/software-mansion/react-native-reanimated/pull/5691)
- [LA Web] Add check for `HTMLElement` when looking for descendant with animation. by [@m-bert](https://github.com/m-bert) in [#5749](https://github.com/software-mansion/react-native-reanimated/pull/5749)
- fix: don't use deprecated onCatalystInstanceDestroy API by [@WoLewicki](https://github.com/WoLewicki) in [#5752](https://github.com/software-mansion/react-native-reanimated/pull/5752)
- Make `useEvent` return a different reference if event handler should be reattached by [@tjzel](https://github.com/tjzel) in [#5743](https://github.com/software-mansion/react-native-reanimated/pull/5743)
- Fix race condition when ShareableHandle is accessed on multiple threads by [@tjzel](https://github.com/tjzel) in [#5759](https://github.com/software-mansion/react-native-reanimated/pull/5759)
- Fix easing in Keyframe by [@Latropos](https://github.com/Latropos) in [#5761](https://github.com/software-mansion/react-native-reanimated/pull/5761)
  Fix android layout animation z-index bug by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#5769](https://github.com/software-mansion/react-native-reanimated/pull/5769)
##### Improvements
- Remove rest of `findNodeHandle` on web by [@m-bert](https://github.com/m-bert) in [#5654](https://github.com/software-mansion/react-native-reanimated/pull/5654)
- Fix missing null check for lastValue in useAnimatedStyle.ts by [@maks-io](https://github.com/maks-io) in [#5402](https://github.com/software-mansion/react-native-reanimated/pull/5402)
- docs: add `withClamp` animation modifier to docs glossary by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#5661](https://github.com/software-mansion/react-native-reanimated/pull/5661)
- Add Testimonials section to Reanimated Landing Page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#5670](https://github.com/software-mansion/react-native-reanimated/pull/5670)
- Improve typing in mock.ts by [@tomekzaw](https://github.com/tomekzaw) in [#5372](https://github.com/software-mansion/react-native-reanimated/pull/5372)
- docs: fix too big button hitbox on landing by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#5707](https://github.com/software-mansion/react-native-reanimated/pull/5707)
- docs: various small fixes by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#5708](https://github.com/software-mansion/react-native-reanimated/pull/5708)
- Rename `isWorklet` to `isWorkletFunction` by [@tjzel](https://github.com/tjzel) in [#5695](https://github.com/software-mansion/react-native-reanimated/pull/5695)
- Move Reanimated Babel Plugin dependencies to dependencies by [@tjzel](https://github.com/tjzel) in [#5716](https://github.com/software-mansion/react-native-reanimated/pull/5716)
- tests: add missing mock function by [@camilossantos2809](https://github.com/camilossantos2809) in [#5755](https://github.com/software-mansion/react-native-reanimated/pull/5755)
##### Keyboard
- [useAnimatedKeyboard][iOS] Keyboard interpolation by [@piaskowyk](https://github.com/piaskowyk) in [#5705](https://github.com/software-mansion/react-native-reanimated/pull/5705)
- [useAnimatedKeyboard][iOS] Support for keyboard interactive dismiss mode by [@piaskowyk](https://github.com/piaskowyk) in [#5730](https://github.com/software-mansion/react-native-reanimated/pull/5730)
- [useAnimatedKeyboard][Android] Keyboard refactor by [@piaskowyk](https://github.com/piaskowyk) in [#5665](https://github.com/software-mansion/react-native-reanimated/pull/5665)
- [useAnimatedKeyboard][Android] Filter keyboard events by [@piaskowyk](https://github.com/piaskowyk) in [#5740](https://github.com/software-mansion/react-native-reanimated/pull/5740)
- [useAnimatedKeyboard][Android] Fix state after animation dismiss by [@piaskowyk](https://github.com/piaskowyk) in [#5741](https://github.com/software-mansion/react-native-reanimated/pull/5741)
- [useAnimatedKeyboard][Android] Fix navigation bar with auto hide by [@piaskowyk](https://github.com/piaskowyk) in [#5742](https://github.com/software-mansion/react-native-reanimated/pull/5742)
- [useAnimatedKeyboard][iOS] Improve curve parameters by [@piaskowyk](https://github.com/piaskowyk) in [#5750](https://github.com/software-mansion/react-native-reanimated/pull/5750)
#### New Contributors
- [@maks-io](https://github.com/maks-io) made their first contribution in [#5402](https://github.com/software-mansion/react-native-reanimated/pull/5402)
- [@Nodonisko](https://github.com/Nodonisko) made their first contribution in [#5646](https://github.com/software-mansion/react-native-reanimated/pull/5646)
- [@camilossantos2809](https://github.com/camilossantos2809) made their first contribution in [#5755](https://github.com/software-mansion/react-native-reanimated/pull/5755)

### 3.7.2
[LA Web] Add check for HTMLElement when looking for descendant with animation. [#5749](https://github.com/software-mansion/react-native-reanimated/pull/5749)

### 3.7.1
- [#5646](https://github.com/software-mansion/react-native-reanimated/pull/5646) Fix for `useAnimatedSensor` to not throw JS errors on re-render in development bundles
- [#5402](https://github.com/software-mansion/react-native-reanimated/pull/5402) Fix for missing null check in `useAnimatedStyle`
- [#5333](https://github.com/software-mansion/react-native-reanimated/pull/5333) Making `useAnimatedStyle` return a stable reference

### 3.6.3
[#5562](https://github.com/software-mansion/react-native-reanimated/pull/5562) - Fixing layout animations now working in web production bundles

### 3.7.0
#### What's Changed
##### New features
- visionOS support by [@okwasniewski](https://github.com/okwasniewski) in [#5627](https://github.com/software-mansion/react-native-reanimated/pull/5627)
- Add TSDoc to public API by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#5377](https://github.com/software-mansion/react-native-reanimated/pull/5377)
- Pass down generator boolean in babel plugin by [@wcandillon](https://github.com/wcandillon) in [#5565](https://github.com/software-mansion/react-native-reanimated/pull/5565)
- Add new spring feature - clamp by [@Latropos](https://github.com/Latropos) in [#5195](https://github.com/software-mansion/react-native-reanimated/pull/5195)
- Introduce executeOnUIRuntimeSync and use it to replace Sync Data Holder by [@kmagiera](https://github.com/kmagiera) in [#4300](https://github.com/software-mansion/react-native-reanimated/pull/4300)

##### Fixes
- Fix ScrollView missing properties by [@tjzel](https://github.com/tjzel) in [#5437](https://github.com/software-mansion/react-native-reanimated/pull/5437)
- Web Layout Animation fixes by [@m-bert](https://github.com/m-bert)
- [Web LA] Update `left` from snapshot. by [@m-bert](https://github.com/m-bert) in [#5491](https://github.com/software-mansion/react-native-reanimated/pull/5491)
- Fix overloads in createAnimatedComponent by [@Latropos](https://github.com/Latropos) in [#5463](https://github.com/software-mansion/react-native-reanimated/pull/5463)
- Fix "Reading from `_value` directly is only possible on the UI runtime." on fast refresh during library development by [@tomekzaw](https://github.com/tomekzaw) in [#5434](https://github.com/software-mansion/react-native-reanimated/pull/5434)
- Fix incomplete UI runtime initialization by [@tomekzaw](https://github.com/tomekzaw) in [#5505](https://github.com/software-mansion/react-native-reanimated/pull/5505)
- Fix FlatList item generic types by [@jkadamczyk](https://github.com/jkadamczyk) in [#5528](https://github.com/software-mansion/react-native-reanimated/pull/5528)
- Fix `useHandler` context issue by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#5586](https://github.com/software-mansion/react-native-reanimated/pull/5586)
- fix: lazily search for ReactFabric by [@WoLewicki](https://github.com/WoLewicki) in [#5588](https://github.com/software-mansion/react-native-reanimated/pull/5588)
- Fix Android reloads by [@piaskowyk](https://github.com/piaskowyk) in [#5624](https://github.com/software-mansion/react-native-reanimated/pull/5624)
- Fix plugin sometimes not workletizing `ObjectMethod` by [@tjzel](https://github.com/tjzel) in [#5599](https://github.com/software-mansion/react-native-reanimated/pull/5599)

##### Improvements
- Rework `interpolate` documentation by [@kacperkapusciak](https://github.com/kacperkapusciak) in [#5398](https://github.com/software-mansion/react-native-reanimated/pull/5398)
- Replace useRef with useState for useSharedValue by [@amadeus](https://github.com/amadeus) in [#5458](https://github.com/software-mansion/react-native-reanimated/pull/5458)
- Add warning about reduced motion in dev mode by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#5479](https://github.com/software-mansion/react-native-reanimated/pull/5479)
- TS Improvements by [@tjzel](https://github.com/tjzel), [@Latropos](https://github.com/Latropos), [@marmor157](https://github.com/marmor157)
- Add `withClamp` documentation by [@Latropos](https://github.com/Latropos) in [#5381](https://github.com/software-mansion/react-native-reanimated/pull/5381)
- Use relative file location in source maps with `relativeSourceLocation` enabled by [@tjzel](https://github.com/tjzel) in [#5464](https://github.com/software-mansion/react-native-reanimated/pull/5464)
- Add docs for Reanimated Babel plugin options by [@tjzel](https://github.com/tjzel) in [#5382](https://github.com/software-mansion/react-native-reanimated/pull/5382)
- Always inject JS version by [@tjzel](https://github.com/tjzel) in [#5499](https://github.com/software-mansion/react-native-reanimated/pull/5499)
- Add suggestions to errors for accessing mutable's `value` by [@tjzel](https://github.com/tjzel) in [#5531](https://github.com/software-mansion/react-native-reanimated/pull/5531)
- Remove `makeRemote` by [@tjzel](https://github.com/tjzel) in [#5518](https://github.com/software-mansion/react-native-reanimated/pull/5518)
- Properly transpile async functions by [@tjzel](https://github.com/tjzel) in [#5577](https://github.com/software-mansion/react-native-reanimated/pull/5577)
- Allow layout animations to be updated on rerender by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#5371](https://github.com/software-mansion/react-native-reanimated/pull/5371)
- Pass shared_ptr by reference by [@piaskowyk](https://github.com/piaskowyk) in [#5592](https://github.com/software-mansion/react-native-reanimated/pull/5592)
- Add interactive examples to landing page by [@patrycjakalinska](https://github.com/patrycjakalinska) in [#5603](https://github.com/software-mansion/react-native-reanimated/pull/5603)

#### New Contributors
[@marmor157](https://github.com/marmor157) [@Code-Victor](https://github.com/Code-Victor) [@wodin](https://github.com/wodin) [@amadeus](https://github.com/amadeus) [@azashi](https://github.com/azashi) [@shubham1206agra](https://github.com/shubham1206agra) [@migueldaipre](https://github.com/migueldaipre) [@cortinico](https://github.com/cortinico) [@patrycjakalinska](https://github.com/patrycjakalinska) [@jp1987](https://github.com/jp1987) [@okwasniewski](https://github.com/okwasniewski)

#### 🙌 Thank you for your contributions!
Package build: https://github.com/software-mansion/react-native-reanimated/actions/runs/7017226041

### 3.6.2
Changes:
- Remove warning in Expo Go

### 3.6.1
Changes:
- Add TSDoc to public API ([#5377](https://github.com/software-mansion/react-native-reanimated/pull/5377))
- Fix PlatformChecker.ts ([#5440](https://github.com/software-mansion/react-native-reanimated/pull/5440))
- Fix ScrollView missing properties ([#5437](https://github.com/software-mansion/react-native-reanimated/pull/5437))

### 3.6.0
#### What's Changed
##### New features
- Multithreading / Async task - [@tomekzaw](https://github.com/tomekzaw) in [#5068](https://github.com/software-mansion/react-native-reanimated/pull/5068) [#5192](https://github.com/software-mansion/react-native-reanimated/pull/5192)
- Layout Animations for web - [@m-bert](https://github.com/m-bert) in [#4805](https://github.com/software-mansion/react-native-reanimated/pull/4805)
- Added `<LayoutAnimationConfig>` - [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#5045](https://github.com/software-mansion/react-native-reanimated/pull/5045)
- Support for react-native@0.73 - [@piaskowyk](https://github.com/piaskowyk) in [#4913](https://github.com/software-mansion/react-native-reanimated/pull/4913) [#5422](https://github.com/software-mansion/react-native-reanimated/pull/5422)
- Add animation - withClamp - [@Latropos](https://github.com/Latropos) in [#5239](https://github.com/software-mansion/react-native-reanimated/pull/5239)

##### Fixes
- Update type exports to fix build warnings - [@khevamann](https://github.com/khevamann) in [#5074](https://github.com/software-mansion/react-native-reanimated/pull/5074)
- fix Maximum call stack size exceeded - [@efstathiosntonas](https://github.com/efstathiosntonas) in [#5087](https://github.com/software-mansion/react-native-reanimated/pull/5087)
- Fix Skia-Reanimated integration - [@tjzel](https://github.com/tjzel) in [#5103](https://github.com/software-mansion/react-native-reanimated/pull/5103)
- Fix cleaning layout animation config on iOS - [@Latropos](https://github.com/Latropos) in [#4997](https://github.com/software-mansion/react-native-reanimated/pull/4997)
- [SET] Fix transition restart by [@piaskowyk](https://github.com/piaskowyk) in [#4947](https://github.com/software-mansion/react-native-reanimated/pull/4947)
- Prevent top-level calls to `requestAnimationFrame` - [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#5136](https://github.com/software-mansion/react-native-reanimated/pull/5136)
- Fix inline styles on web - [@tjzel](https://github.com/tjzel) in [#5164](https://github.com/software-mansion/react-native-reanimated/pull/5164)
- Fix animated UI Props on Web - [@piaskowyk](https://github.com/piaskowyk) in [#5169](https://github.com/software-mansion/react-native-reanimated/pull/5169)
- Fix mapper getting stuck on an error in worklet - [@tjzel](https://github.com/tjzel) in [#5190](https://github.com/software-mansion/react-native-reanimated/pull/5190)
- Fix race-condition during render - [@piaskowyk](https://github.com/piaskowyk) in [#5224](https://github.com/software-mansion/react-native-reanimated/pull/5224)
- Fix stack trace on worklet factory crash - [@tjzel](https://github.com/tjzel) in [#5197](https://github.com/software-mansion/react-native-reanimated/pull/5197)
- Fix inverted `FlatList` by [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#5295](https://github.com/software-mansion/react-native-reanimated/pull/5295)
- Fix useAnimatedKeyboard when keyboard type changes by [@andreysam](https://github.com/andreysam) in [#5337](https://github.com/software-mansion/react-native-reanimated/pull/5337)

##### Improvements
- Documentation improvements - [@kacperkapusciak](https://github.com/kacperkapusciak) in [#5063](https://github.com/software-mansion/react-native-reanimated/pull/5063) [#5071](https://github.com/software-mansion/react-native-reanimated/pull/5071) [#5159](https://github.com/software-mansion/react-native-reanimated/pull/5159) [#5215](https://github.com/software-mansion/react-native-reanimated/pull/5215) [#5299](https://github.com/software-mansion/react-native-reanimated/pull/5299)
- Use strict everywhere - [@tjzel](https://github.com/tjzel) in [#5055](https://github.com/software-mansion/react-native-reanimated/pull/5055)
- Add e2e tests in NextExample - [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#5124](https://github.com/software-mansion/react-native-reanimated/pull/5124)
- CI to detect broken URLs in source code - [@piaskowyk](https://github.com/piaskowyk) in [#5131](https://github.com/software-mansion/react-native-reanimated/pull/5131)
- Unify `Extrapolation` and `Extrapolate` - [@Latropos](https://github.com/Latropos) in [#5141](https://github.com/software-mansion/react-native-reanimated/pull/5141)
- Add `performance.now` in worklet runtimes by [@tomekzaw](https://github.com/tomekzaw) in [#5194](https://github.com/software-mansion/react-native-reanimated/pull/5194)
- Improve spring config verification - [@Latropos](https://github.com/Latropos) in [#5188](https://github.com/software-mansion/react-native-reanimated/pull/5188)
- Add compatibility table - [@Latropos](https://github.com/Latropos) in [#5122](https://github.com/software-mansion/react-native-reanimated/pull/5122)
- Add shareable ArrayBuffer, typed arrays and DataView, BigInt - [@tomekzaw](https://github.com/tomekzaw) in [#5223](https://github.com/software-mansion/react-native-reanimated/pull/5223) [#5237](https://github.com/software-mansion/react-native-reanimated/pull/5237)
- Reduce web bundle size - [@bartlomiejbloniarz](https://github.com/bartlomiejbloniarz) in [#5203](https://github.com/software-mansion/react-native-reanimated/pull/5203) [#5200](https://github.com/software-mansion/react-native-reanimated/pull/5200)
- Replaced DEBUG macro with NDEBUG - [@michalmaka](https://github.com/michalmaka) in [#5113](https://github.com/software-mansion/react-native-reanimated/pull/5113)
- Bump iOS deployment target to 10.0 - [@gabrieldonadel](https://github.com/gabrieldonadel) in [#5263](https://github.com/software-mansion/react-native-reanimated/pull/5263)
- Run listeners when calling sv.modify - [@tomekzaw](https://github.com/tomekzaw) in [#5306](https://github.com/software-mansion/react-native-reanimated/pull/5306)
- Avoid double serialization of `__initData` - [@tomekzaw](https://github.com/tomekzaw) in [#5186](https://github.com/software-mansion/react-native-reanimated/pull/5186)
- Add JSProps on Fabric by [@piaskowyk](https://github.com/piaskowyk) in [#5009](https://github.com/software-mansion/react-native-reanimated/pull/5009)
- Use install_modules_dependencies by [@piaskowyk](https://github.com/piaskowyk) in [#5334](https://github.com/software-mansion/react-native-reanimated/pull/5334)
- Allow different flavors JS and App by [@tjzel](https://github.com/tjzel) in [#5404](https://github.com/software-mansion/react-native-reanimated/pull/5404)

##### Typescript
- A lot of type improvements - [@tjzel](https://github.com/tjzel)

#### New Contributors
[@khevamann](https://github.com/khevamann) [@xSyki](https://github.com/xSyki) [@ankit-tailor](https://github.com/ankit-tailor) [@caglar09](https://github.com/caglar09) [@gabrieldonadel](https://github.com/gabrieldonadel) @td-tomasz-joniec [@cwclancy](https://github.com/cwclancy) [@szydlovsky](https://github.com/szydlovsky) [@joshlam](https://github.com/joshlam) [@andreysam](https://github.com/andreysam) [@ugurcanatas](https://github.com/ugurcanatas)

#### 🙌 Thank you for your contributions!
Package build: https://github.com/software-mansion/react-native-reanimated/actions/runs/7017226041