// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#include "OHOSCSSPlatformTransitions.h"

#include "RNOH/ComponentInstance.h"
#include "RNOH/RNInstance.h"
#include "RNOH/RNInstanceCAPI.h"
#include "RNOH/TaskExecutor/TaskExecutor.h"
#include "RNOH/arkui/ArkUINode.h"
#include "RNOH/arkui/NativeNodeApi.h"

#include <arkui/native_animate.h>
#include <arkui/native_interface.h>
#include <arkui/native_node.h>

#include <glog/logging.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <optional>
#include <utility>
#include <vector>

using namespace facebook;

namespace reanimated::css {

namespace {

double wallClockMs() {
  return std::chrono::duration<double, std::milli>(
             std::chrono::high_resolution_clock::now().time_since_epoch())
      .count();
}

// CSS property -> the ArkUI node attribute that renders it. The routable set
// matches platform.cpp's OHOS whitelist (shadow* stays on the loop: ArkUI's
// NODE_SHADOW takes only predefined style enums).
std::optional<ArkUI_NodeAttributeType> attributeForProperty(const std::string &propertyName) {
  static const std::unordered_map<std::string, ArkUI_NodeAttributeType> kAttributes = {
      {"opacity", NODE_OPACITY},
      {"backgroundColor", NODE_BACKGROUND_COLOR},
      {"borderColor", NODE_BORDER_COLOR},
      {"borderRadius", NODE_BORDER_RADIUS},
      {"borderWidth", NODE_BORDER_WIDTH},
  };
  const auto it = kAttributes.find(propertyName);
  return it != kAttributes.end() ? std::optional<ArkUI_NodeAttributeType>(it->second) : std::nullopt;
}

// Normalized [r,g,b,a] doubles (parsePlatformValue's Color form) -> 0xAARRGGBB,
// the layout ArkUI color attributes take.
uint32_t argbFromColor(const std::array<double, 4> &rgba) {
  const auto channel = [](const double v) {
    return static_cast<uint32_t>(std::clamp(v, 0.0, 1.0) * 255.0 + 0.5);
  };
  return (channel(rgba[3]) << 24) | (channel(rgba[0]) << 16) | (channel(rgba[1]) << 8) | channel(rgba[2]);
}

// The single ArkUI_NumberValue expressing this property's endpoint. A Size
// value (array<double,2>) is not expressible — unreachable through the
// routing gate, reported as nullopt so callers can bail out.
struct AttributePayload {
  ArkUI_NumberValue value;
};
std::optional<AttributePayload> payloadForValue(const PlatformValue &value) {
  if (const auto *scalar = std::get_if<double>(&value)) {
    return AttributePayload{ArkUI_NumberValue{.f32 = static_cast<float>(*scalar)}};
  }
  if (const auto *color = std::get_if<std::array<double, 4>>(&value)) {
    return AttributePayload{ArkUI_NumberValue{.u32 = argbFromColor(*color)}};
  }
  return std::nullopt;
}

std::string describeValue(const PlatformValue &value) {
  if (const auto *scalar = std::get_if<double>(&value)) {
    return std::to_string(*scalar);
  }
  if (const auto *color = std::get_if<std::array<double, 4>>(&value)) {
    std::string out = "#" + std::to_string(argbFromColor(*color));
    return out;
  }
  return "size";
}

// Only linear and cubic-bezier reach the backend (canRouteCSSProperty gate);
// steps / linear-stops would need per-frame interpolation on the loop.
ArkUI_CurveHandle createCurve(const EasingConfig &easing) {
  if (const auto *bezier = std::get_if<CubicBezierEasing>(&easing)) {
    return OH_ArkUI_Curve_CreateCubicBezierCurve(
        static_cast<float>(bezier->x1),
        static_cast<float>(bezier->y1),
        static_cast<float>(bezier->x2),
        static_cast<float>(bezier->y2));
  }
  return OH_ArkUI_Curve_CreateCurveByType(ARKUI_CURVE_LINEAR);
}

// Everything the MAIN-thread animation needs; plain copies only, so the
// closure outlives the caller-side state safely.
struct AnimateRequest {
  react::Tag tag;
  std::string property;
  ArkUI_NodeAttributeType attribute;
  AttributePayload payload;
  double durationMs;
  double delayMs;
  EasingConfig easing;
};

// Resolves the raw ArkUI node behind a view tag. Must run on MAIN (component
// instances live there); returns nullptr for unmounted/unresolved tags.
ArkUI_NodeHandle resolveNode(
    const std::weak_ptr<rnoh::RNInstance> &weakInstance,
    const react::Tag tag) {
  const auto instance = weakInstance.lock();
  const auto instanceCapi = std::dynamic_pointer_cast<rnoh::RNInstanceCAPI>(instance);
  if (instanceCapi == nullptr) {
    return nullptr;
  }
  const auto componentInstance = instanceCapi->findComponentInstanceByTag(tag);
  if (componentInstance == nullptr) {
    return nullptr;
  }
  return componentInstance->getLocalRootArkUINode().getArkUINodeHandle();
}

} // namespace

OHOSCSSPlatformTransitions::OHOSCSSPlatformTransitions(
    std::weak_ptr<rnoh::RNInstance> instance,
    std::weak_ptr<rnoh::TaskExecutor> taskExecutor)
    : instance_(std::move(instance)), taskExecutor_(std::move(taskExecutor)) {}

bool OHOSCSSPlatformTransitions::applyTransitionForTag(
    jsi::Runtime &rt,
    const react::Tag viewTag,
    const std::string &propertyName,
    const jsi::Value &fromValue,
    const jsi::Value &toValue,
    const CSSTransitionPropertySettings &settings,
    const double timestamp) {
  const auto from = parsePlatformValue(rt, propertyName, fromValue);
  const auto to = parsePlatformValue(rt, propertyName, toValue);
  if (!from || !to || !attributeForProperty(propertyName) || !payloadForValue(*to)) {
    return false;
  }
  DLOG(INFO) << "[css-route] apply tag=" << viewTag << " prop=" << propertyName
             << " from=" << describeValue(*from) << " to=" << describeValue(*to)
             << " duration=" << settings.duration << " delay=" << settings.delay;
  applyForTag(viewTag, propertyName, *from, *to, settings, timestamp);
  return true;
}

bool OHOSCSSPlatformTransitions::applyDynamicTransitionForTag(
    const react::Tag viewTag,
    const std::string &propertyName,
    const folly::dynamic &fromValue,
    const folly::dynamic &toValue,
    const double timestamp) {
  std::optional<CSSTransitionPropertySettings> settings;
  {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto propertiesIt = active_.find(viewTag);
    if (propertiesIt == active_.end()) {
      return false;
    }
    const auto activeIt = propertiesIt->second.find(propertyName);
    if (activeIt == propertiesIt->second.end()) {
      // No config apply ran for this property, so there are no settings to reuse.
      return false;
    }
    settings = activeIt->second.settings;
  }
  const auto from = parsePlatformValue(propertyName, fromValue);
  const auto to = parsePlatformValue(propertyName, toValue);
  if (!from || !to || !attributeForProperty(propertyName) || !payloadForValue(*to)) {
    return false;
  }
  DLOG(INFO) << "[css-route] applyDynamic tag=" << viewTag << " prop=" << propertyName
             << " from=" << describeValue(*from) << " to=" << describeValue(*to);
  applyForTag(viewTag, propertyName, *from, *to, *settings, timestamp);
  return true;
}

void OHOSCSSPlatformTransitions::removeTransitionForTag(
    const react::Tag viewTag, const std::string &propertyName) {
  std::optional<PlatformValue> endValue;
  {
    std::lock_guard<std::mutex> lock(mutex_);
    const auto propertiesIt = active_.find(viewTag);
    if (propertiesIt != active_.end()) {
      const auto activeIt = propertiesIt->second.find(propertyName);
      if (activeIt != propertiesIt->second.end()) {
        endValue = activeIt->second.adjustedEnd;
      }
      propertiesIt->second.erase(propertyName);
      if (propertiesIt->second.empty()) {
        active_.erase(propertiesIt);
      }
    }
  }
  const auto attribute = attributeForProperty(propertyName);
  if (!endValue || !attribute) {
    return;
  }
  const auto payload = payloadForValue(*endValue);
  if (!payload) {
    return;
  }
  // v1: snap the node to the recorded target value. iOS freezes the live
  // presentation value on cancel; ArkUI has no generic presentation getter
  // for arbitrary attributes, so the node lands on the target instead.
  const auto weakInstance = instance_;
  const ArkUI_NodeAttributeType attr = *attribute;
  const AttributePayload payloadCopy = *payload;
  const std::string property = propertyName;
  runOnMain([weakInstance, viewTag, property, attr, payloadCopy]() {
    const auto nodeApi = rnoh::NativeNodeApi::getInstance();
    ArkUI_NodeHandle node = resolveNode(weakInstance, viewTag);
    if (node == nullptr) {
      DLOG(WARNING) << "[css-route] remove: node not found tag=" << viewTag;
      return;
    }
    ArkUI_NumberValue value = payloadCopy.value;
    const ArkUI_AttributeItem item{&value, 1, nullptr, nullptr};
    nodeApi->setAttribute(node, attr, &item);
    DLOG(INFO) << "[css-route] remove tag=" << viewTag << " prop=" << property
               << " (snapped to target)";
  });
}

void OHOSCSSPlatformTransitions::applyForTag(
    const react::Tag viewTag,
    const std::string &propertyName,
    const PlatformValue &fromValue,
    const PlatformValue &toValue,
    const CSSTransitionPropertySettings &settings,
    const double timestamp) {
  const auto attribute = attributeForProperty(propertyName);
  const auto payload = payloadForValue(toValue);
  if (!attribute || !payload) {
    return;
  }

  ReversingState reversing;
  {
    std::lock_guard<std::mutex> lock(mutex_);
    auto &properties = active_[viewTag];
    const auto activeIt = properties.find(propertyName);
    // Targeting the in-flight transition's start value means this is a reversal.
    const bool isReversal =
        activeIt != properties.end() && toValue == activeIt->second.adjustedStart;
    if (isReversal) {
      reversing = reverseShorten(
          activeIt->second.reversing, timestamp, settings.duration, settings.delay, settings.easingConfig);
      DLOG(INFO) << "[css-route] reversal tag=" << viewTag << " prop=" << propertyName
                 << " shortened=" << reversing.duration << "ms";
    } else {
      reversing = makeReversingState(timestamp, settings.duration, settings.delay, settings.easingConfig);
    }
    properties[propertyName] = ActiveTransition{
        isReversal ? activeIt->second.adjustedEnd : fromValue, toValue, reversing, settings};
  }

  // reversing.startTimestamp is absolute (ms); animateTo wants a relative
  // delay. Negative delays (already-part-elapsed W3C semantics) clamp to 0 —
  // ArkUI has no negative-delay form.
  double delayMs = reversing.startTimestamp - wallClockMs();
  if (delayMs < 0) {
    delayMs = 0;
  }

  AnimateRequest request{
      viewTag,
      propertyName,
      *attribute,
      *payload,
      std::max(0.0, reversing.duration),
      delayMs,
      settings.easingConfig};
  const auto weakInstance = instance_;
  runOnMain([weakInstance, request = std::move(request)]() {
    ArkUI_NodeHandle node = resolveNode(weakInstance, request.tag);
    if (node == nullptr) {
      DLOG(WARNING) << "[css-route] animate: node not found tag=" << request.tag
                    << " prop=" << request.property;
      return;
    }
    ArkUI_ContextHandle context = OH_ArkUI_GetContextByNode(node);
    if (context == nullptr) {
      DLOG(WARNING) << "[css-route] animate: no UIContext tag=" << request.tag;
      return;
    }
    ArkUI_NativeAnimateAPI_1 *animateApi = nullptr;
    OH_ArkUI_GetModuleInterface(ARKUI_NATIVE_ANIMATE, ArkUI_NativeAnimateAPI_1, animateApi);
    if (animateApi == nullptr || animateApi->animateTo == nullptr) {
      DLOG(WARNING) << "[css-route] animate: ArkUI_NativeAnimateAPI_1 unavailable";
      return;
    }

    ArkUI_AnimateOption *option = OH_ArkUI_AnimateOption_Create();
    OH_ArkUI_AnimateOption_SetDuration(option, static_cast<int32_t>(request.durationMs));
    OH_ArkUI_AnimateOption_SetDelay(option, static_cast<int32_t>(request.delayMs));
    ArkUI_CurveHandle curve = createCurve(request.easing);
    if (curve != nullptr) {
      OH_ArkUI_AnimateOption_SetICurve(option, curve);
    }

    // animateTo invokes the update closure synchronously (it exists to record
    // the end-state diff), so a stack context is safe as its userData.
    struct UpdateCtx {
      ArkUI_NodeHandle node;
      ArkUI_NodeAttributeType attribute;
      ArkUI_NumberValue value;
    } updateCtx{node, request.attribute, request.payload.value};
    ArkUI_ContextCallback update{
        &updateCtx,
        [](void *userData) {
          const auto *ctx = static_cast<UpdateCtx *>(userData);
          ArkUI_NumberValue value = ctx->value;
          const ArkUI_AttributeItem item{&value, 1, nullptr, nullptr};
          rnoh::NativeNodeApi::getInstance()->setAttribute(ctx->node, ctx->attribute, &item);
        }};
    const int32_t result = animateApi->animateTo(context, option, &update, nullptr);
    OH_ArkUI_AnimateOption_Dispose(option);
    if (curve != nullptr) {
      OH_ArkUI_Curve_DisposeCurve(curve);
    }
    DLOG(INFO) << "[css-route] animateTo tag=" << request.tag << " prop=" << request.property
               << " result=" << result << " duration=" << static_cast<int32_t>(request.durationMs)
               << "ms delay=" << static_cast<int32_t>(request.delayMs) << "ms";
  });
}

void OHOSCSSPlatformTransitions::runOnMain(std::function<void()> task) {
  auto taskExecutor = taskExecutor_.lock();
  if (!taskExecutor) {
    return;
  }
  if (taskExecutor->isOnTaskThread(rnoh::TaskThread::MAIN)) {
    task();
  } else {
    taskExecutor->runTask(rnoh::TaskThread::MAIN, std::move(task));
  }
}

} // namespace reanimated::css
