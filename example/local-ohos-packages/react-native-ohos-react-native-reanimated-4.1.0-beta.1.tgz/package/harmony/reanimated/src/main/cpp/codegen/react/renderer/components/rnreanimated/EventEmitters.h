#pragma once

// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#include <react/renderer/components/view/ViewEventEmitter.h>

namespace facebook {
namespace react {

class REASharedTransitionBoundaryEventEmitter final
    : public ViewEventEmitter {
 public:
  using ViewEventEmitter::ViewEventEmitter;
};

} // namespace react
} // namespace facebook
