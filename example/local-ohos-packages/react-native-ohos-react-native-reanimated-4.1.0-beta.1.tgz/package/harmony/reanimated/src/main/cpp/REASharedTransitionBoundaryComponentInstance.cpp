// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#include "REASharedTransitionBoundaryComponentInstance.h"

namespace rnoh {

REASharedTransitionBoundaryComponentInstance::REASharedTransitionBoundaryComponentInstance(
    Context context)
    : CppComponentInstance(std::move(context)), m_customNode(m_arkUINodeCtx) {}

void REASharedTransitionBoundaryComponentInstance::onChildInserted(
    ComponentInstance::Shared const& childComponentInstance,
    std::size_t index) {
  CppComponentInstance::onChildInserted(childComponentInstance, index);
  m_customNode.insertChild(childComponentInstance->getLocalRootArkUINode(), index);
}

void REASharedTransitionBoundaryComponentInstance::onChildRemoved(
    ComponentInstance::Shared const& childComponentInstance) {
  CppComponentInstance::onChildRemoved(childComponentInstance);
  m_customNode.removeChild(childComponentInstance->getLocalRootArkUINode());
}

CustomNode& REASharedTransitionBoundaryComponentInstance::getLocalRootArkUINode() {
  return m_customNode;
}

void REASharedTransitionBoundaryComponentInstance::onLayoutChanged(
    facebook::react::LayoutMetrics const& layoutMetrics) {
  auto adjusted = layoutMetrics;
  const auto scaleFactor =
      layoutMetrics.pointScaleFactor > 0 ? layoutMetrics.pointScaleFactor : 1.f;
  const auto minSize = 1.f / scaleFactor; // rounds to >= 1px in setLayoutRect
  if (adjusted.frame.size.width < minSize) {
    adjusted.frame.size.width = minSize;
  }
  if (adjusted.frame.size.height < minSize) {
    adjusted.frame.size.height = minSize;
  }
  CppComponentInstance::onLayoutChanged(adjusted);
}

} // namespace rnoh
