#pragma once

// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#include <react/renderer/components/view/ViewProps.h>
#include <react/renderer/core/PropsParserContext.h>
#include <react/renderer/core/RawProps.h>
#include <react/renderer/core/propsConversions.h>

namespace facebook {
namespace react {

class REASharedTransitionBoundaryProps final : public ViewProps {
 public:
  REASharedTransitionBoundaryProps() = default;

  REASharedTransitionBoundaryProps(
      const PropsParserContext &context,
      const REASharedTransitionBoundaryProps &sourceProps,
      const RawProps &rawProps)
      : ViewProps(context, sourceProps, rawProps) {
    isActive = convertRawProp(context, rawProps, "isActive", sourceProps.isActive, false);
  }

  bool isActive{false};
};

} // namespace react
} // namespace facebook
