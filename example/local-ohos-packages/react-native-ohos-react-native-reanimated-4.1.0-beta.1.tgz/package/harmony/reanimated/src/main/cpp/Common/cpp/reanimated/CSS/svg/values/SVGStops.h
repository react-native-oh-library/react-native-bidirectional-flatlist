#pragma once

#include <reanimated/CSS/common/values/CSSValue.h>
#include <reanimated/CSS/svg/values/SVGBrush.h>

#include <concepts>
#include <string>
#include <utility>
#include <vector>

namespace reanimated::css {

struct SVGStops : public CSSSimpleValue<SVGStops> {
  struct GradientStop {
    // OHOS patch: clang 15's std::is_constructible doesn't account for
    // parenthesized aggregate initialization (P0960), so
    // std::construct_at — used by vector::emplace_back — rejects
    // GradientStop(double, SVGBrush) ("no matching constructor"). An explicit
    // constructor bypasses the trait gap; brace initialization keeps working.
    // Upstream relies on P0960 with clang 17+ (NDK).
    GradientStop(double offset_, SVGBrush color_) : offset(offset_), color(std::move(color_)) {}

    double offset;
    SVGBrush color;
  };

  SVGStops() = default;
  template <typename T>
    requires(!std::same_as<std::decay_t<T>, SVGStops>) && std::constructible_from<std::vector<GradientStop>, T>
  explicit SVGStops(T &&value) : stops{std::forward<T>(value)} {}
  explicit SVGStops(jsi::Runtime &rt, const jsi::Value &jsiValue);
  explicit SVGStops(const folly::dynamic &value);

  static bool canConstruct(jsi::Runtime &rt, const jsi::Value &jsiValue);
  static bool canConstruct(const folly::dynamic &value);

  folly::dynamic toDynamic() const override;
  std::string toString() const override;
  SVGStops interpolate(double progress, const SVGStops &to) const override;

  bool operator==(const SVGStops &other) const;

#ifndef NDEBUG
  friend std::ostream &operator<<(std::ostream &os, const SVGStops &dimension);
#endif // NDEBUG

 private:
  std::vector<GradientStop> stops;
};

} // namespace reanimated::css
