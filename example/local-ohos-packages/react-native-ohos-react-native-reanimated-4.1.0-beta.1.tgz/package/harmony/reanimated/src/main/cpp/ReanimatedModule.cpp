// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#include "RNOH/ArkTSTurboModule.h"
#include "RNOH/RNInstance.h"
#include "ReanimatedModule.h"
#include "PseudoSelectorManager.h"
#include "ReanimatedSensorContainer.h"
#include "PlatformDepMethodsHolder.h"
#include "WorkletRuntimeCollector.h"
#include "RNRuntimeDecorator.h"
#include "TransformParser.h"
#include "RNOH/RNInstanceCAPI.h"
#include "WorkletsModule.h"
#include "ReanimatedNodesManager.h"
#include "OHOSCSSPlatformTransitions.h"
using namespace facebook;
using namespace reanimated;
using namespace worklets;
namespace rnoh {
static double getMillisSinceEpoch() {
    auto now = std::chrono::high_resolution_clock::now();
    auto frameTime = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch());
    return frameTime.count();
}

jsi::Value installTurboModule(facebook::jsi::Runtime &rt, react::TurboModule &turboModule,
                              const facebook::jsi::Value *args, size_t count) {
    auto self = static_cast<ReanimatedModule *>(&turboModule);
    self->installTurboModule(rt);
    return facebook::jsi::Value(true);
}

ReanimatedModule::ReanimatedModule(const ArkTSTurboModule::Context ctx, const std::string name)
    : ArkTSTurboModule(ctx, name) {
    methodMap_ = {{"installTurboModule", {0, rnoh::installTurboModule}}};
}

ReanimatedModule::~ReanimatedModule() {
    DLOG(INFO) << "ReanimatedModule::~ReanimatedModule";
    if (eventListener) {
        m_ctx.scheduler->removeEventListener(eventListener);
    }
    if (keyboardEventDataUpdater_) {
        keyboardEventDataUpdater_ = nullptr;
    }
    if (auto nativeReanimatedModule = weakNativeReanimatedModule_.lock()) {
        nativeReanimatedModule->cleanupSensors();
    }
}

void ReanimatedModule::installTurboModule(facebook::jsi::Runtime &rt) {
    if (!m_ctx.taskExecutor->isOnTaskThread(rnoh::TaskThread::JS)) {
        DLOG(ERROR) << "[reanimated] reanimated installTurboModule failed,because of current thread is not js;";
        return;
    }
    auto runMainThreadFuc = [weakExecutor = std::weak_ptr(m_ctx.taskExecutor)](TaskExecutor::Task &&task) {
        if (auto taskExecutor = weakExecutor.lock()) {
            taskExecutor->runTask(TaskThread::MAIN, std::move(task));
        }
    };
    auto nodesManager = std::make_shared<ReanimatedNodesManager>(runMainThreadFuc);

    auto maybeFlushUIUpdatesQueueFunction = [nodesManager]() { nodesManager->maybeFlushUIUpdatesQueue(); };
    auto requestRender = [weakSelf = weak_from_this(), nodesManager](std::function<void(double)> onRender) {
        auto self = weakSelf.lock();
        if (!self) {
            return;
        }

        nodesManager->postOnAnimation(
            [weakReanimatedModule = self->weakNativeReanimatedModule_, onRender = std::move(onRender)](auto frameTime) {
                if (auto reanimatedModule = weakReanimatedModule.lock()) {
                    onRender(frameTime);
                }
            });
    };

    auto getAnimationTimestamp = getMillisSinceEpoch;

    auto synchronouslyUpdateUIPropsFunction = [weakInstance = m_ctx.instance](Tag tag, const folly::dynamic &dynamic) {
        auto instance = weakInstance.lock();
        auto instanceCapi = std::dynamic_pointer_cast<RNInstanceCAPI>(instance);
        if (!instanceCapi) {
            return;
        }
        auto componentInstance = instanceCapi->findComponentInstanceByTag(tag);
        if (!componentInstance) {
            return;
        }

        // We want to restore the ignored props after the update,
        // because reanimated handles setting correct props on React renders on its own
        auto ignoredProps = componentInstance->getIgnoredPropKeys();
        instanceCapi->synchronouslyUpdateViewOnUIThread(tag, dynamic);
        componentInstance->setIgnoredPropKeys(std::move(ignoredProps));
    };
    auto sensorContainer = std::make_shared<ReanimatedSensorContainer>();


    auto registerSensorFunction = [sensorContainer,
                                   runMainThreadFuc](int sensorType, int interval, int iosReferenceFrame,
                                                     std::function<void(double[], int)> setter) -> int {
        return sensorContainer->registerSensor(sensorType, interval, iosReferenceFrame, setter, runMainThreadFuc);
    };
    auto unregisterSensorFunction = [sensorContainer](int sensorId) { sensorContainer->unregisterSensor(sensorId); };
    auto subscribeForKeyboardEventsFunction =
        [weakSelf = weak_from_this()](std::function<void(int keyboardState, int height)> keyboardEventDataUpdater,
                                      bool isStatusBarTranslucent, bool isNavigationBarTranslucent) {
            auto self = weakSelf.lock();
            if (!self) {
                return 0;
            }
            self->keyboardEventDataUpdater_ = std::move(keyboardEventDataUpdater);
            auto weakExecutor = std::weak_ptr(self->m_ctx.taskExecutor);
            if (auto taskExecutor = weakExecutor.lock()) {
                taskExecutor->runTask(TaskThread::MAIN, [ctx = self->m_ctx, isStatusBarTranslucent, isNavigationBarTranslucent]() {
                    ArkJS arkJs(ctx.env);
                    auto napiTurboModuleObject = arkJs.getObject(ctx.arkTSTurboModuleInstanceRef);
                    napiTurboModuleObject.call("subscribeKeyBordListeners", {
                        arkJs.createBoolean(isStatusBarTranslucent),
                        arkJs.createBoolean(isNavigationBarTranslucent),
                    });
                });
            }
            return 0;
        };
    auto unsubscribeFromKeyboardEventsFunction = [weakSelf = weak_from_this()](int listenerId) {
        auto self = weakSelf.lock();
        if (!self) {
            return 0;
        }
        auto weakExecutor = std::weak_ptr(self->m_ctx.taskExecutor);
        if (auto taskExecutor = weakExecutor.lock()) {
            taskExecutor->runTask(TaskThread::MAIN, [ctx = self->m_ctx]() {
                ArkJS arkJs(ctx.env);
                auto napiTurboModuleObject = arkJs.getObject(ctx.arkTSTurboModuleInstanceRef);
                napiTurboModuleObject.call("unsubscribeKeyBordListeners", {});
            });
        }
        return 0;
    };
    auto setGestureStateFunction = [weakSelf = weak_from_this()](int handlerTag, int newState) {
        auto self = weakSelf.lock();
        if (!self) {
            return;
        }
        ArkJS arkJs(self->m_ctx.env);
        auto napiTag = arkJs.createInt(handlerTag);
        auto napiState = arkJs.createInt(newState);
        auto napiTurboModuleObject = arkJs.getObject(self->m_ctx.arkTSTurboModuleInstanceRef);
        napiTurboModuleObject.call("setGestureHandlerState", {napiTag, napiState});
    };

    auto pseudoSelectorManager = std::make_shared<PseudoSelectorManager>(
        [weakInstance = std::weak_ptr(m_ctx.instance)](facebook::react::Tag tag) {
            std::vector<facebook::react::Tag> chain;
            auto instance = weakInstance.lock();
            auto instanceCapi = std::dynamic_pointer_cast<RNInstanceCAPI>(instance);
            if (!instanceCapi) {
                chain.push_back(tag);
                return chain;
            }
            auto componentInstance = instanceCapi->findComponentInstanceByTag(tag);
            while (componentInstance != nullptr && chain.size() < 512) {
                chain.push_back(componentInstance->getTag());
                componentInstance = componentInstance->getParent().lock();
            }
            if (chain.empty()) {
                chain.push_back(tag);
            }
            return chain;
        });
    pseudoSelectorManager_ = pseudoSelectorManager;
    auto attachPseudoSelector = [pseudoSelectorManager](Tag tag, PseudoSelector pseudoSelector,
                                                        std::function<void(bool)> callback) {
        pseudoSelectorManager->attach(tag, pseudoSelector, std::move(callback));
    };
    auto detachPseudoSelector = [pseudoSelectorManager](Tag tag, PseudoSelector pseudoSelector) {
        pseudoSelectorManager->detach(tag, pseudoSelector);
    };

    // CSS transition routing backend (IOS_CSS_CORE_ANIMATION flag)
    auto cssPlatformTransitions = std::make_shared<css::OHOSCSSPlatformTransitions>(
        m_ctx.instance, std::weak_ptr(m_ctx.taskExecutor));
    auto cssCanRouteProperty = [](const std::string &propertyName, const css::EasingConfig &easing) {
        return css::canRouteCSSProperty(propertyName, easing);
    };
    auto cssApplyTransitionJSI = [cssPlatformTransitions](
                                     jsi::Runtime &rt,
                                     Tag viewTag,
                                     const std::string &propertyName,
                                     const jsi::Value &fromValue,
                                     const jsi::Value &toValue,
                                     const css::CSSTransitionPropertySettings &settings,
                                     double timestamp) {
        return cssPlatformTransitions->applyTransitionForTag(
            rt, viewTag, propertyName, fromValue, toValue, settings, timestamp);
    };
    auto cssApplyTransitionDynamic = [cssPlatformTransitions](
                                         Tag viewTag,
                                         const std::string &propertyName,
                                         const folly::dynamic &fromValue,
                                         const folly::dynamic &toValue,
                                         double timestamp) {
        return cssPlatformTransitions->applyDynamicTransitionForTag(
            viewTag, propertyName, fromValue, toValue, timestamp);
    };
    auto cssRemoveTransition = [cssPlatformTransitions](
                                   Tag viewTag, const std::string &propertyName) {
        cssPlatformTransitions->removeTransitionForTag(viewTag, propertyName);
    };

    PlatformDepMethodsHolder platformDepMethodsHolder = {
        requestRender,
        synchronouslyUpdateUIPropsFunction,
        getAnimationTimestamp,
        registerSensorFunction,
        unregisterSensorFunction,
        setGestureStateFunction,
        subscribeForKeyboardEventsFunction,
        unsubscribeFromKeyboardEventsFunction,
        maybeFlushUIUpdatesQueueFunction,
        attachPseudoSelector,
        detachPseudoSelector,
        cssCanRouteProperty,
        cssApplyTransitionJSI,
        cssApplyTransitionDynamic,
        cssRemoveTransition,
    };
    bool isReducedMotion = false; // ANIMATOR_DURATION_SCALE
    m_ctx.taskExecutor->runSyncTask(TaskThread::MAIN,
        [ctx = m_ctx, &isReducedMotion]() {
            if (!ctx.arkTSTurboModuleInstanceRef) {
                return;
            }
            ArkJS arkJs(ctx.env);
            auto napiTurboModuleObject =
                arkJs.getObject(ctx.arkTSTurboModuleInstanceRef);
            auto napiResult =
                napiTurboModuleObject.call("isReducedMotionEnabled", {});
            isReducedMotion = arkJs.getBoolean(napiResult);
        });
    
    auto workletsModule = [weakSelf = weak_from_this()]() -> std::shared_ptr<WorkletsModule> {
        auto self = weakSelf.lock();
        if (!self) {
            return nullptr;
        }
        auto instance = self->m_ctx.instance.lock();
        if (instance == nullptr) {
            return nullptr;
        }
        return instance->getTurboModule<WorkletsModule>("WorkletsModule");
    };
    auto workletsModuleInstance = workletsModule();
    if (workletsModuleInstance == nullptr) {
        DLOG(ERROR) << "[reanimated] WorkletsModule not found; install worklets before reanimated";
        return;
    }
    auto workletsProxy = workletsModuleInstance->getWorkletsModuleProxy();
    if (workletsProxy == nullptr) {
        DLOG(ERROR) << "[reanimated] WorkletsModuleProxy not initialized yet "
                      "(installTurboModule must run first)";
        return;
    }

    auto reanimatedModuleProxy = std::make_shared<ReanimatedModuleProxy>(
        workletsProxy->getUIWorkletRuntime(), workletsProxy->getUIScheduler(), rt, jsInvoker_,
        platformDepMethodsHolder, isReducedMotion);
    reanimatedModuleProxy->init(platformDepMethodsHolder);
    nativeReanimatedModule_ = reanimatedModuleProxy;
    weakNativeReanimatedModule_ = reanimatedModuleProxy;

    ReanimatedPerformOperations reanimatedPerformOperations = [weakNativeReanimatedModule =
                                                                   weakNativeReanimatedModule_]() {
        if (auto nativeReanimatedModule = weakNativeReanimatedModule.lock()) {
            nativeReanimatedModule->performOperations();
        }
    };
    nodesManager->registerPerformOperations(reanimatedPerformOperations);

    WorkletRuntimeCollector::install(rt);
    auto &uiRuntime = workletsProxy->getUIWorkletRuntime()->getJSIRuntime();

    RNRuntimeDecorator::decorate(rt, uiRuntime, reanimatedModuleProxy);
    injectDependencies(rt);

    eventListener = std::make_shared<facebook::react::EventListener>(
        [weakNativeReanimatedModule = weakNativeReanimatedModule_,
         weakTaskExecutor = std::weak_ptr{m_ctx.taskExecutor},
         pseudoSelectorManager](facebook::react::RawEvent const &rawEvent) {
            auto taskExecutor = weakTaskExecutor.lock();
            auto nativeReanimatedModule = weakNativeReanimatedModule.lock();
            if (!nativeReanimatedModule || !taskExecutor || !taskExecutor->isOnTaskThread(TaskThread::MAIN)) {
                return false;
            }

            auto eventType = rawEvent.type;
            auto frameTime = getMillisSinceEpoch();
    
            pseudoSelectorManager->handleRawEvent(rawEvent);
            if (eventType.rfind("topOn", 0) == 0) {
                auto eventCopy = rawEvent;
                eventCopy.type = "on" + eventType.substr(5);
                return nativeReanimatedModule->handleRawEvent(eventCopy, frameTime);
            } else if (eventType.rfind("topLayout", 0) == 0) { // 针对onLayout事件，不阻断，采用系统处理
                return false;
            }
            return nativeReanimatedModule->handleRawEvent(rawEvent, frameTime);
        });
    m_ctx.scheduler->addEventListener(eventListener);
}
void ReanimatedModule::injectDependencies(facebook::jsi::Runtime & /* rt */) {
    const auto uiManager = m_ctx.scheduler->getUIManager();
    if (auto nativeReanimatedModule = weakNativeReanimatedModule_.lock()) {
        nativeReanimatedModule->initializeFabric(uiManager);
    }
}

void ReanimatedModule::callKeyBord(double height, int status) {
    if (keyboardEventDataUpdater_) {
        keyboardEventDataUpdater_(status, height);
    }
}
} // namespace rnoh