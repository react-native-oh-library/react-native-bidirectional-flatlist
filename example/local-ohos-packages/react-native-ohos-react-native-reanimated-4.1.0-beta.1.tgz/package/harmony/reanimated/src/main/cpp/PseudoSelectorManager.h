// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#pragma once

#include <react/renderer/core/ReactPrimitives.h>
#include <react/renderer/core/RawEvent.h>
#include <reanimated/PseudoStyles/PseudoSelector.h>

#include <functional>
#include <map>
#include <mutex>
#include <optional>
#include <unordered_map>
#include <unordered_set>
#include <vector>

namespace rnoh {

class PseudoSelectorManager {
public:
    using SelectorStateCallback = std::function<void(bool)>;
    using AncestryProvider = std::function<std::vector<facebook::react::Tag>(facebook::react::Tag)>;

    explicit PseudoSelectorManager(AncestryProvider ancestryProvider);

    void attach(facebook::react::Tag tag, reanimated::PseudoSelector selector, SelectorStateCallback callback);
    void detach(facebook::react::Tag tag, reanimated::PseudoSelector selector);
    void handleRawEvent(facebook::react::RawEvent const &rawEvent);

private:
    struct Entry {
        SelectorStateCallback callback;
        bool lastReported = false;
    };

    void recomputeAndNotify();

    AncestryProvider m_ancestryProvider;
    
    std::mutex m_mutex;
    std::unordered_map<facebook::react::Tag, std::map<reanimated::PseudoSelector, Entry>> m_entries;
    
    std::unordered_set<facebook::react::Tag> m_hoveredTags;
    std::unordered_map<facebook::react::Tag, size_t> m_pressedTouchCounts;
    std::unordered_map<facebook::react::Tag, std::vector<facebook::react::Tag>> m_pressedChains;
    std::optional<facebook::react::Tag> m_focusedTag;
    std::unordered_set<facebook::react::Tag> m_focusedChain;
};

} // namespace rnoh
