// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#ifndef HARMONY_REANIMATEDSENSORCONTAINER_H
#define HARMONY_REANIMATEDSENSORCONTAINER_H
#include "ReanimatedSensor.h"
#include <functional>
namespace rnoh {
class ReanimatedSensorContainer {
public:
    ReanimatedSensorContainer();
    ~ReanimatedSensorContainer() noexcept = default;
    int registerSensor(int sensorType, int interval, int iosReferenceFrame, std::function<void(double[], int)> setter,
                       std::function<void(TaskExecutor::Task &&)> runOnTheMainThread);
    void unregisterSensor(int sensorId);

private:
    std::unordered_map<int, std::shared_ptr<ReanimatedSensor>> sensorMap_;
    int nextSensorId{0};
};
} // namespace rnoh
#endif // HARMONY_REANIMATEDSENSORCONTAINER_H
