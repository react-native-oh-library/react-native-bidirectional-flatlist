// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#include "ReanimatedPackage.h"
#include "ReanimatedModule.h"
#include "REASharedTransitionBoundaryComponentInstance.h"

#include "REASharedTransitionBoundaryJSIBinder.h"
#include "Common/NativeView/react/renderer/components/rnreanimated/REASharedTransitionBoundaryComponentDescriptor.h"

using namespace rnoh;
using namespace facebook;

class ReanimatedTurboModuleFactoryDelegate : public TurboModuleFactoryDelegate {
public:
    SharedTurboModule createTurboModule(Context ctx, const std::string &name) const override
    {
        if (name == "ReanimatedModule") {
            return std::make_shared<ReanimatedModule>(ctx, name);
        }
        return nullptr;
    };
};

std::unique_ptr<TurboModuleFactoryDelegate> ReanimatedPackage::createTurboModuleFactoryDelegate()
{
    return std::make_unique<ReanimatedTurboModuleFactoryDelegate>();
}

class ReanimatedArkTsMessage : public ArkTSMessageHandler {
    void handleArkTSMessage(const Context &ctx) override
    {
        auto rnInstance = ctx.rnInstance.lock();
        if (rnInstance) {
            if (ctx.messageName == "REANIMATED_KEY_BOARD_CHANGE") {
                auto keyboardHeight = ctx.messagePayload["keyboardHeight"].asDouble();
                auto status = ctx.messagePayload["status"].asInt();
                rnInstance->getTurboModule<ReanimatedModule>("ReanimatedModule")->callKeyBord(keyboardHeight, status);
            }
        }
    }
};

std::vector<ArkTSMessageHandler::Shared> ReanimatedPackage::createArkTSMessageHandlers()
{
    return { std::make_shared<ReanimatedArkTsMessage>() };
}

std::vector<react::ComponentDescriptorProvider> ReanimatedPackage::createComponentDescriptorProviders()
{
    return { react::concreteComponentDescriptorProvider<
        react::REASharedTransitionBoundaryComponentDescriptor>() };
}

ComponentInstance::Shared ReanimatedPackage::createComponentInstance(const ComponentInstance::Context& ctx)
{
    if (ctx.componentName == "REASharedTransitionBoundary") {
        return std::make_shared<REASharedTransitionBoundaryComponentInstance>(ctx);
    }
    return Package::createComponentInstance(ctx);
}

ComponentJSIBinderByString ReanimatedPackage::createComponentJSIBinderByName()
{
    return { { "REASharedTransitionBoundary", std::make_shared<REASharedTransitionBoundaryJSIBinder>() } };
}
