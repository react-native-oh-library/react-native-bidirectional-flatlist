// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#ifndef HARMONY_REANIMATEDSENSOR_H
#define HARMONY_REANIMATEDSENSOR_H
#include <array>
#include <functional>
#include <mutex>
#include <sensors/oh_sensor_type.h>
#include "RNOH/TaskExecutor/TaskExecutor.h"

namespace rnoh {
class ReanimatedSensor : public std::enable_shared_from_this<ReanimatedSensor> {
public:
    ReanimatedSensor(int sensorType, int interval, int iosReferenceFrame, std::function<void(double[], int)> setter,
                     std::function<void(TaskExecutor::Task &&)> runOnTheMainThread);
    ~ReanimatedSensor();
    bool initialize();
    void cancel();
    void castSensorType(int sensorType);
    void runSensor(std::array<double, 7> value);
    std::function<void(double[], int)> setter_;
    Sensor_Type sensorType_{SENSOR_TYPE_ACCELEROMETER};

private:
    void destroySensor();
    bool isSupportSensor();
    int getInterfaceOrientation();
    int interval_{-1};
    int iosReferenceFrame_{-1};
    Sensor_Subscriber *subSensor_{nullptr};
    Sensor_SubscriptionId *id_{nullptr};
    Sensor_SubscriptionAttribute *attr_{nullptr};
    std::function<void(TaskExecutor::Task &&)> runOnTheMainThread_;
};
} // namespace rnoh
#endif // HARMONY_REANIMATEDSENSOR_H
