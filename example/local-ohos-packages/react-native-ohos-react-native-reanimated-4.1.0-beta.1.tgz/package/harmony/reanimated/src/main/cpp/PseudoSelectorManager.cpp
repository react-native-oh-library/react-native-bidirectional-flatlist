// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#include "PseudoSelectorManager.h"

namespace rnoh {

using reanimated::PseudoSelector;

PseudoSelectorManager::PseudoSelectorManager(AncestryProvider ancestryProvider)
    : m_ancestryProvider(std::move(ancestryProvider)) {}

void PseudoSelectorManager::attach(facebook::react::Tag tag, PseudoSelector selector,
                                   SelectorStateCallback callback) {
    std::lock_guard<std::mutex> lock(m_mutex);
    m_entries[tag][selector] = Entry{std::move(callback), false};
}

void PseudoSelectorManager::detach(facebook::react::Tag tag, PseudoSelector selector) {
    std::lock_guard<std::mutex> lock(m_mutex);
    auto it = m_entries.find(tag);
    if (it == m_entries.end()) {
        return;
    }
    it->second.erase(selector);
    if (it->second.empty()) {
        m_entries.erase(it);
    }
}

void PseudoSelectorManager::handleRawEvent(facebook::react::RawEvent const &rawEvent) {
    const auto &type = rawEvent.type;
    const bool isPointerEvent = type == "topPointerEnter" || type == "topPointerLeave";
    const bool isTouchEvent = type == "topTouchStart" || type == "topTouchEnd" || type == "topTouchCancel";
    const bool isFocusEvent = type == "topFocus" || type == "topBlur";
    if (!isPointerEvent && !isTouchEvent && !isFocusEvent) {
        return;
    }

    if (rawEvent.eventTarget == nullptr) {
        return;
    }
    const auto tag = rawEvent.eventTarget->getTag();

    if (type == "topPointerEnter") {
        m_hoveredTags.insert(tag);
    } else if (type == "topPointerLeave") {
        m_hoveredTags.erase(tag);
    } else if (type == "topTouchStart") {
        if (m_pressedTouchCounts[tag]++ == 0) {
            m_pressedChains[tag] = m_ancestryProvider ? m_ancestryProvider(tag)
                                                      : std::vector<facebook::react::Tag>{tag};
        }
    } else if (type == "topTouchEnd" || type == "topTouchCancel") {
        auto it = m_pressedTouchCounts.find(tag);
        if (it != m_pressedTouchCounts.end() && --it->second == 0) {
            m_pressedTouchCounts.erase(it);
            m_pressedChains.erase(tag);
        }
    } else if (type == "topFocus") {
        m_focusedTag = tag;
        m_focusedChain.clear();
        if (m_ancestryProvider) {
            for (auto ancestor : m_ancestryProvider(tag)) {
                m_focusedChain.insert(ancestor);
            }
        } else {
            m_focusedChain.insert(tag);
        }
    } else { // topBlur
        if (m_focusedTag.has_value() && *m_focusedTag == tag) {
            m_focusedTag.reset();
            m_focusedChain.clear();
        }
    }

    recomputeAndNotify();
}

void PseudoSelectorManager::recomputeAndNotify() {
    std::vector<std::pair<SelectorStateCallback, bool>> notifications;
    {
        std::lock_guard<std::mutex> lock(m_mutex);
        if (m_entries.empty()) {
            return;
        }
        
        std::unordered_set<facebook::react::Tag> pressedTags;
        std::unordered_set<facebook::react::Tag> deepestActiveTags;
        for (const auto &entry : m_pressedChains) {
            bool deepestFound = false;
            for (auto chainTag : entry.second) {
                pressedTags.insert(chainTag);
                if (!deepestFound) {
                    auto tagIt = m_entries.find(chainTag);
                    if (tagIt != m_entries.end() && tagIt->second.count(PseudoSelector::ActiveDeepest) > 0) {
                        deepestActiveTags.insert(chainTag);
                        deepestFound = true;
                    }
                }
            }
        }

        for (auto &tagEntry : m_entries) {
            const auto tag = tagEntry.first;
            for (auto &selectorEntry : tagEntry.second) {
                const auto selector = selectorEntry.first;
                auto &entry = selectorEntry.second;
                bool active = false;
                switch (selector) {
                    case PseudoSelector::Hover:
                        active = m_hoveredTags.count(tag) > 0;
                        break;
                    case PseudoSelector::Active:
                        active = pressedTags.count(tag) > 0;
                        break;
                    case PseudoSelector::ActiveDeepest:
                        active = deepestActiveTags.count(tag) > 0;
                        break;
                    case PseudoSelector::Focus:
                        active = m_focusedTag.has_value() && *m_focusedTag == tag;
                        break;
                    case PseudoSelector::FocusWithin:
                        active = m_focusedChain.count(tag) > 0;
                        break;
                }
                if (active != entry.lastReported) {
                    entry.lastReported = active;
                    notifications.emplace_back(entry.callback, active);
                }
            }
        }
    }
    for (auto &notification : notifications) {
        notification.first(notification.second);
    }
}

} // namespace rnoh
