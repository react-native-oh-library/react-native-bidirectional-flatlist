// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

import { RNOHLogger, Tag, UITurboModule, UITurboModuleContext } from "@rnoh/react-native-openharmony/ts";
import { Animator, AnimatorResult, window } from '@kit.ArkUI';
import { KeyboardState } from "./KeyboardState";
import deviceInfo from '@ohos.deviceInfo';
import { accessibility } from '@kit.AccessibilityKit';

export class ReanimatedModule extends UITurboModule {
  static NAME = "ReanimatedModule"
  private logger: RNOHLogger
  private keyBordHeight = 0;
  private currentAnimator: AnimatorResult | null = null;
  private currentAnimatedHeight = 0;

  constructor(ctx: UITurboModuleContext) {
    super(ctx);
    this.logger = ctx.logger.clone("Reanimated");
  }

  public setViewProps(tag: Tag, props: Object) {
    this.ctx.descriptorRegistry.setAnimatedRawProps(tag, props);
  }

  public async subscribeKeyBordListeners(isStatusBarTranslucent: boolean, isNavigationBarTranslucent: boolean) {
    //ignore isStatusBarTranslucent  - those are Android only
    let windowInstance: window.Window;
    try {
      windowInstance = await window.getLastWindow(this.ctx.uiAbilityContext);
    } catch (e: ESObject) {
      this.logger.error(`subscribeKeyBordListeners failed: ${e?.message ?? e}`);
      return;
    }
    const navIndicatorArea = windowInstance.getWindowAvoidArea(
      window.AvoidAreaType.TYPE_NAVIGATION_INDICATOR
    );
    const navIndicatorHeight = this.ctx.getUIContext().px2vp(
      navIndicatorArea.bottomRect.height
    );

    const isEdgeToEdge = this.isEdgeToEdgeMode(windowInstance);
    const effectiveNavBarTranslucent = isEdgeToEdge && isNavigationBarTranslucent;

    windowInstance.on('keyboardHeightChange', async (height) => {
      let rawKeyboardHeight = this.ctx.getUIContext().px2vp(height);
      //If the immersive mode is not enabled, then the area around the bottom navigation bar that needs to be avoided needs to be removed.
      //If the immersive mode is enabled, the returned value will be the height of the current keyboard.
      let keyBordHeight = effectiveNavBarTranslucent
        ? rawKeyboardHeight
        : Math.max(0, rawKeyboardHeight - navIndicatorHeight);

      //Unchanged height, skip handle
      if (Math.abs(keyBordHeight - this.currentAnimatedHeight) < 0.01) {
        return;
      }

      const isOpening = keyBordHeight > this.keyBordHeight;

      if (this.currentAnimator) {
        this.currentAnimator.onFrame = null;
        this.currentAnimator.onFinish = null;
        this.currentAnimator.cancel();
        this.currentAnimator = null;
      }

      this.currentAnimator = Animator.create({
        duration: isOpening ? 480 : 350,
        delay: 0,
        //simulate the keyboard pop-up and retraction animations in harmony
        easing: isOpening ? "cubic-bezier(0.2, 0.0, 0.1, 1.0)"
          : "cubic-bezier(0.0, 0.0, 0.1, 1.0)",
        fill: "forwards",
        direction: "normal",
        iterations: 1,
        begin: this.currentAnimatedHeight,
        end: keyBordHeight
      }
      )
      this.currentAnimator.onFrame = (progress: number) => {
        this.currentAnimatedHeight = progress;
        if (Math.abs(progress - keyBordHeight) < 0.01) { //The final instruction is sent by "onFinish".
          return;
        }
        let status = keyBordHeight > this.keyBordHeight ? KeyboardState.OPENING : KeyboardState.CLOSING;
        this.ctx.rnInstance.postMessageToCpp("REANIMATED_KEY_BOARD_CHANGE",
          { keyboardHeight: progress, status: status.valueOf() });
      }
      this.currentAnimator.onFinish = () => {
        this.currentAnimatedHeight = keyBordHeight;
        let status = keyBordHeight > this.keyBordHeight ? KeyboardState.OPEN : KeyboardState.CLOSED;
        this.keyBordHeight = keyBordHeight;
        this.ctx.rnInstance.postMessageToCpp("REANIMATED_KEY_BOARD_CHANGE",
          { keyboardHeight: keyBordHeight, status: status.valueOf() });
      }
      this.currentAnimator.play();
    })
  }

  public async unsubscribeKeyBordListeners() {
    let windowInstance: window.Window;
    try {
      windowInstance = await window.getLastWindow(this.ctx.uiAbilityContext);
    } catch (e: ESObject) {
      this.logger.error(`unsubscribeKeyBordListeners failed: ${e?.message ?? e}`);
      return;
    }
    windowInstance.off('keyboardHeightChange')
    if (this.currentAnimator) {
      this.currentAnimator.onFrame = null;
      this.currentAnimator.onFinish = null;
      this.currentAnimator.cancel();
      this.currentAnimator = null;
    }
    this.keyBordHeight = 0;
    this.currentAnimatedHeight = 0;
  }

  public setGestureHandlerState(handlerTag: Tag, newState: number) {
    const module = this.ctx.rnInstance.getTurboModule("RNGestureHandlerModule") as any;
    if (module && module.setGestureHandlerState) {
      module.setGestureHandlerState(handlerTag, newState);
    }
  }

  private isEdgeToEdgeMode(windowInstance: window.Window) {
    let isLayoutFullScreen = false;
    try {
      const windowProperties = windowInstance.getWindowProperties();
      isLayoutFullScreen = windowProperties.isLayoutFullScreen;
    } catch (e: ESObject) {
      isLayoutFullScreen = false;
    }
    return isLayoutFullScreen;
  }

  public isReducedMotionEnabled(): boolean {
    try {
      if (deviceInfo.sdkApiVersion >= 23) {
        return (accessibility as ESObject).isAnimationReduceEnabledSync();
      }
    } catch (e) {
      this.logger.warn(`isReducedMotionEnabled failed: ${JSON.stringify(e)}`);
    }
    return false;
  }

  __onDestroy__(): void {
    this.unsubscribeKeyBordListeners();
  }
}
