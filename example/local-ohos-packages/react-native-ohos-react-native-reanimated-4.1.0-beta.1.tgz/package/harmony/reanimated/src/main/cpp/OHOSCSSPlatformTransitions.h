// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#pragma once

#include <reanimated/CSS/configs/CSSTransitionConfig.h>
#include <reanimated/CSS/utils/platform.h>
#include <reanimated/CSS/utils/reversingShortening.h>

#include <folly/dynamic.h>
#include <jsi/jsi.h>
#include <react/renderer/core/ReactPrimitives.h>

#include <functional>
#include <memory>
#include <mutex>
#include <string>
#include <unordered_map>

namespace rnoh {
class RNInstance;
class TaskExecutor;
} // namespace rnoh

namespace reanimated::css {

// Per-property state for an in-flight native transition. adjustedStart/adjustedEnd
// and the reversing snapshot handle interruptions; settings are reused by the
// toggle path. (Mirrors the Apple backend's ActiveTransition.)
struct ActiveTransition {
  PlatformValue adjustedStart;
  PlatformValue adjustedEnd;
  ReversingState reversing;
  CSSTransitionPropertySettings settings;
};

/// ArkUI-backed CSS transition backend — the OHOS counterpart of Apple's
/// REACSSPlatformTransitions. Routed properties animate via
/// ArkUI_NativeAnimateAPI_1::animateTo on the real UI nodes (implicit
/// attribute animation) instead of being interpolated per-frame on the
/// reanimated loop.
///
/// The state map is mutex-guarded (routing can arrive from the JS thread as
/// well as the operations loop); the ArkUI work always runs on MAIN and the
/// posted closures only carry copies, never map references.
class OHOSCSSPlatformTransitions {
 public:
  OHOSCSSPlatformTransitions(
      std::weak_ptr<rnoh::RNInstance> instance,
      std::weak_ptr<rnoh::TaskExecutor> taskExecutor);

  /// Config path (CSSPlatformTransitionProxy's applyJSI hook). Returns false
  /// when the platform can't express an endpoint — the proxy then falls back
  /// to the loop for this property.
  bool applyTransitionForTag(
      facebook::jsi::Runtime &rt,
      react::Tag viewTag,
      const std::string &propertyName,
      const facebook::jsi::Value &fromValue,
      const facebook::jsi::Value &toValue,
      const CSSTransitionPropertySettings &settings,
      double timestamp);

  /// Pseudo-selector toggle path: reuses the settings of the active transition.
  bool applyDynamicTransitionForTag(
      react::Tag viewTag,
      const std::string &propertyName,
      const folly::dynamic &fromValue,
      const folly::dynamic &toValue,
      double timestamp);

  /// Cancels the property's native transition and drops its platform-side state.
  void removeTransitionForTag(react::Tag viewTag, const std::string &propertyName);

 private:
  // Reverse-shortens against any in-flight transition (W3C reversing),
  // records the new active state and kicks off the ArkUI animation.
  void applyForTag(
      react::Tag viewTag,
      const std::string &propertyName,
      const PlatformValue &fromValue,
      const PlatformValue &toValue,
      const CSSTransitionPropertySettings &settings,
      double timestamp);

  void runOnMain(std::function<void()> task);

  std::unordered_map<react::Tag, std::unordered_map<std::string, ActiveTransition>> active_;
  std::mutex mutex_;
  std::weak_ptr<rnoh::RNInstance> instance_;
  std::weak_ptr<rnoh::TaskExecutor> taskExecutor_;
};

} // namespace reanimated::css
