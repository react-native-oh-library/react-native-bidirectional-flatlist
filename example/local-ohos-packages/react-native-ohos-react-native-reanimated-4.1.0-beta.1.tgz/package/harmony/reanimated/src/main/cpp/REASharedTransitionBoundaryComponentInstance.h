// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#pragma once

#include "Common/NativeView/react/renderer/components/rnreanimated/REASharedTransitionBoundaryShadowNode.h"
#include "RNOH/CppComponentInstance.h"
#include "RNOH/arkui/CustomNode.h"

namespace rnoh {

class REASharedTransitionBoundaryComponentInstance
    : public CppComponentInstance<facebook::react::REASharedTransitionBoundaryShadowNode> {
 private:
  CustomNode m_customNode;

 public:
  explicit REASharedTransitionBoundaryComponentInstance(Context context);

  void onChildInserted(
      ComponentInstance::Shared const& childComponentInstance,
      std::size_t index) override;

  void onChildRemoved(
      ComponentInstance::Shared const& childComponentInstance) override;

  CustomNode& getLocalRootArkUINode() override;

  void onLayoutChanged(facebook::react::LayoutMetrics const& layoutMetrics) override;
};

} // namespace rnoh
