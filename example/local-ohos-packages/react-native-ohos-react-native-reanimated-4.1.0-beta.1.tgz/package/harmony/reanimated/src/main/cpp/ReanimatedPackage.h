// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.
#include "RNOH/Package.h"

namespace rnoh {
class ReanimatedPackage : public Package {
public:
    ReanimatedPackage(Package::Context ctx) : Package(ctx) {}

    std::unique_ptr<TurboModuleFactoryDelegate> createTurboModuleFactoryDelegate() override;

    std::vector<ArkTSMessageHandler::Shared> createArkTSMessageHandlers() override;

    std::vector<facebook::react::ComponentDescriptorProvider> createComponentDescriptorProviders() override;

    ComponentInstance::Shared createComponentInstance(const ComponentInstance::Context& ctx) override;

    ComponentJSIBinderByString createComponentJSIBinderByName() override;
};
} // namespace rnoh
