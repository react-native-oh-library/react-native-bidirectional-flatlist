// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#include "ReanimatedSensorContainer.h"
#include "glog/logging.h"
namespace rnoh {

rnoh::ReanimatedSensorContainer::ReanimatedSensorContainer() {}

int rnoh::ReanimatedSensorContainer::registerSensor(int sensorType, int interval, int iosReferenceFrame,
                                                    std::function<void(double *, int)> setter,
                                                    std::function<void(TaskExecutor::Task &&)> runOnTheMainThread) {
    auto sensor =
        std::make_shared<ReanimatedSensor>(sensorType, interval, iosReferenceFrame, setter, runOnTheMainThread);
    int sensorId = -1;
    if (sensor->initialize()) {
        sensorId = nextSensorId;
        nextSensorId++;
        sensorMap_[sensorId] = sensor;
    }
    return sensorId;
}

void rnoh::ReanimatedSensorContainer::unregisterSensor(int sensorId) {
    auto it = sensorMap_.find(sensorId);
    if (it == sensorMap_.end()) {
        return;
    }
    auto sensor = it->second;
    if (sensor != nullptr) {
        sensor->cancel();
        sensorMap_.erase(it);
    }
}
}