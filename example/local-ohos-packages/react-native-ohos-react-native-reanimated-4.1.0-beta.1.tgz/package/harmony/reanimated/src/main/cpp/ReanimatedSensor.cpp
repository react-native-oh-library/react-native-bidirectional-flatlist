// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#include "ReanimatedSensor.h"
#include "glog/logging.h"
#include <algorithm>
#include <cmath>
#include <string>
#include <sensors/oh_sensor.h>
#include <window_manager/oh_display_info.h>
#include <window_manager/oh_display_manager.h>
namespace rnoh {
static std::unordered_map<Sensor_Type, ReanimatedSensor *> g_sensorSubscriberMap_;
static std::mutex g_subscriberMapMutex_; // 保护映射表的互斥锁

void SensorDataCallbackImpl(Sensor_Event *event) {
    if (event == nullptr) {
        return;
    }
    int64_t timestamp = -1;
    // 获取传感器数据的时间戳。
    int32_t ret = OH_SensorEvent_GetTimestamp(event, &timestamp);
    if (ret != SENSOR_SUCCESS) {
        return;
    }
    Sensor_Type sensorType;
    // 获取传感器类型。
    ret = OH_SensorEvent_GetType(event, &sensorType);
    if (ret != SENSOR_SUCCESS) {
        return;
    }
    Sensor_Accuracy accuracy = SENSOR_ACCURACY_UNRELIABLE;
    // 获取传感器数据的精度。
    ret = OH_SensorEvent_GetAccuracy(event, &accuracy);
    if (ret != SENSOR_SUCCESS) {
        return;
    }
    float *data = nullptr;
    uint32_t length = 0;
    // 获取传感器数据。
    ret = OH_SensorEvent_GetData(event, &data, &length);
    if (ret != SENSOR_SUCCESS || data == nullptr) {
        return;
    }

    std::lock_guard<std::mutex> lock(g_subscriberMapMutex_);
    auto it = g_sensorSubscriberMap_.find(sensorType);
    if (it == g_sensorSubscriberMap_.end()) {
        return;
    }
    ReanimatedSensor *sensorInstance = it->second;
    if (sensorInstance == nullptr) {
        return;
    }

    switch (sensorType) {
    case SENSOR_TYPE_GYROSCOPE:
    case SENSOR_TYPE_MAGNETIC_FIELD: {
        std::array<double, 7> sendData = {
            data[0],
            data[1],
            data[2],
            0,
            0,
            0,
            0,
        };
        sensorInstance->runSensor(sendData);
        return;
    }
    case SENSOR_TYPE_ACCELEROMETER:
    case SENSOR_TYPE_LINEAR_ACCELERATION:
    case SENSOR_TYPE_GRAVITY: {
        std::array<double, 7> sendData = {
            -data[0],
            -data[1],
            -data[2],
            0,
            0,
            0,
            0,
        };
        sensorInstance->runSensor(sendData);
        return;
    }
    case SENSOR_TYPE_ROTATION_VECTOR: {
        double qx = data[0], qy = data[1], qz = data[2];
        double qw = (length >= 4)
            ? data[3]
            : std::sqrt(std::max(0.0, 1.0 - qx * qx - qy * qy - qz * qz));
        double xx = qx * qx, yy = qy * qy, zz = qz * qz;
        double xy = qx * qy, xz = qx * qz, yz = qy * qz;
        double wx = qw * qx, wy = qw * qy, wz = qw * qz;
        double azimuth = std::atan2(2 * (xy - wz), 1 - 2 * (xx + zz));
        double pitch = std::asin(std::clamp(-2 * (yz + wx), -1.0, 1.0));
        double roll = std::atan2(-2 * (xz - wy), 1 - 2 * (xx + yy));
        std::array<double, 7> sendData = {
            qx,       // qx
            qz,       // qy槽位放qz，对齐iOS参考系（同Android ReanimatedSensorListener.kt）
            -qy,      // qz槽位放-qy
            qw,       // qw
            -azimuth, // yaw
            -pitch,   // pitch
            roll      // roll
        };
        sensorInstance->runSensor(sendData);
        return;
    }
    default:
        return;
    }
}


rnoh::ReanimatedSensor::ReanimatedSensor(int sensorType, int interval, int iosReferenceFrame,
                                         std::function<void(double *, int)> setter,
                                         std::function<void(TaskExecutor::Task &&)> runOnTheMainThread)
    : iosReferenceFrame_(iosReferenceFrame), setter_(std::move(setter)),
      runOnTheMainThread_(std::move(runOnTheMainThread)) {
    if (interval == -1) {
        uint32_t refreshRate = 0;
        OH_NativeDisplayManager_GetDefaultDisplayRefreshRate(&refreshRate);
        if (refreshRate > 0) {
            // 采样周期 = 1/刷新率，换算为纳秒（iOS侧为 1/maximumFramesPerSecond 秒）
            interval_ = 1000000000 / refreshRate;
        } else {
            interval_ = 16666667; // 查询失败时按60Hz周期兜底
        }
    } else {
        // js unit is milliseconds
        interval_ = interval * 1000000;
    }
    castSensorType(sensorType);
}


void rnoh::ReanimatedSensor::castSensorType(int sensorType) {
    if (sensorType == 1) {
        sensorType_ = SENSOR_TYPE_LINEAR_ACCELERATION;
    } else if (sensorType == 2) {
        sensorType_ = SENSOR_TYPE_GYROSCOPE;
    } else if (sensorType == 3) {
        sensorType_ = SENSOR_TYPE_GRAVITY;
    } else if (sensorType == 4) {
        sensorType_ = SENSOR_TYPE_MAGNETIC_FIELD;
    } else if (sensorType == 5) {
        sensorType_ = SENSOR_TYPE_ROTATION_VECTOR;
    } else {
        throw std::invalid_argument("[ReanimatedSensor] Unknown sensorType: " + std::to_string(sensorType));
    }
}

bool rnoh::ReanimatedSensor::initialize() {
    if (!isSupportSensor()) {
        if (sensorType_ == SENSOR_TYPE_LINEAR_ACCELERATION) {
            DLOG(WARNING) << "[ReanimatedSensor] linear acceleration not supported, fallback to accelerometer";
            sensorType_ = SENSOR_TYPE_ACCELEROMETER;
        }
        if (!isSupportSensor()) {
            DLOG(ERROR) << "[ReanimatedSensor] is not support, sensorType:" << sensorType_;
            return false;
        }
    }
    id_ = OH_Sensor_CreateSubscriptionId();
    if (id_ == nullptr) {
        DLOG(ERROR) << "[ReanimatedSensor] create sensor id failed";
        return false;
    }
    int32_t res = OH_SensorSubscriptionId_SetType(id_, sensorType_);
    if (res != SENSOR_SUCCESS) {
        OH_Sensor_DestroySubscriptionId(id_);
        id_ = nullptr;
        DLOG(ERROR) << "[ReanimatedSensor] set sensor type failed ,sensorType:" << sensorType_;
        return false;
    }
    attr_ = OH_Sensor_CreateSubscriptionAttribute();
    if (attr_ == nullptr) {
        DLOG(ERROR) << "[ReanimatedSensor] create sensor attribute failed";
        return false;
    }

    res = OH_SensorSubscriptionAttribute_SetSamplingInterval(attr_, interval_);
    if (res != SENSOR_SUCCESS) {
        OH_Sensor_DestroySubscriptionAttribute(attr_);
        attr_ = nullptr;
        DLOG(ERROR) << "[ReanimatedSensor] set sensor Interval failed, interval_:" << interval_;
        return false;
    }

    subSensor_ = OH_Sensor_CreateSubscriber();

    {
        std::lock_guard<std::mutex> lock(g_subscriberMapMutex_);
        g_sensorSubscriberMap_[sensorType_] = this;
    }

    int32_t ret = OH_SensorSubscriber_SetCallback(subSensor_, SensorDataCallbackImpl);
    if (ret != SENSOR_SUCCESS) {
        OH_Sensor_DestroySubscriptionAttribute(attr_);
        attr_ = nullptr;
        DLOG(ERROR) << "[ReanimatedSensor] set sensor callback failed";
        return false;
    }
    Sensor_Result sensorRes = OH_Sensor_Subscribe(id_, attr_, subSensor_);
    if (sensorRes != SENSOR_SUCCESS) {
        OH_Sensor_DestroySubscriptionAttribute(attr_);
        attr_ = nullptr;
        DLOG(ERROR) << "[ReanimatedSensor] on sensor subscribe failed";
        return false;
    }
    return true;
}


bool rnoh::ReanimatedSensor::isSupportSensor() {
    uint32_t count = 0;
    int32_t ret = OH_Sensor_GetInfos(nullptr, &count);
    bool isSupport = false;
    if (count > 0) {
        Sensor_Info **sensors = OH_Sensor_CreateInfos(count);
        ret = OH_Sensor_GetInfos(sensors, &count);
        for (uint32_t i = 0; i < count; ++i) {
            Sensor_Info *sensorInfoTemp = sensors[i];
            Sensor_Type sensorType;
            ret = OH_SensorInfo_GetType(sensorInfoTemp, &sensorType);
            if (sensorType == sensorType_) {
                isSupport = true;
                break;
            }
        }
        ret = OH_Sensor_DestroyInfos(sensors, count);
    }
    return isSupport;
}

void rnoh::ReanimatedSensor::runSensor(std::array<double, 7> value) {
    if (setter_ && runOnTheMainThread_) {
        runOnTheMainThread_([weakSelf = weak_from_this(), value = std::move(value)]() mutable {
            auto self = weakSelf.lock();
            if (!self) {
                return;
            }
            self->setter_(value.data(), self->getInterfaceOrientation());
        });
    }
}

int rnoh::ReanimatedSensor::getInterfaceOrientation() {
    NativeDisplayManager_Rotation rotation;
    auto ret = OH_NativeDisplayManager_GetDefaultDisplayRotation(&rotation);
    if (ret == DISPLAY_MANAGER_OK) {
        switch (rotation) {
        case DISPLAY_MANAGER_ROTATION_270:
            return 270;
        case DISPLAY_MANAGER_ROTATION_90:
            return 90;
        case DISPLAY_MANAGER_ROTATION_180:
            return 180;
        default:
            return 0;
        }
    }
    return 0;
}


void rnoh::ReanimatedSensor::cancel() { destroySensor(); }

void rnoh::ReanimatedSensor::destroySensor() {
    std::lock_guard<std::mutex> lock(g_subscriberMapMutex_);
    for (auto it = g_sensorSubscriberMap_.begin(); it != g_sensorSubscriberMap_.end();) {
        if (it->second == this) {
            if (it->second->id_ && it->second->subSensor_) {
                OH_Sensor_Unsubscribe(it->second->id_, it->second->subSensor_);
            }
            if (it->second->id_ ) {
                OH_Sensor_DestroySubscriptionId(it->second->id_);
            }
            if (it->second->subSensor_) {
                OH_Sensor_DestroySubscriber(it->second->subSensor_);
            }
            if (it->second->attr_) {
                OH_Sensor_DestroySubscriptionAttribute(it->second->attr_);
            }
            it->second->id_ = nullptr;
            it->second->attr_ = nullptr;
            it->second->subSensor_ = nullptr;
            it = g_sensorSubscriberMap_.erase(it);
        } else {
            ++it;
        }
    }
}

rnoh::ReanimatedSensor::~ReanimatedSensor() { destroySensor(); }
}