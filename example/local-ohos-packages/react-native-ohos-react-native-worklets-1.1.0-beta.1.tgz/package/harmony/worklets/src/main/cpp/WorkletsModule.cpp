// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#include "AnimationFrameManager.h"
#include "Common/cpp/worklets/WorkletRuntime/BundleModeConfig.h"
#include "Common/cpp/worklets/WorkletRuntime/RuntimeBindings.h"
#include "RNOH/ArkTSTurboModule.h"
#include "RNOH/RNInstance.h"
#include "WorkletsUIScheduler.h"
#include "WorkletsModuleProxy.h"
#include "WorkletsModule.h"
#include "cxxreact/JSBigString.h"
#include "rawfile/raw_file_manager.h"
#include "rawfile/raw_file.h"

using namespace facebook;
namespace worklets {
jsi::Value installTurboModule(facebook::jsi::Runtime &rt, react::TurboModule &turboModule,
                              const facebook::jsi::Value *args, size_t count) {
    auto self = static_cast<WorkletsModule *>(&turboModule);
    bool bundleModeEnabled = false;
    if (count >= 1 && args != nullptr && args[0].isBool()) {
        bundleModeEnabled = args[0].getBool();
    }
    self->installTurboModule(rt, bundleModeEnabled);
    return facebook::jsi::Value(true);
}

jsi::Value start(facebook::jsi::Runtime &rt, react::TurboModule &turboModule,
                 const facebook::jsi::Value *args, size_t count) {
    auto self = static_cast<WorkletsModule *>(&turboModule);
    self->start();
    return facebook::jsi::Value(true);
}

jsi::Value toggleSlowAnimationsOnUIRuntime(facebook::jsi::Runtime &rt, react::TurboModule &turboModule,
                                           const facebook::jsi::Value *args, size_t count) {
    auto self = static_cast<WorkletsModule *>(&turboModule);
    return facebook::jsi::Value(self->toggleSlowAnimationsOnUIRuntime());
}

WorkletsModule::WorkletsModule(const ArkTSTurboModule::Context ctx, const std::string name)
    : ArkTSTurboModule(ctx, name) {
    methodMap_ = {
        {"installTurboModule", {1, worklets::installTurboModule}},
        {"start", {0, worklets::start}},
        {"toggleSlowAnimationsOnUIRuntime", {0, worklets::toggleSlowAnimationsOnUIRuntime}},
    };
}

WorkletsModule::~WorkletsModule() {
    if (rnRuntimeStatus_) {
        rnRuntimeStatus_->setDead();
    }
    workletsModuleProxy_.reset();
}

void WorkletsModule::installTurboModule(facebook::jsi::Runtime &runtime, bool bundleModeEnabled) {
    if (workletsModuleProxy_) {
        DLOG(WARNING) << "WorkletsModuleProxy already initialized";
        return;
    }

    auto isJavaScriptQueue = [weakExecutor = std::weak_ptr(m_ctx.taskExecutor)]() {
        if (auto taskExecutor = weakExecutor.lock()) {
            return taskExecutor->isOnTaskThread(rnoh::TaskThread::JS);
        }
        return false;
    };
    auto animationManager = std::make_shared<rnoh::AnimationFrameManager>(
        [weakExecutor = std::weak_ptr(m_ctx.taskExecutor)](rnoh::TaskExecutor::Task &&task) {
            if (auto taskExecutor = weakExecutor.lock()) {
                taskExecutor->runTask(rnoh::TaskThread::MAIN, std::move(task));
            }
        });
    animationFrameManager_ = animationManager; // 保存，供 toggleSlowAnimationsOnUIRuntime 使用
    auto forwardedRequestAnimationFrame = std::function<void(std::function<void(const double)>)>(
        [animationFrameQueue = animationManager](std::function<void(const double)> callback) {
            animationFrameQueue->registerOnAnimationCallback(callback);
        });

#ifdef WORKLETS_BUNDLE_MODE
    // compile-time opt-in takes precedence over the runtime flag
    bundleModeEnabled = true;
#endif

    // In Bundle Mode the whole JS bundle is evaluated in the Worklet Runtime,
    // so we have to load it from rawfile and hand it over to the proxy.
    std::shared_ptr<const ScriptBuffer> script = nullptr;
    std::string sourceURL = "";
    if (bundleModeEnabled) {
        auto instance = m_ctx.instance.lock();
        if (instance != nullptr) {
            auto rawFile =
                OH_ResourceManager_OpenRawFile(instance->getNativeResourceManager(), instance->getBundlePath().c_str());
            if (rawFile != nullptr) {
                long len = OH_ResourceManager_GetRawFileSize(rawFile);
                std::string jsBigString(len, '\0');
                int res = OH_ResourceManager_ReadRawFile(rawFile, jsBigString.data(), len);
                if (res == len) {
                    script = std::make_shared<ScriptBuffer>(
                        std::make_unique<JSBigStdString>(std::move(jsBigString), true));
                    sourceURL = instance->getBundlePath();
                } else {
                    bundleModeEnabled = false;
                    DLOG(ERROR) << "[react_worklets] script read failed, falling back to non-bundle mode";
                }
                OH_ResourceManager_CloseRawFile(rawFile);
            } else {
                bundleModeEnabled = false;
                DLOG(WARNING) << "[react_worklets] cannot open rawfile: " << instance->getBundlePath()
                             << ", falling back to non-bundle mode";
            }
        } else {
            bundleModeEnabled = false;
        }
    }

    rnRuntimeStatus_ = std::make_shared<RNRuntimeStatus>();
    workletsModuleProxy_ = std::make_shared<WorkletsModuleProxy>(
        runtime, jsInvoker_, std::make_shared<rnoh::WorkletsUIScheduler>(m_ctx.taskExecutor),
        std::move(isJavaScriptQueue),
        std::make_shared<RuntimeBindings>(RuntimeBindings{
            .requestAnimationFrame = std::move(forwardedRequestAnimationFrame),
            .nativeLoggingHook = bundleModeEnabled ? extractNativeLoggingHookFromRNRuntime(runtime)
                                                   : RuntimeBindings::NativeLoggingHook{},
        }),
        BundleModeConfig{
            .enabled = bundleModeEnabled,
            .script = std::move(script),
            .sourceURL = std::move(sourceURL),
        },
        rnRuntimeStatus_);
}

void WorkletsModule::start() {
    if (!workletsModuleProxy_) {
        DLOG(ERROR) << "[react_worklets] start called before installTurboModule";
        return;
    }
    workletsModuleProxy_->start();
}

bool WorkletsModule::toggleSlowAnimationsOnUIRuntime() {
    // 对标上游 WorkletsModule.kt#toggleSlowAnimations）：拖慢因子 10，
    // 帧时间戳压缩后 UI runtime 的时间流速降为 1/10，动画随之放慢
    constexpr int kAnimationsDragFactor = 10;
    slowAnimationsEnabled_ = !slowAnimationsEnabled_.load();
    if (auto animationFrameManager = animationFrameManager_) {
        animationFrameManager->enableSlowAnimations(slowAnimationsEnabled_.load(), kAnimationsDragFactor);
    }
    return slowAnimationsEnabled_.load();
}

std::shared_ptr<worklets::WorkletsModuleProxy> WorkletsModule::getWorkletsModuleProxy() { return workletsModuleProxy_; }
} // namespace worklets
