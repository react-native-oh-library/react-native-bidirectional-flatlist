// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#pragma once

#include <atomic>
#include <chrono>
#include <vector>
#include <functional>
#include <native_display_soloist/native_display_soloist.h>
#include <native_vsync/native_vsync.h>
#include "RNOH/NativeVsyncHandle.h"
#include "RNOH/TaskExecutor/TaskExecutor.h"
using OnAnimationCallback = std::function<void(double)>;
namespace rnoh {
class AnimationFrameManager : public std::enable_shared_from_this<AnimationFrameManager> {
public:
    AnimationFrameManager(std::function<void(TaskExecutor::Task &&)> runOnTheMainThread);
    ~AnimationFrameManager() noexcept;
    std::vector<OnAnimationCallback> onAnimationCallbacks;
    NativeVsyncHandle m_vsyncHandle;
    std::function<void(TaskExecutor::Task &&)> runOnTheMainThread;

    void registerOnAnimationCallback(OnAnimationCallback callback);
    void onAnimationFrame(int64_t timestamp);

    // 慢速动画调试开关
    void enableSlowAnimations(bool enabled, int dragFactor);

private:
    double calculateTimestamp(int64_t timestampMs);

    // IOS_DYNAMIC_FRAMERATE_ENABLED（对标 iOS AnimationFrameQueue 的 ProMotion
    // 自适应帧率路径）：flag 开启时帧队列改用 DisplaySoloist 驱动，按 4 帧滑动
    // 平均的回调耗时在四档间调 ExpectedFrameRateRange；flag 关闭或 Soloist 创建
    // 失败时保持 NativeVsyncHandle 单次请求路径，行为不变。
    void updateDynamicFrameRate(std::chrono::duration<double, std::milli> elapsed);
    bool applyFrameRateTier(int32_t tier);

    OH_DisplaySoloist *displaySoloist_ = nullptr;
    bool useSoloist_ = false;
    static constexpr int TIME_SAMPLES_AMOUNT = 4;
    std::chrono::duration<double, std::milli> timeDeltas_[TIME_SAMPLES_AMOUNT]{};
    int timeDeltaIndex_ = 0;
    int32_t currentFrameRateTier_ = -1;

    std::mutex callbacksMutex_;
    // 慢速动画状态
    std::atomic<bool> slowAnimationsEnabled_{false};
    std::atomic<int> animationsDragFactor_{1};
    std::atomic<bool> slowAnimationsAnchorPending_{false};
    std::atomic<int64_t> slowAnimationsAnchorMs_{0};
};
} // namespace rnoh
