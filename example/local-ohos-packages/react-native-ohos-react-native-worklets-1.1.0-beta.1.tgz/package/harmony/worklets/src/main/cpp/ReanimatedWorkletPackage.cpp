// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#include "ReanimatedWorkletPackage.h"
#include "WorkletsModule.h"

using namespace rnoh;
using namespace facebook;

class WorkletsTurboModuleFactoryDelegate : public TurboModuleFactoryDelegate {
public:
    SharedTurboModule createTurboModule(Context ctx, const std::string &name) const override
    {
        if (name == "WorkletsModule") {
            return std::make_shared<worklets::WorkletsModule>(ctx, name);
        }
        return nullptr;
    };
};


std::unique_ptr<TurboModuleFactoryDelegate> ReanimatedWorkletPackage::createTurboModuleFactoryDelegate()
{
    return std::make_unique<WorkletsTurboModuleFactoryDelegate>();
}

class ReanimatedWorkletArkTsMessage : public ArkTSMessageHandler {
    void handleArkTSMessage(const Context &ctx) override
    {
    }
};

std::vector<ArkTSMessageHandler::Shared> ReanimatedWorkletPackage::createArkTSMessageHandlers()
{
    return { std::make_shared<ReanimatedWorkletArkTsMessage>() };
}
