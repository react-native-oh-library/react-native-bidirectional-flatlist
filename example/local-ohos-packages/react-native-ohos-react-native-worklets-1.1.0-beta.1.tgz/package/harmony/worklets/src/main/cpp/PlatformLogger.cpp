// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#pragma once

#include "worklets/Tools/PlatformLogger.h"
#include "glog/logging.h"
#include <string>

constexpr const auto tag = "Worklets";

namespace worklets {

void PlatformLogger::log(const char *str) { DLOG(INFO) << "[Worklets]:" << str; }


void PlatformLogger::log(const std::string &str) { DLOG(INFO) << "[Worklets]:" << str; }


void PlatformLogger::log(const double d) { DLOG(INFO) << "[Worklets]:" << d; }


void PlatformLogger::log(const int i) { DLOG(INFO) << "[Worklets]:" << i; }

void PlatformLogger::log(const bool b) { DLOG(INFO) << "[Worklets]:" << b; }
}