// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#include "AnimationFrameManager.h"

#include "Common/cpp/worklets/Tools/FeatureFlags.h"

#include <glog/logging.h>

constexpr int64_t NANO_TO_MILLIS = 1000000;

namespace rnoh {

namespace {
// 对标 iOS FrameRateRange 四档，字段 = {min, expected, max}；
// expected 只是请求值，渲染服务会按面板能力钳制（60Hz 屏最高 60）
struct FrameRateTier {
    int32_t min;
    int32_t expected;
    int32_t max;
    const char *name;
};
constexpr FrameRateTier K_FRAME_RATE_TIERS[] = {
    {60, 120, 120, "BEST"},    // 平均回调耗时 < 8ms
    {30, 60, 60, "STANDARD"},  // < 16ms
    {24, 30, 30, "LOW"},       // < 33ms
    {10, 24, 24, "POOR"},      // >= 33ms
};
} // namespace

static void vsyncHandleCallback(long long timestamp, void *data) {
    auto self = static_cast<AnimationFrameManager *>(data);
    self->onAnimationFrame(timestamp);
}

// Soloist 回调自带 targetTimestamp（语义对齐 iOS displayLink.targetTimestamp），
// 但现有管线消费的是 vsync timestamp，保持不变以最小化行为差异
static void soloistHandleCallback(long long timestamp, long long /*targetTimestamp*/, void *data) {
    auto self = static_cast<AnimationFrameManager *>(data);
    self->onAnimationFrame(timestamp);
}

AnimationFrameManager::AnimationFrameManager(std::function<void(TaskExecutor::Task &&)> runOnTheMainThread)
    : m_vsyncHandle("AnimationFrameManager"), runOnTheMainThread(std::move(runOnTheMainThread)) {
    // flag 真值来自编译期 WORKLETS_FEATURE_FLAGS（entry CMakeLists 拥有，
    // 当前为 [IOS_DYNAMIC_FRAMERATE_ENABLED:true]）
    if (worklets::StaticFeatureFlags::getFlag("IOS_DYNAMIC_FRAMERATE_ENABLED")) {
        displaySoloist_ = OH_DisplaySoloist_Create(false);
        useSoloist_ = displaySoloist_ != nullptr;
        if (useSoloist_) {
            // 对标 iOS 初始 currentFrameRate = BEST + preferredFramesPerSecond = 120
            currentFrameRateTier_ = 0;
            applyFrameRateTier(0);
            DLOG(INFO) << "[dynamic-framerate] enabled: DisplaySoloist ready (IOS_DYNAMIC_FRAMERATE_ENABLED=true)";
        } else {
            DLOG(WARNING) << "[dynamic-framerate] DisplaySoloist create failed, fallback to NativeVsync";
        }
    }
}

AnimationFrameManager::~AnimationFrameManager() noexcept {
    if (displaySoloist_ != nullptr) {
        OH_DisplaySoloist_Stop(displaySoloist_);
        OH_DisplaySoloist_Destroy(displaySoloist_);
        displaySoloist_ = nullptr;
    }
}

void AnimationFrameManager::registerOnAnimationCallback(OnAnimationCallback callback) {
    {
        std::lock_guard<std::mutex> lock(callbacksMutex_);
        onAnimationCallbacks.push_back(std::move(callback));
    }
    if (useSoloist_) {
        // 对标 iOS setPaused(FALSE)：有帧回调待执行就恢复 vsync 流；
        // 消费任务先 Stop 再执行回调（见 onAnimationFrame），执行中重注册
        // 的下一帧会经由这里重新 Start，动画循环得以延续
        OH_DisplaySoloist_Start(displaySoloist_, soloistHandleCallback, this);
    } else {
        m_vsyncHandle.requestFrame(vsyncHandleCallback, this);
    }
}
void AnimationFrameManager::onAnimationFrame(int64_t timestamp) {
    runOnTheMainThread([weakSelf = weak_from_this(), timestamp]() {
        auto self = weakSelf.lock();
        if (!self) {
            return;
        }
        std::vector<OnAnimationCallback> callbacks;
        {
            std::lock_guard<std::mutex> lock(self->callbacksMutex_);
            std::swap(callbacks, self->onAnimationCallbacks);
        }
        if (callbacks.empty()) {
            return;
        }
        if (self->useSoloist_) {
            // 对标 iOS setPaused(TRUE)：先暂停再执行，防止把执行中重注册的
            // 下一帧一起停掉
            OH_DisplaySoloist_Stop(self->displaySoloist_);
        }
        auto start = std::chrono::high_resolution_clock::now();
        for (auto &callback : callbacks) {
            callback(self->calculateTimestamp(timestamp/NANO_TO_MILLIS));
        }
        if (self->useSoloist_) {
            self->updateDynamicFrameRate(std::chrono::high_resolution_clock::now() - start);
        }
    });
}
void AnimationFrameManager::enableSlowAnimations(bool enabled, int dragFactor) {
    slowAnimationsEnabled_.store(enabled);
    animationsDragFactor_.store(dragFactor);
    if (enabled) {
        // 每次开启都重新锚定（对标上游 AnimationFrameQueue#enableSlowAnimations
        // 里重置 mFirstUptime 的行为）
        slowAnimationsAnchorPending_.store(true);
    }
}

// 仅在主线程调用（onAnimationFrame 的任务里）
double AnimationFrameManager::calculateTimestamp(int64_t timestampMs) {
    if (!slowAnimationsEnabled_.load()) {
        return static_cast<double>(timestampMs);
    }
    // 锚定开启后的第一帧：上游 Android 用 SystemClock.uptimeMillis() 做锚点，
    // 此处直接用帧时间戳本身，避免跨时钟的时基假设
    if (slowAnimationsAnchorPending_.exchange(false)) {
        slowAnimationsAnchorMs_.store(timestampMs);
        return static_cast<double>(timestampMs);
    }
    const int64_t anchor = slowAnimationsAnchorMs_.load();
    const int64_t factor = animationsDragFactor_.load();
    return static_cast<double>(anchor + (timestampMs - anchor) / factor);
}

// 仅在主线程调用。对标 iOS executeQueueForProMotion：4 帧滑动平均耗时
// 决定档位，档位变化才下发范围（避免每帧都做 IPC）
void AnimationFrameManager::updateDynamicFrameRate(std::chrono::duration<double, std::milli> elapsed) {
    timeDeltaIndex_ = (timeDeltaIndex_ + 1) % TIME_SAMPLES_AMOUNT;
    timeDeltas_[timeDeltaIndex_] = elapsed;
    double average = 0;
    for (int i = 0; i < TIME_SAMPLES_AMOUNT; i++) {
        average += timeDeltas_[i].count();
    }
    average = average / TIME_SAMPLES_AMOUNT;
    int32_t tier;
    if (average < 8) {
        tier = 0;
    } else if (average < 16) {
        tier = 1;
    } else if (average < 33) {
        tier = 2;
    } else {
        tier = 3;
    }
    if (tier != currentFrameRateTier_) {
        if (applyFrameRateTier(tier)) {
            currentFrameRateTier_ = tier;
        }
    }
}

bool AnimationFrameManager::applyFrameRateTier(int32_t tier) {
    const auto &range = K_FRAME_RATE_TIERS[tier];
    // SDK 字段顺序为 {min, max, expected}
    DisplaySoloist_ExpectedRateRange rateRange{range.min, range.max, range.expected};
    auto rc = OH_DisplaySoloist_SetExpectedFrameRateRange(displaySoloist_, &rateRange);
    DLOG(INFO) << "[dynamic-framerate] tier -> " << range.name << " (" << range.min << "/"
               << range.expected << "/" << range.max << ") rc=" << rc;
    return rc == 0;
}
};
