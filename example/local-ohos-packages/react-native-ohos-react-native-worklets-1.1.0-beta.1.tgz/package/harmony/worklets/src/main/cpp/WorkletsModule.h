// Copyright (c) 2026 Huawei Device Co., Ltd. All rights reserved
// Use of this source code is governed by a MIT license that can be
// found in the LICENSE file.

#pragma once

#include <atomic>
#include "AnimationFrameManager.h"
#include "RNOH/ArkTSTurboModule.h"
#include "worklets/NativeModules/WorkletsModuleProxy.h"
#include "worklets/Tools/RNRuntimeStatus.h"

namespace worklets {

class JSI_EXPORT WorkletsModule : public std::enable_shared_from_this<WorkletsModule>, public rnoh::ArkTSTurboModule {
public:
    WorkletsModule(const ArkTSTurboModule::Context ctx, const std::string name);
    ~WorkletsModule() override;
    void installTurboModule(facebook::jsi::Runtime &rt, bool bundleModeEnabled);
    void start();
    bool toggleSlowAnimationsOnUIRuntime();
    std::shared_ptr<worklets::WorkletsModuleProxy> getWorkletsModuleProxy();

private:
    std::shared_ptr<worklets::WorkletsModuleProxy> workletsModuleProxy_ = nullptr;
    std::shared_ptr<RNRuntimeStatus> rnRuntimeStatus_ = nullptr;
    // 供 toggleSlowAnimationsOnUIRuntime 使用
    std::shared_ptr<rnoh::AnimationFrameManager> animationFrameManager_ = nullptr;
    std::atomic<bool> slowAnimationsEnabled_{false};
};

} // namespace worklets
