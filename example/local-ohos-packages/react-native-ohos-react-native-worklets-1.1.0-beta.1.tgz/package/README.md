> 文档模板：v0.4.2

<p align="center">
  <h1 align="center"> <code>react-native-worklets</code> </h1>
</p>
<p align="center">
    <a href="https://github.com/software-mansion/react-native-reanimated/tree/main/packages/react-native-worklets">
        <img src="https://img.shields.io/badge/platforms-ios%20|%20android%20|%20web%20|%20harmony%20-lightgrey.svg" alt="Supported platforms" />
    </a>
    <a href="https://github.com/software-mansion/react-native-reanimated/blob/main/packages/react-native-worklets/LICENSE">
        <img src="https://img.shields.io/badge/license-MIT-green.svg" alt="License" />
    </a>
</p>

本项目基于 [原库 react-native-worklets](https://github.com/software-mansion/react-native-reanimated/tree/main/packages/react-native-worklets) 开发。

该第三方库的仓库已迁移至 Gitcode，且支持直接从 npm 下载，新的包名为：`@react-native-ohos/react-native-worklets`，版本所属关系如下：

| 三方库名称                               | 三方库版本（npm地址）                                        | 发布信息                                                     | 支持RN版本 | Autolink | 编译API版本 | 社区基线版本 | 源码地址                                                     |
| ---------------------------------------- | ------------------------------------------------------------ | ------------------------------------------------------------ | ---------- | -------- | ----------- | ------------ | ------------------------------------------------------------ |
| @react-native-ohos/react-native-worklets | [~ 1.1.0(进行中)](https://www.npmjs.com/package/@react-native-ohos/react-native-worklets) | [Gitcode Releases](https://gitcode.com/CPF-RN/rntpc_react-native-reanimated/releases) | 0.84.*     | 是       | API12+      | 0.11.4       | [br_rnoh0.84](https://gitcode.com/CPF-RN/rntpc_react-native-reanimated/tree/br_rnoh0.84) |

## 简介

react-native-worklets 是 React Native 的多线程库，自 `react-native-reanimated >= 4.0.0` 起从中独立出来，是 reanimated 的底层依赖，也可单独使用。它通过 worklet 机制（配合 Babel 插件将标记 `'worklet'` 的函数转换为可序列化、可跨线程传递的形式），提供在 UI 线程、RN（JS）线程与自定义 Worklet Runtime 之间调度执行代码的能力，并附带了跨运行时共享数据（Serializable / Synchronizable / Shareable）与运行时判断等基础设施。

> [!TIP] 单独使用 worklets 能力，或配合 `@react-native-ohos/react-native-reanimated`（>= 4.0.0，其原生端依赖本库）使用均可。

## 下载安装

进入到工程目录并输入以下命令：

**npm**

```bash
npm install react-native-worklets@0.11.4
npm install @react-native-ohos/react-native-worklets
```

**yarn**

```bash
yarn add react-native-worklets@0.11.4
yarn add @react-native-ohos/react-native-worklets
```

#### 插件配置

添加 `react-native-worklets/plugin` 插件到 `babel.config.js`：

> [!TIP] 为什么需要添加这个？Babel 插件会自动转换特殊的 JavaScript 函数（称为 worklet），以便它们可以被传递并在 UI 线程上运行。

```js
  module.exports = {
    presets: [
      ... // don't add it here :)
    ],
    plugins: [
      ...
      'react-native-worklets/plugin',
    ],
  };
```

清除 Metro 的缓存（推荐）：

**npm**

```bash
npm start --reset-cache
```

**yarn**

```bash
yarn start --reset-cache
```

## Link

|         | 是否支持autolink | RN框架版本 |
| ------- | ---------------- | ---------- |
| ~ 1.1.0 | 是               | 0.84       |

使用AutoLink的工程需要根据该文档配置，Autolink框架指导文档：https://gitcode.com/CPF-RN/ohos_react_native/blob/master/docs/zh-cn/Autolinking.md

如您使用的版本支持 Autolink，并且工程已接入 Autolink，可跳过ManualLink配置。

<details>
  <summary>ManualLink: 此步骤为手动配置原生依赖项的指导</summary>

首先需要使用 DevEco Studio 打开项目里的 HarmonyOS 工程 `harmony`。

### 1. Overrides RN SDK

为了让工程依赖同一个版本的 RN SDK，需要在工程根目录的 `oh-package.json5` 添加 overrides 字段，指向工程需要使用的 RN SDK 版本。替换的版本既可以是一个具体的版本号，也可以是一个模糊版本，还可以是本地存在的 HAR 包或源码目录。

关于该字段的作用请阅读[官方说明](https://developer.huawei.com/consumer/cn/doc/harmonyos-guides-V5/ide-oh-package-json5-V5#zh-cn_topic_0000001792256137_overrides)

```json
{
  ...
  "overrides": {
    "@rnoh/react-native-openharmony" : "~0.84.2",
  }
}
```

### 2. 引入原生端代码

目前有两种方法：

- 通过 har 包引入；
- 直接链接源码。

方法一：通过 har 包引入（推荐）

> [!TIP] har 包位于三方库安装路径的 `harmony` 文件夹下。

打开 `entry/oh-package.json5`，添加以下依赖

```json
"dependencies": {
    "@rnoh/react-native-openharmony": "~0.84.2",
    "@react-native-ohos/react-native-worklets": "file:../../node_modules/@react-native-ohos/react-native-worklets/harmony/worklets.har"
  }
```

点击右上角的 `sync` 按钮

或者在命令行终端执行：

```bash
cd entry
ohpm install
```

方法二：直接链接源码

> [!TIP] 如需使用直接链接源码，请参考[直接链接源码说明](https://gitcode.com/CPF-RN/usage-docs/blob/master/zh-cn/link-source-code.md)

### 3. 配置 CMakeLists 和引入 ReanimatedWorkletPackage

打开 `entry/src/main/cpp/CMakeLists.txt`，添加：

```diff
project(rnapp)
cmake_minimum_required(VERSION 3.4.1)
set(RNOH_APP_DIR "${CMAKE_CURRENT_SOURCE_DIR}")
+ set(OH_MODULES "${CMAKE_CURRENT_SOURCE_DIR}/../../../oh_modules")
set(RNOH_CPP_DIR "${CMAKE_CURRENT_SOURCE_DIR}/../../../../../../react-native-harmony/harmony/cpp")

# (可选)若需开启flags，按需参考配置如下：
+ add_compile_definitions(WORKLETS_FEATURE_FLAGS="[RUNTIME_TEST_FLAG:false][FETCH_PREVIEW_ENABLED:false][IOS_DYNAMIC_FRAMERATE_ENABLED:true][ENABLE_CROSS_RUNTIME_STACK_TRACES:true]")

add_subdirectory("${RNOH_CPP_DIR}" ./rn)

# RNOH_END: manual_package_linking_1
add_subdirectory("../../../../sample_package/src/main/cpp" ./sample-package)

+ add_subdirectory("${OH_MODULES}/@react-native-ohos/react-native-worklets/src/main/cpp" ./worklets)

# RNOH_END: manual_package_linking_1

add_library(rnoh_app SHARED
    "./PackageProvider.cpp"
    "${RNOH_CPP_DIR}/RNOHAppNapiBridge.cpp"
)

target_link_libraries(rnoh_app PUBLIC rnoh)

# RNOH_BEGIN: manual_package_linking_2
target_link_libraries(rnoh_app PUBLIC rnoh_sample_package)
+ target_link_libraries(rnoh_app PUBLIC rnoh_worklets)

# RNOH_BEGIN: manual_package_linking_2
```

打开 `entry/src/main/cpp/PackageProvider.cpp`，添加：

```diff
#include "RNOH/PackageProvider.h"
#include "SamplePackage.h"
+ #include "ReanimatedWorkletPackage.h"
using namespace rnoh;

std::vector<std::shared_ptr<Package>> PackageProvider::getPackages(Package::Context ctx) {
    return {
      std::make_shared<SamplePackage>(ctx),
+     std::make_shared<ReanimatedWorkletPackage>(ctx)
    };
}
```

### 4. 在 ArkTs 侧引入 ReanimatedWorkletPackage

打开 `entry/src/main/ets/RNPackagesFactory.ets`，添加：

```diff
  ...
+ import { ReanimatedWorkletPackage } from '@react-native-ohos/react-native-worklets'

export function createRNPackages(ctx: RNPackageContext): RNPackage[] {
  return [
    new SamplePackage(ctx),
+   new ReanimatedWorkletPackage(ctx),
  ];
}
```

</details>

### 运行

点击右上角的 `sync` 按钮

或者在命令行终端执行：

```bash
cd entry
ohpm install
```

然后编译、运行即可。

## 约束与限制

### 兼容性

本文档内容基于以下版本验证通过：

1. RNOH: 0.84.2;  SDK: HarmonyOS 6.0.1 Release SDK; IDE: DevEco Studio 6.0.1.260; ROM: 6.0.0.130 SP15;

## 使用示例

下面的代码展示了这个库的基本使用场景：

> [!WARNING] 使用时 import 的库名不变。

```js
import { runOnUIAsync } from 'react-native-worklets';

import React, { useState } from 'react';
import { StyleSheet, Text, View, Button } from 'react-native';

export default function RunOnUIAsyncExample() {
  const [textResult, setTextResult] = useState<string>('');

  const result: Promise<string> = runOnUIAsync((): string => {
    return 'runOnUIAsync';
  });

  return (
    <View style={styles.container}>
      <Text>runOnUIAsync: {textResult}</Text>
      <Button
        title="run"
        onPress={async () => {
          const str = await result;
          setTextResult(JSON.stringify(str));
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: 'white',
  },
});
```

## 接口说明

> [!TIP] "Platform"列表示该属性在原三方库上支持的平台。

> [!TIP] "HarmonyOS Support"列为 yes 表示 HarmonyOS 平台支持该属性；no 则表示不支持；partially 表示部分支持。使用方法跨平台一致，效果对标 iOS 或 Android 的效果。

### 属性

#### WorkletRuntimeConfig（createWorkletRuntime 配置）

| 名称                        | 参数类型                 | 默认值   | 必填 | 平台 | HarmonyOS平台支持 | 描述                                                       |
| --------------------------- | ------------------------ | --------- | ---- | ---- | ----------------- | ---------------------------------------------------------- |
| `name`                      | string                   | none      | No   | All  | Yes               | Worklet Runtime 名称，用于调试与异常堆栈定位               |
| `initializer`               | () => void               | none      | No   | All  | Yes               | runtime 创建后、其他 worklet 执行前立即运行的初始化 worklet |
| `animationQueuePollingRate` | number                   | 16        | No   | All  | Yes               | requestAnimationFrame 回调的轮询间隔（毫秒）               |
| `enableEventLoop`           | boolean                  | true      | No   | All  | Yes               | 是否启用默认事件循环（提供 setTimeout / setInterval / requestAnimationFrame 等） |
| `queue`                     | 'default' \| object \| null | 'default' | No | All  | Yes               | 调度队列：'default' 内置队列、对象为自定义 AsyncQueue、null 不挂载队列 |

#### WorkletRuntime（createWorkletRuntime 返回值）

| 名称        | 参数类型 | 默认值 | 必填 | 平台 | HarmonyOS平台支持 | 描述                                 |
| ----------- | -------- | ------ | ---- | ---- | ----------------- | ------------------------------------ |
| `name`      | string   | none   | No   | All  | Yes               | runtime 名称（只读）                 |
| `runtimeId` | number   | none   | No   | All  | Yes               | runtime 标识（只读），供 `scheduleOnRuntimeWithId` 等按 id 调度的 API 使用 |

#### Synchronizable（createSynchronizable 返回值）

跨运行时同步访问的共享值，可在 worklet 中直接读写：

| 名称            | 参数类型                                  | 默认值 | 必填 | 平台 | HarmonyOS平台支持 | 描述                                       |
| --------------- | ----------------------------------------- | ------ | ---- | ---- | ----------------- | ------------------------------------------ |
| `getDirty`      | () => Value                               | none   | No   | All  | Yes               | 非阻塞读取当前值（可能读到未加锁的"脏"值） |
| `getBlocking`   | () => Value                               | none   | No   | All  | Yes               | 阻塞读取当前值（加锁）                     |
| `setBlocking`   | (value: Value \| ((prev: Value) => Value)) => void | none | No | All | Yes        | 阻塞写入，支持直接赋值或更新函数           |
| `lock`          | () => void                                | none   | No   | All  | Yes               | 加锁（跨 runtime 互斥）                    |
| `unlock`        | () => void                                | none   | No   | All  | Yes               | 解锁                                       |

#### Shareable（createShareable 创建的共享对象）

绑定宿主 Worklet Runtime 的共享对象：宿主侧为 ShareableHost（直接持有值），其他 runtime 侧为 ShareableGuest（代理读写）：

| 名称                  | 所属侧       | 参数类型                                  | 默认值 | 必填 | 平台 | HarmonyOS平台支持 | 描述                                       |
| --------------------- | ------------- | ----------------------------------------- | ------ | ---- | ---- | ----------------- | ------------------------------------------ |
| `value`               | Host          | Value                                     | none   | No   | All  | Yes               | 宿主侧持有的共享值（直接读写）             |
| `getAsync`            | Guest         | () => Promise&lt;Value&gt;                | none   | No   | All  | Yes               | 异步读取共享值                             |
| `getSync`             | Guest         | () => Value                               | none   | No   | All  | Yes               | 同步读取共享值                             |
| `setAsync`            | Guest         | (value: Value \| ((prev: Value) => Value)) => void | none | No | All | Yes        | 异步写入共享值，支持更新函数               |
| `setSync`             | Guest         | (value: Value \| ((prev: Value) => Value)) => void | none | No | All | Yes        | 同步写入共享值，支持更新函数               |
| `hostDecorator`       | config 参数   | (shareable: ShareableHost) => ShareableHost | none | No | All  | Yes               | 装饰宿主对象的 worklet（须返回同一引用）   |
| `guestDecorator`      | config 参数   | (shareable: ShareableGuest) => ShareableGuest | none | No | All | Yes             | 装饰每个 guest 对象的 worklet（须返回同一引用） |
| `initSynchronously`   | config 参数   | boolean                                   | false  | No   | All  | Yes               | 是否在 createShareable 调用时同步创建宿主（默认懒创建） |

#### RegistrationData（registerCustomSerializable 参数）

| 名称        | 参数类型                                   | 默认值 | 必填 | 平台 | HarmonyOS平台支持 | 描述                                               |
| ----------- | ------------------------------------------ | ------ | ---- | ---- | ----------------- | -------------------------------------------------- |
| `name`      | string                                     | none   | Yes  | All  | Yes               | 自定义 Serializable 唯一名称（重复注册会告警）     |
| `determine` | (value: object) => boolean                 | none   | Yes  | All  | Yes               | 判断给定值是否属于该自定义类型的 worklet           |
| `pack`      | (value: TValue) => TPacked                 | none   | Yes  | All  | Yes               | 序列化前打包为可默认序列化类型的 worklet           |
| `unpack`    | (value: TPacked) => TValue                 | none   | Yes  | All  | Yes               | 反序列化后还原为原 JavaScript 值的 worklet         |

### API

#### 线程调度（UI 线程 / RN 线程）

| 名称                    | 类型     | 参数类型                                                        | 返回值                                   | 必填 | 平台 | HarmonyOS平台支持 | 描述                                              |
| ----------------------- | -------- | --------------------------------------------------------------- | ---------------------------------------- | ---- | ---- | ----------------- | ------------------------------------------------- |
| `runOnUI`               | function | (worklet: (...args) => ReturnValue)                             | (...args) => void                        | No   | All  | Yes               | 返回包装函数，调用时把 worklet 异步调度到 UI 线程 |
| `runOnUIAsync`          | function | (worklet: (...args) => ReturnValue, ...args)                    | Promise&lt;ReturnValue&gt;               | No   | All  | Yes               | 异步在 UI 线程执行 worklet，Promise 携带返回值    |
| `runOnUISync`           | function | (worklet: (...args) => ReturnValue, ...args)                    | ReturnValue                              | No   | All  | Yes               | 在 UI Runtime 上同步执行 worklet 并返回结果       |
| `executeOnUIRuntimeSync`| function | (worklet: (...args) => ReturnValue)                             | (...args) => ReturnValue                 | No   | All  | Yes               | 返回包装函数，调用时在 UI Runtime 上同步执行      |
| `scheduleOnUI`          | function | (worklet: (...args) => ReturnValue, ...args)                    | void                                     | No   | All  | Yes               | 立即把 worklet 调度到 UI 线程（不返回结果）       |
| `runOnJS`               | function | (fun: (...args) => ReturnValue)                                 | (...args) => void                        | No   | All  | Yes               | 返回包装函数，调用时把函数异步调度回 RN 线程      |
| `scheduleOnRN`          | function | (fun: (...args) => ReturnValue, ...args)                        | void                                     | No   | All  | Yes               | 立即把函数调度到 RN 线程微任务队列执行            |

#### Worklet Runtime

| 名称                        | 类型     | 参数类型                                                        | 返回值                                  | 必填 | 平台 | HarmonyOS平台支持 | 描述                                                       |
| --------------------------- | -------- | --------------------------------------------------------------- | --------------------------------------- | ---- | ---- | ----------------- | ---------------------------------------------------------- |
| `createWorkletRuntime`      | function | (config?: WorkletRuntimeConfig) 或 (name?, initializer?)        | WorkletRuntime                          | No   | All  | Yes               | 创建自定义 JS 运行时（可跑在与 JS / UI 线程不同的线程上）   |
| `runOnRuntime`              | function | (workletRuntime: WorkletRuntime, worklet)                       | WorkletFunction（异步执行包装）         | No   | All  | Yes               | 返回包装函数，调用时把 worklet 异步调度到指定 runtime      |
| `runOnRuntimeAsync`         | function | (workletRuntime: WorkletRuntime, worklet, ...args)              | Promise&lt;ReturnValue&gt;              | No   | All  | Yes               | 异步在指定 runtime 执行 worklet，Promise 携带返回值        |
| `runOnRuntimeAsyncWithId`   | function | (runtimeId: number, worklet, ...args)                           | Promise&lt;ReturnValue&gt;              | No   | All  | Yes               | 同 `runOnRuntimeAsync`，按 runtimeId 指定目标 runtime      |
| `runOnRuntimeSync`          | function | (workletRuntime: WorkletRuntime, worklet, ...args)              | ReturnValue                             | No   | All  | Yes               | 同步在指定 runtime 执行 worklet 并返回结果                 |
| `runOnRuntimeSyncWithId`    | function | (runtimeId: number, worklet, ...args)                           | ReturnValue                             | No   | All  | Yes               | 同 `runOnRuntimeSync`，按 runtimeId 指定目标 runtime       |
| `scheduleOnRuntime`         | function | (workletRuntime: WorkletRuntime, worklet, ...args)              | void                                    | No   | All  | Yes               | 把 worklet 调度到指定 runtime 执行                         |
| `scheduleOnRuntimeWithId`   | function | (runtimeId: number, worklet, ...args)                           | void                                    | No   | All  | Yes               | 同 `scheduleOnRuntime`，按 runtimeId 指定目标 runtime      |
| `UIRuntimeId`              | const    | -                                                               | number（= RuntimeKind.UI = 2）           | No   | All  | Yes               | UI Runtime 的 runtimeId 常量，`createShareable` 指定宿主时使用 |
| `getUIRuntimeHolder`        | function | ()                                                              | object（UI Runtime Holder）              | No   | All  | Yes               | 获取 UI Runtime 的底层 Holder（内部 / 高级用法）           |
| `getUISchedulerHolder`      | function | ()                                                              | object（UI Scheduler Holder）            | No   | All  | Yes               | 获取 UI Runtime 调度器的底层 Holder（内部 / 高级用法）     |

#### 运行时判断

| 名称                | 类型     | 参数类型 | 返回值      | 必填 | 平台 | HarmonyOS平台支持 | 描述                                                       |
| ------------------- | -------- | -------- | ----------- | ---- | ---- | ----------------- | ---------------------------------------------------------- |
| `getRuntimeKind`    | function | ()       | RuntimeKind | No   | All  | Yes               | 获取当前 runtime 种类（worklet 内可用）                    |
| `isRNRuntime`       | function | ()       | boolean     | No   | All  | Yes               | 当前是否为 React Native 运行时                             |
| `isUIRuntime`       | function | ()       | boolean     | No   | All  | Yes               | 当前是否为 UI 运行时                                       |
| `isWorkletRuntime`  | function | ()       | boolean     | No   | All  | Yes               | 当前是否为 Worklet 运行时（UI 或 Worker）                  |
| `isWorkerRuntime`   | function | ()       | boolean     | No   | All  | Yes               | 当前是否为用户创建的 Worker 运行时                         |

#### 共享与序列化

| 名称                        | 类型     | 参数类型                                        | 返回值                 | 必填 | 平台 | HarmonyOS平台支持 | 描述                                                       |
| --------------------------- | -------- | ----------------------------------------------- | ---------------------- | ---- | ---- | ----------------- | ---------------------------------------------------------- |
| `createShareable`           | function | (hostRuntimeId: number, initial: Value, config?) | Shareable               | No   | All  | Yes               | 创建绑定宿主 Worklet Runtime 的跨运行时共享对象            |
| `isShareable`               | function | (value: unknown)                                | boolean                | No   | All  | Yes               | 判断给定值是否为 Shareable（worklet 内可用）               |
| `createSerializable`        | function | (value: Value)                                  | SerializableRef        | No   | All  | Yes               | 递归把 JavaScript 值转为可跨运行时传递的 Serializable 引用 |
| `isSerializableRef`         | function | (value: unknown)                                | boolean                | No   | All  | Yes               | 判断给定值是否为 Serializable 引用                         |
| `registerCustomSerializable`| function | (registrationData: RegistrationData)            | void                   | No   | All  | Yes               | 为自定义类型注册打包 / 解包（序列化）逻辑                  |
| `serializableMappingCache`  | const    | -                                               | { set, get }           | No   | All  | Yes               | Serializable 对象与引用间的映射缓存（内部用）              |
| `createSynchronizable`      | function | (value: Value)                                  | Synchronizable         | No   | All  | Yes               | 创建带跨线程同步读写能力的 Synchronizable                  |
| `isSynchronizable`          | function | (value: unknown)                                | boolean                | No   | All  | Yes               | 判断给定值是否为 Synchronizable（worklet 内可用）          |

#### 已废弃（Deprecated）

以下导出为兼容保留，请优先使用对应替代项：

| 名称                              | 类型     | 参数类型                | 返回值                    | 必填 | 平台 | HarmonyOS平台支持 | 描述                                     |
| --------------------------------- | -------- | ----------------------- | ------------------------- | ---- | ---- | ----------------- | ---------------------------------------- |
| `makeShareable`<sup>deprecated</sup> | function | (value: Value)          | Value（Serializable 引用）| No   | All  | Yes               | 已废弃，请使用 `createSerializable`      |
| `makeShareableCloneRecursive`<sup>deprecated</sup> | function | (value, shouldPersistRemote?, depth?) | SerializableRef | No  | All  | Yes               | 已废弃，请使用 `createSerializable`      |
| `makeShareableCloneOnUIRecursive`<sup>deprecated</sup> | function | (value: Value)          | SerializableRef           | No   | All  | Yes               | 已废弃，内部使用                          |
| `isShareableRef`<sup>deprecated</sup> | function | (value: unknown)        | boolean                   | No   | All  | Yes               | 已废弃，请使用 `isSerializableRef`       |
| `shareableMappingCache`<sup>deprecated</sup> | const    | -                       | { set, get }              | No   | All  | Yes               | 已废弃，请使用 `serializableMappingCache` |
| `callMicrotasks`<sup>deprecated</sup> | function | ()                      | void（NOOP）              | No   | All  | Yes               | 已废弃，空实现仅为向后兼容               |

#### Worklet 工具

| 名称                | 类型     | 参数类型          | 返回值  | 必填 | 平台 | HarmonyOS平台支持 | 描述                                                       |
| ------------------- | -------- | ----------------- | ------- | ---- | ---- | ----------------- | ---------------------------------------------------------- |
| `isWorkletFunction` | function | (value: unknown)  | boolean | No   | All  | Yes               | 判断函数是否为 worklet（需启用 Babel 插件；声明前调用恒为 false；仅 RN 运行时有效） |

#### Feature Flags

| 名称                     | 类型     | 参数类型                             | 返回值  | 必填 | 平台 | HarmonyOS平台支持 | 描述                                               |
| ------------------------ | -------- | ------------------------------------ | ------- | ---- | ---- | ----------------- | -------------------------------------------------- |
| `getStaticFeatureFlag`  | function | (name: keyof StaticFeatureFlagsSchema) | boolean | No | All  | Yes               | 读取静态特性开关（编译期确定）                    |
| `setDynamicFeatureFlag` | function | (name: string, value: boolean)       | void    | No   | All  | Yes               | 动态设置特性开关                                   |
| `getDynamicFeatureFlag` | function | (name: string)                       | boolean | No   | All  | Yes               | 读取动态特性开关                                   |

静态开关：

| 名称                              | 参数类型 | 默认值 | 必填 | 平台 | HarmonyOS平台支持 | 描述                                                       |
| --------------------------------- | -------- | ------ | ---- | ---- | ----------------- | ---------------------------------------------------------- |
| `RUNTIME_TEST_FLAG`               | boolean  | false  | No   | All  | Yes               | 运行时测试开关（上游测试用途，源码中无业务消费点），鸿蒙行为与上游一致 |
| `FETCH_PREVIEW_ENABLED`           | boolean  | false  | No   | All  | Yes               | Bundle Mode 下是否在 Worklet Runtime 初始化网络模块（提供 fetch 预览能力） |
| `IOS_DYNAMIC_FRAMERATE_ENABLED`   | boolean  | true   | No   | iOS  | Yes            |  动态帧率（ProMotion 自适应刷新率）开关 |
| `ENABLE_CROSS_RUNTIME_STACK_TRACES` | boolean | true   | No   | All  | Yes               | 开发模式（\_\_DEV\_\_）下捕获跨 runtime 调度堆栈，便于错误堆栈跨 runtime 定位 |

#### 调试

| 名称                             | 类型     | 参数类型 | 返回值  | 必填 | 平台 | HarmonyOS平台支持 | 描述                                                       |
| -------------------------------- | -------- | -------- | ------- | ---- | ---- | ----------------- | ---------------------------------------------------------- |
| `isBundleModeEnabled`            | function | ()       | boolean | No   | All  | Yes               | 是否启用 Bundle Mode（由 Worklets Babel 插件在构建期注入） |
| `toggleSlowAnimationsOnUIRuntime`| function | ()       | boolean | No   | All  | Yes               | 切换 UI Runtime 慢速动画调试模式（内部调试用）             |

#### 原生模块

| 名称             | 类型 | 参数类型 | 返回值           | 必填 | 平台 | HarmonyOS平台支持 | 描述                                       |
| ---------------- | ---- | -------- | ---------------- | ---- | ---- | ----------------- | ------------------------------------------ |
| `WorkletsModule` | const | -        | IWorkletsModule  | No   | All  | Yes               | 原生 WorkletsModule（TurboModule）引用，内部 / 高级用法 |

### 枚举与常量

| 名称         | 类型 | 取值                                    | 必填 | 平台 | HarmonyOS平台支持 | 描述                                       |
| ------------ | ---- | --------------------------------------- | ---- | ---- | ----------------- | ------------------------------------------ |
| `RuntimeKind`| enum | ReactNative = 1, UI = 2, Worker = 3     | No   | All  | Yes               | 运行时种类（getRuntimeKind 返回）          |
| `UIRuntimeId`| const | 2（= RuntimeKind.UI）                    | No   | All  | Yes               | UI Runtime 的 runtimeId 常量               |

## 遗留问题

无

## 其他

无

## 目录结构

````
/rntpc_react-native-reanimated  # 项目根目录
├── package
│    ├── react-native-worklets          # worklets 鸿蒙适配包（reanimated >= 4.0.0 的底层依赖）
│    │    ├── harmony                    # 鸿蒙适配代码
│    │    │    └─ worklets.har           # har 包
│    │    │    └─ worklets               # 鸿蒙适配核心代码
│    │    │          └─ src/main/cpp     # C++ 适配代码（ReanimatedWorkletPackage）
│    │    │          └─ src/main/ets     # ArkTS 适配代码
│    │    ├── src
│    │    │    └─ index.ts               # 适配层入口（重导出上游 JS 导出）
│    │    └── package.json
│    └── react-native-reanimated         # reanimated 鸿蒙适配包
├── example                              # 示例工程
└── README.OpenSource                    # 开源信息

````

## 贡献代码

使用过程中发现任何问题都可以提交 [Issue](https://gitcode.com/CPF-RN/rntpc_react-native-reanimated/issues)，当然，也非常欢迎提交 [PR](https://gitcode.com/CPF-RN/rntpc_react-native-reanimated/pulls)。

## 开源协议

本项目基于 [The MIT License (MIT)](https://github.com/software-mansion/react-native-reanimated/blob/main/packages/react-native-worklets/LICENSE) ，请自由地享受和参与开源。
